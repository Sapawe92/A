/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { CameraScanner } from './components/CameraScanner';
import { VanStockManager } from './components/VanStockManager';
import { TechScheduler } from './components/TechScheduler';
import { TurnInsManager } from './components/TurnInsManager';
import { YearlyReports } from './components/YearlyReports';
import { GoogleDriveManager } from './components/GoogleDriveManager';
import { RepairGuides } from './components/RepairGuides';
import { OfflineIndicator } from './components/OfflineIndicator';
import { LeakScanLogo } from './components/Logo';
import { SubscriptionModal } from './components/SubscriptionModal';
import { TechLanguage, StockItem, Job, DailyTurnIn, Technician, LeakDiagnosis, Van, CustomerSignOff, SubscriptionTier } from './types';
import {
  loadStoredJobs,
  saveStoredJobs,
  loadStoredStock,
  saveStoredStock,
  loadStoredVans,
  saveStoredVans,
  loadStoredTechs,
  saveStoredTechs,
  loadStoredTurnIns,
  saveStoredTurnIns,
  enqueueSyncAction,
} from './services/offlineStorage';

export default function App() {
  const [activeTab, setActiveTab] = useState<'scan' | 'guides' | 'van' | 'techs' | 'turnins' | 'reports' | 'drive'>('scan');
  const [selectedLanguage, setSelectedLanguage] = useState<TechLanguage>('en');
  const [scannerImage, setScannerImage] = useState<string | null>(null);
  const [scannerNotes, setScannerNotes] = useState<string>('');

  // Contractor Subscription Tier state (persisted locally)
  const [subscriptionTier, setSubscriptionTier] = useState<SubscriptionTier>(() => {
    try {
      const saved = localStorage.getItem('leakscan_subscription_tier');
      return (saved as SubscriptionTier) || 'free';
    } catch {
      return 'free';
    }
  });
  const [showSubscriptionModal, setShowSubscriptionModal] = useState<boolean>(false);

  const handleSelectTier = (tier: SubscriptionTier) => {
    setSubscriptionTier(tier);
    try {
      localStorage.setItem('leakscan_subscription_tier', tier);
    } catch {
      // ignore
    }
  };

  // Core state loaded from offline LocalStorage cache (with fallback to mock data)
  const [vans, setVans] = useState<Van[]>(() => loadStoredVans());
  const [stockItems, setStockItems] = useState<StockItem[]>(() => loadStoredStock());
  const [techs, setTechs] = useState<Technician[]>(() => loadStoredTechs());
  const [jobs, setJobs] = useState<Job[]>(() => loadStoredJobs());
  const [turnIns, setTurnIns] = useState<DailyTurnIn[]>(() => loadStoredTurnIns());

  // Automatic persistent caching to LocalStorage
  useEffect(() => {
    saveStoredVans(vans);
  }, [vans]);

  useEffect(() => {
    saveStoredStock(stockItems);
  }, [stockItems]);

  useEffect(() => {
    saveStoredTechs(techs);
  }, [techs]);

  useEffect(() => {
    saveStoredJobs(jobs);
  }, [jobs]);

  useEffect(() => {
    saveStoredTurnIns(turnIns);
  }, [turnIns]);

  // Update Stock Item quantity
  const handleUpdateQuantity = (itemId: string, delta: number) => {
    const targetItem = stockItems.find((i) => i.id === itemId);
    const newQty = targetItem ? Math.max(0, targetItem.quantity + delta) : 0;
    enqueueSyncAction(
      'stock_update',
      `Updated ${targetItem?.name || 'part'} inventory (${delta > 0 ? '+' : ''}${delta} → ${newQty})`,
      { itemId, delta, newQty }
    );
    setStockItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
  };

  // Add new part to a van
  const handleAddItem = (newItem: Omit<StockItem, 'id'>) => {
    const item: StockItem = {
      ...newItem,
      id: `item-${Date.now()}`,
    };
    enqueueSyncAction('stock_add', `Added new part "${item.name}" to van stock`, item);
    setStockItems((prev) => [item, ...prev]);
  };

  // Restock all low parts in a van
  const handleRestockLowItems = (vanId: string) => {
    const targetVan = vans.find((v) => v.id === vanId);
    enqueueSyncAction(
      'stock_restock',
      `Restocked low inventory items for ${targetVan?.name || vanId}`,
      { vanId }
    );
    setStockItems((prev) =>
      prev.map((item) => {
        if (item.vanId === vanId && item.quantity <= item.minThreshold) {
          return {
            ...item,
            quantity: item.minThreshold * 2,
          };
        }
        return item;
      })
    );
  };

  // Deduct parts when a job is repaired
  const handleDeductPartsFromVan = (
    parts: Array<{ name: string; quantity: number }>,
    vanId: string
  ) => {
    enqueueSyncAction(
      'parts_deducted',
      `Deducted ${parts.length} part(s) from van inventory for completed repair`,
      { parts, vanId }
    );
    setStockItems((prev) =>
      prev.map((item) => {
        if (item.vanId !== vanId) return item;
        const matchingPart = parts.find((p) =>
          item.name.toLowerCase().includes(p.name.toLowerCase().slice(0, 10)) ||
          p.name.toLowerCase().includes(item.name.toLowerCase().slice(0, 10))
        );
        if (matchingPart) {
          return {
            ...item,
            quantity: Math.max(0, item.quantity - matchingPart.quantity),
          };
        }
        return item;
      })
    );
  };

  // Add Estimate as a new scheduled job
  const handleAddEstimateToJobs = (diagnosis: LeakDiagnosis) => {
    const activeTech = techs[0];
    const newJob: Job = {
      id: `job-${Date.now()}`,
      customerName: 'Customer (AI Scan Job)',
      customerPhone: '(555) 789-0123',
      address: 'Current Jobsite Location',
      timeSlot: 'Today - Immediate Repair',
      urgency: diagnosis.severity === 'critical' ? 'emergency' : 'high',
      status: 'in_progress',
      assignedTechId: activeTech.id,
      assignedTechName: activeTech.name,
      assignedVanName: activeTech.assignedVanName,
      issueSummary: diagnosis.issueName,
      estimateTotal: diagnosis.customerEstimate.totalEstimate,
      currentLeakPhoto: diagnosis.imageUrl || (diagnosis.imageUrls && diagnosis.imageUrls[0]),
      currentLeakPhotos: diagnosis.imageUrls || (diagnosis.imageUrl ? [diagnosis.imageUrl] : []),
      diagnosisData: diagnosis,
    };
    enqueueSyncAction(
      'job_create',
      `Created offline work order for "${diagnosis.issueName}" ($${diagnosis.customerEstimate.totalEstimate})`,
      newJob
    );
    setJobs((prev) => [newJob, ...prev]);
  };

  // Update tech status
  const handleUpdateTechStatus = (techId: string, newStatus: Technician['status']) => {
    setTechs((prev) =>
      prev.map((t) => (t.id === techId ? { ...t, status: newStatus } : t))
    );
  };

  // Update job status
  const handleUpdateJobStatus = (jobId: string, newStatus: Job['status']) => {
    const targetJob = jobs.find((j) => j.id === jobId);
    enqueueSyncAction(
      'job_status',
      `Updated job #${jobId.slice(-4)} (${targetJob?.customerName}) status to ${newStatus}`,
      { jobId, newStatus }
    );
    setJobs((prev) =>
      prev.map((job) => {
        if (job.id === jobId) {
          // If moving to completed, update tech metrics
          if (newStatus === 'completed' && job.status !== 'completed') {
            setTechs((tPrev) =>
              tPrev.map((tech) => {
                if (tech.id === job.assignedTechId) {
                  return {
                    ...tech,
                    jobsCompletedToday: tech.jobsCompletedToday + 1,
                    todayRevenue: tech.todayRevenue + (job.estimateTotal || 350),
                    status: 'available',
                  };
                }
                return tech;
              })
            );
          }
          return { ...job, status: newStatus };
        }
        return job;
      })
    );
  };

  // Dispatch new job from dispatch modal
  const handleDispatchNewJob = (newJobData: Omit<Job, 'id'>) => {
    const job: Job = {
      ...newJobData,
      id: `job-${Date.now()}`,
    };
    enqueueSyncAction(
      'job_create',
      `Dispatched job for ${job.customerName} (${job.address})`,
      job
    );
    setJobs((prev) => [job, ...prev]);
  };

  // Save customer sign-off on a job
  const handleSaveJobSignOff = (jobId: string, signOff: CustomerSignOff) => {
    const targetJob = jobs.find((j) => j.id === jobId);
    enqueueSyncAction(
      'job_signoff',
      `Captured customer sign-off from "${signOff.signerName}" for job #${jobId.slice(-4)} (${targetJob?.customerName || 'Customer'})`,
      { jobId, signOff }
    );
    setJobs((prev) =>
      prev.map((job) => {
        if (job.id === jobId) {
          // If not already completed, count toward tech metrics
          if (job.status !== 'completed') {
            setTechs((tPrev) =>
              tPrev.map((tech) => {
                if (tech.id === job.assignedTechId) {
                  return {
                    ...tech,
                    jobsCompletedToday: tech.jobsCompletedToday + 1,
                    todayRevenue: tech.todayRevenue + (job.estimateTotal || 350),
                    status: 'available',
                  };
                }
                return tech;
              })
            );
          }
          return {
            ...job,
            status: 'completed',
            signOff,
          };
        }
        return job;
      })
    );
  };

  // Add historical repair photo to a job
  const handleAddHistoricalPhoto = (jobId: string, photo: any) => {
    enqueueSyncAction(
      'job_historical_photo',
      `Attached historical comparison photo to job #${jobId.slice(-4)}`,
      { jobId, photo }
    );
    setJobs((prev) =>
      prev.map((job) => {
        if (job.id === jobId) {
          const currentPhotos = job.historicalPhotos || [];
          return {
            ...job,
            historicalPhotos: [photo, ...currentPhotos],
          };
        }
        return job;
      })
    );
  };

  // Submit shift turn-in
  const handleSubmitTurnIn = (
    data: Omit<DailyTurnIn, 'id' | 'status' | 'submittedAt'>
  ) => {
    const newTurn: DailyTurnIn = {
      ...data,
      id: `turn-${Date.now()}`,
      status: 'pending_review',
      submittedAt: 'Just now',
    };
    enqueueSyncAction(
      'turnin_submit',
      `Submitted daily turn-in report for ${newTurn.techName}`,
      newTurn
    );
    setTurnIns((prev) => [newTurn, ...prev]);
  };

  // Approve turn-in
  const handleApproveTurnIn = (turnId: string) => {
    setTurnIns((prev) =>
      prev.map((t) => (t.id === turnId ? { ...t, status: 'approved' } : t))
    );
  };

  // Counts for badges
  const lowStockCount = stockItems.filter((i) => i.quantity <= i.minThreshold).length;
  const pendingTurnInsCount = turnIns.filter((t) => t.status === 'pending_review').length;

  return (
    <div className="min-h-screen bg-[#0b1120] text-slate-100 flex flex-col selection:bg-amber-500 selection:text-slate-950">
      {/* Offline Mode & Network Connectivity Bar */}
      <OfflineIndicator />

      {/* Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedLanguage={selectedLanguage}
        setSelectedLanguage={setSelectedLanguage}
        lowStockCount={lowStockCount}
        pendingTurnInsCount={pendingTurnInsCount}
        activeTechName={techs[0]?.name || 'Alex Penchev'}
        subscriptionTier={subscriptionTier}
        onOpenSubscriptionModal={() => setShowSubscriptionModal(true)}
      />

      {/* Main Tab View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 pt-5">
        {activeTab === 'scan' && (
          <CameraScanner
            selectedLanguage={selectedLanguage}
            setSelectedLanguage={setSelectedLanguage}
            vans={vans}
            stockItems={stockItems}
            onDeductPartsFromVan={handleDeductPartsFromVan}
            onAddEstimateToJobs={handleAddEstimateToJobs}
            initialImage={scannerImage}
            initialNotes={scannerNotes}
            onNavigateToDrive={() => setActiveTab('drive')}
          />
        )}

        {activeTab === 'guides' && (
          <RepairGuides
            selectedLanguage={selectedLanguage}
            setSelectedLanguage={setSelectedLanguage}
            stockItems={stockItems}
            jobs={jobs}
            onSaveJobSignOff={handleSaveJobSignOff}
            onNavigateToScan={() => setActiveTab('scan')}
            onNavigateToDrive={() => setActiveTab('drive')}
            subscriptionTier={subscriptionTier}
            onSelectTier={handleSelectTier}
            onOpenSubscriptionModal={() => setShowSubscriptionModal(true)}
          />
        )}

        {activeTab === 'van' && (
          <VanStockManager
            vans={vans}
            stockItems={stockItems}
            onUpdateQuantity={handleUpdateQuantity}
            onAddItem={handleAddItem}
            onRestockLowItems={handleRestockLowItems}
            subscriptionTier={subscriptionTier}
            onSelectTier={handleSelectTier}
            onOpenSubscriptionModal={() => setShowSubscriptionModal(true)}
          />
        )}

        {activeTab === 'techs' && (
          <TechScheduler
            techs={techs}
            jobs={jobs}
            vans={vans}
            onUpdateTechStatus={handleUpdateTechStatus}
            onUpdateJobStatus={handleUpdateJobStatus}
            onDispatchNewJob={handleDispatchNewJob}
            onAddHistoricalPhoto={handleAddHistoricalPhoto}
            onSaveJobSignOff={handleSaveJobSignOff}
            onNavigateToDrive={() => setActiveTab('drive')}
            subscriptionTier={subscriptionTier}
            onSelectTier={handleSelectTier}
            onOpenSubscriptionModal={() => setShowSubscriptionModal(true)}
          />
        )}

        {activeTab === 'turnins' && (
          <TurnInsManager
            turnIns={turnIns}
            techs={techs}
            vans={vans}
            onSubmitTurnIn={handleSubmitTurnIn}
            onApproveTurnIn={handleApproveTurnIn}
          />
        )}

        {activeTab === 'reports' && <YearlyReports />}

        {activeTab === 'drive' && (
          <GoogleDriveManager
            onLoadPhotoIntoScanner={(photoUrl, notes) => {
              setScannerImage(photoUrl);
              setScannerNotes(notes || '');
              setActiveTab('scan');
            }}
            onNavigateToScan={() => setActiveTab('scan')}
          />
        )}
      </main>

      {/* Contractor Quick Mobile Bar / Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-4 px-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <LeakScanLogo size="sm" showText={false} />
            <span className="font-bold text-slate-200">LEAKSCAN AI</span>
            <span>— Built for Plumbing & Mechanical Field Contractors</span>
          </div>
          <div className="text-[11px] text-slate-400">
            ESL Multilingual Support: English • Español • Български • Українська • Русский • Polski
          </div>
        </div>
      </footer>

      {/* Contractor Membership & Subscription Modal */}
      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        currentTier={subscriptionTier}
        onSelectTier={handleSelectTier}
      />
    </div>
  );
}
