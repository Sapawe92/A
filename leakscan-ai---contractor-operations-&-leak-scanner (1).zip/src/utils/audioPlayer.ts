// Web Speech API text-to-speech utility with native language voice selection
export function speakText(text: string, langCode: string, onEnd?: () => void): () => void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported in this browser.');
    if (onEnd) onEnd();
    return () => {};
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  
  // Map our language codes to BCP 47 language tags
  const langTagMap: Record<string, string> = {
    en: 'en-US',
    bg: 'bg-BG',
    es: 'es-ES',
    uk: 'uk-UA',
    ru: 'ru-RU',
    pl: 'pl-PL',
    pt: 'pt-BR',
  };

  const targetLang = langTagMap[langCode] || 'en-US';
  utterance.lang = targetLang;
  utterance.rate = 0.95; // Slightly slower, very clear for field instructions
  utterance.pitch = 1.0;

  // Attempt to select the best matching voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find((v) => v.lang.startsWith(langCode)) || voices.find((v) => v.lang.includes(langCode));
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  utterance.onend = () => {
    if (onEnd) onEnd();
  };

  utterance.onerror = () => {
    if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);

  // Return cancel function
  return () => {
    window.speechSynthesis.cancel();
    if (onEnd) onEnd();
  };
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
