export type TechLanguage = 'en' | 'es' | 'bg' | 'uk' | 'ru' | 'pl' | 'pt';

export interface LanguageOption {
  code: TechLanguage;
  label: string;
  nativeLabel: string;
  flag: string;
}

export interface RepairStep {
  stepNumber: number;
  title: string;
  instruction: string;
  visualCue: string;
  safetyWarning?: string;
}

export interface RequiredMaterial {
  name: string;
  nameLocal: string;
  specs: string;
  quantity: number;
  unitCost: number;
  standardRetailPrice: number;
  inVanStock: boolean;
  vanStockCount?: number;
}

export interface CustomerEstimate {
  laborHours: number;
  recommendedLaborRate: number;
  partsSubtotal: number;
  tripDiagnosticFee: number;
  totalEstimate: number;
  clientSummaryEnglish: string;
}

export interface LeakDiagnosis {
  issueName: string;
  issueNameLocal: string;
  severity: 'critical' | 'high' | 'moderate' | 'minor';
  leakType: string;
  rootCause: string;
  rootCauseLocal: string;
  estimatedRepairTimeMinutes: number;
  confidenceScore?: number;
  repairSteps: RepairStep[];
  requiredMaterials: RequiredMaterial[];
  customerEstimate: CustomerEstimate;
  audioScript: string;
  imageUrl?: string;
  imageUrls?: string[];
  timestamp?: string;
}

export interface Technician {
  id: string;
  name: string;
  avatar: string;
  phone: string;
  status: 'on_site' | 'en_route' | 'at_supply_house' | 'available' | 'off_duty';
  assignedVanId: string;
  assignedVanName: string;
  currentJobAddress?: string;
  nativeLanguage: TechLanguage;
  jobsCompletedToday: number;
  todayRevenue: number;
  etaMinutes?: number;
}

export interface Van {
  id: string;
  name: string;
  licensePlate: string;
  assignedTechId: string;
  assignedTechName: string;
  makeModel: string;
  totalStockItems: number;
  lowStockItemsCount: number;
  lastAudited: string;
}

export interface StockItem {
  id: string;
  vanId: string;
  name: string;
  category: 'fittings' | 'valves' | 'pipes' | 'sealants' | 'tools' | 'fixtures';
  sku: string;
  quantity: number;
  minThreshold: number;
  unitCost: number;
  retailPrice: number;
  binLocation: string;
}

export interface HistoricalRepairPhoto {
  id: string;
  date: string;
  photoUrl: string;
  title: string;
  technicianName: string;
  partsUsed: string[];
  repairNotes: string;
  status: 'fixed' | 'prior_leak' | 'before' | 'after';
}

export interface CustomerSignOff {
  signerName: string;
  signatureDataUrl: string;
  signedAt: string;
  satisfactionRating?: number;
  notes?: string;
  termsAccepted?: boolean;
  procedureName?: string;
  invoiceTotal?: number;
  driveFileId?: string;
  driveViewLink?: string;
}

export interface Job {
  id: string;
  customerName: string;
  customerPhone: string;
  address: string;
  timeSlot: string;
  urgency: 'emergency' | 'high' | 'standard';
  status: 'scheduled' | 'dispatched' | 'en_route' | 'in_progress' | 'completed';
  assignedTechId: string;
  assignedTechName: string;
  assignedVanName: string;
  issueSummary: string;
  estimateTotal?: number;
  currentLeakPhoto?: string;
  currentLeakPhotos?: string[];
  diagnosisData?: LeakDiagnosis;
  historicalPhotos?: HistoricalRepairPhoto[];
  signOff?: CustomerSignOff;
}

export interface DailyTurnIn {
  id: string;
  date: string;
  techId: string;
  techName: string;
  vanName: string;
  jobsCompleted: number;
  cashCollected: number;
  checksCollected: number;
  cardCollected: number;
  supplyReceiptsTotal: number;
  mileageStart: number;
  mileageEnd: number;
  vanRestocked: boolean;
  notes: string;
  status: 'pending_review' | 'approved' | 'rejected';
  submittedAt: string;
}

export interface FinancialMetric {
  year: number;
  grossRevenue: number;
  completedJobs: number;
  averageTicket: number;
  partsCosts: number;
  laborCosts: number;
  netProfit: number;
  profitMarginPercent: number;
}

export interface RepairGuideStep {
  stepNumber: number;
  title: string;
  instruction: string;
  safetyWarning?: string;
  proTip?: string;
}

export interface LocalizedGuideContent {
  title: string;
  summary: string;
  symptoms: string[];
  steps: RepairGuideStep[];
  proTips?: string[];
  safetyWarning?: string;
}

export interface RepairGuide {
  id: string;
  title: string;
  category: 'water_supply' | 'drainage' | 'water_heaters' | 'fixtures' | 'valves' | 'emergency';
  categoryLabel: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedMinutes: number;
  symptoms: string[];
  requiredTools: string[];
  requiredMaterials: string[];
  translations: Partial<Record<TechLanguage, LocalizedGuideContent>>;
  supportedLanguages: TechLanguage[];
  tags: string[];
  featured?: boolean;
}

export type SubscriptionTier = 'free' | 'standard' | 'pro' | 'enterprise';

export interface SubscriptionFeatureComparison {
  name: string;
  category: string;
  free: boolean | string;
  standard: boolean | string;
  pro: boolean | string;
  enterprise: boolean | string;
  highlight?: boolean;
}

export interface SubscriptionPlan {
  id: SubscriptionTier;
  name: string;
  badge?: string;
  tagline: string;
  priceMonthly: number;
  priceAnnual: number;
  popular?: boolean;
  features: string[];
  limitations?: string[];
  ctaText: string;
  colorScheme: 'slate' | 'amber' | 'blue' | 'purple' | 'emerald';
}
