import React, { useState } from 'react';
import {
  Truck,
  Plus,
  Minus,
  AlertTriangle,
  Search,
  ShoppingCart,
  Filter,
  Package,
  Layers,
  CheckCircle,
  Copy,
  Check,
  X,
  RefreshCw,
  SlidersHorizontal,
} from 'lucide-react';
import { StockItem, Van, SubscriptionTier } from '../types';
import { VanStockPaywall } from './VanStockPaywall';

interface VanStockManagerProps {
  vans: Van[];
  stockItems: StockItem[];
  onUpdateQuantity: (itemId: string, delta: number) => void;
  onAddItem: (newItem: Omit<StockItem, 'id'>) => void;
  onRestockLowItems: (vanId: string) => void;
  subscriptionTier?: SubscriptionTier;
  onSelectTier?: (tier: SubscriptionTier) => void;
  onOpenSubscriptionModal?: () => void;
}

export const VanStockManager: React.FC<VanStockManagerProps> = ({
  vans,
  stockItems,
  onUpdateQuantity,
  onAddItem,
  onRestockLowItems,
  subscriptionTier = 'free',
  onSelectTier = () => {},
  onOpenSubscriptionModal = () => {},
}) => {
  // If user is on Free or Standard tier, render the catchy Van Stock PRO paywall
  if (subscriptionTier === 'free' || subscriptionTier === 'standard') {
    return (
      <VanStockPaywall
        currentTier={subscriptionTier}
        vans={vans}
        stockItems={stockItems}
        onSelectTier={onSelectTier}
        onOpenSubscriptionModal={onOpenSubscriptionModal}
      />
    );
  }
  const [selectedVanId, setSelectedVanId] = useState<string>(vans[0]?.id || 'van-1');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showRestockCart, setShowRestockCart] = useState<boolean>(false);
  const [copiedOrder, setCopiedOrder] = useState<boolean>(false);

  // New item form state
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<StockItem['category']>('fittings');
  const [newItemSku, setNewItemSku] = useState('');
  const [newItemQty, setNewItemQty] = useState(5);
  const [newItemMinThreshold, setNewItemMinThreshold] = useState(3);
  const [newItemUnitCost, setNewItemUnitCost] = useState(12);
  const [newItemRetailPrice, setNewItemRetailPrice] = useState(28);
  const [newItemBin, setNewItemBin] = useState('Bin A-1');

  const selectedVan = vans.find((v) => v.id === selectedVanId) || vans[0];

  // Filter items for selected van
  const vanItems = stockItems.filter((item) => item.vanId === selectedVanId);

  const filteredItems = vanItems.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.binLocation.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesLowStock = !showLowStockOnly || item.quantity <= item.minThreshold;
    return matchesSearch && matchesCategory && matchesLowStock;
  });

  // Calculate metrics
  const totalUnits = vanItems.reduce((acc, curr) => acc + curr.quantity, 0);
  const lowStockItems = vanItems.filter((item) => item.quantity <= item.minThreshold);
  const totalInventoryValue = vanItems.reduce((acc, curr) => acc + curr.quantity * curr.unitCost, 0);

  // Handle adding new part
  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    onAddItem({
      vanId: selectedVanId,
      name: newItemName.trim(),
      category: newItemCategory,
      sku: newItemSku.trim() || `SKU-${Date.now().toString().slice(-4)}`,
      quantity: Number(newItemQty),
      minThreshold: Number(newItemMinThreshold),
      unitCost: Number(newItemUnitCost),
      retailPrice: Number(newItemRetailPrice),
      binLocation: newItemBin.trim() || 'General Bin',
    });

    // Reset
    setNewItemName('');
    setNewItemSku('');
    setShowAddModal(false);
  };

  // Generate copyable Ferguson/Home Depot text
  const generateSupplyOrderText = () => {
    return lowStockItems
      .map(
        (item) =>
          `[ ] ${item.name} (SKU: ${item.sku}) - NEED: ${Math.max(1, item.minThreshold * 2 - item.quantity)} units (Current: ${item.quantity})`
      )
      .join('\n');
  };

  const copySupplyOrder = () => {
    const text = generateSupplyOrderText();
    navigator.clipboard.writeText(text);
    setCopiedOrder(true);
    setTimeout(() => setCopiedOrder(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner with Van Fleet Switcher */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex flex-wrap items-center gap-2">
                <span>Van Inventory & Stock Tracker</span>
                {subscriptionTier === 'enterprise' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[11px] font-bold">
                    👑 Titan Enterprise
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-bold">
                    ⭐ Master Pro Active
                  </span>
                )}
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[11px] font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  Offline Cached
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Real-time truck inventory, automatic restock reorder carts, and low-parts threshold warnings.
              </p>
            </div>
          </div>

          {/* Quick Van Selector Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {vans.map((van) => {
              const vanLows = stockItems.filter((i) => i.vanId === van.id && i.quantity <= i.minThreshold).length;
              return (
                <button
                  key={van.id}
                  onClick={() => setSelectedVanId(van.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedVanId === van.id
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'bg-slate-950/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>{van.name.split(' - ')[0]}</span>
                  {vanLows > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                        selectedVanId === van.id
                          ? 'bg-slate-950 text-amber-400'
                          : 'bg-rose-500 text-white'
                      }`}
                    >
                      {vanLows} low
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* KPI Overview Cards for Selected Van */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Assigned Tech</span>
            <Truck className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-base sm:text-lg font-black text-white">{selectedVan.assignedTechName}</div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">{selectedVan.makeModel}</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Total Van Units</span>
            <Package className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">{totalUnits}</div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Across {vanItems.length} SKUs</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Low Stock Items</span>
            <AlertTriangle className={`w-4 h-4 ${lowStockItems.length > 0 ? 'text-rose-400' : 'text-slate-500'}`} />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span>{lowStockItems.length}</span>
            {lowStockItems.length > 0 && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                Action Required
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Below safe threshold</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Van Inventory Value</span>
            <ShoppingCart className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-400">
            ${totalInventoryValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Wholesale cost basis</div>
        </div>
      </div>

      {/* Action Bar: Search, Filters, Add Item & Reorder Cart */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search parts by name, SKU, or bin location..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
            />
          </div>

          {/* Quick Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowLowStockOnly(!showLowStockOnly)}
              className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                showLowStockOnly
                  ? 'bg-rose-500 text-white shadow-md'
                  : 'bg-slate-950 text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Low Stock Only ({lowStockItems.length})</span>
            </button>

            <button
              onClick={() => setShowRestockCart(true)}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center gap-1.5 shadow-md shadow-amber-500/20"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>Supply Reorder Cart</span>
            </button>

            <button
              onClick={() => setShowAddModal(true)}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Part</span>
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {['all', 'fittings', 'valves', 'pipes', 'sealants', 'tools', 'fixtures'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`text-[11px] font-bold px-3 py-1.5 rounded-lg capitalize transition-colors ${
                categoryFilter === cat
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800/80'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Parts Inventory List / Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            {filteredItems.length} Parts in {selectedVan.name}
          </span>
          <span className="text-[11px] text-slate-500 font-mono">
            Audited {selectedVan.lastAudited}
          </span>
        </div>

        {filteredItems.length === 0 ? (
          <div className="p-10 text-center text-slate-400">
            <Package className="w-8 h-8 mx-auto mb-2 text-slate-600" />
            <p className="text-sm font-semibold">No parts found</p>
            <p className="text-xs text-slate-500 mt-0.5">Try adjusting your search query or category filters.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {filteredItems.map((item) => {
              const isLow = item.quantity <= item.minThreshold;
              return (
                <div
                  key={item.id}
                  className={`p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                    isLow ? 'bg-rose-500/[0.04]' : 'hover:bg-slate-800/30'
                  }`}
                >
                  {/* Left: Info */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-bold text-white">{item.name}</h4>
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {item.sku}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider bg-slate-800 px-1.5 py-0.2 rounded">
                        {item.category}
                      </span>
                      {isLow && (
                        <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 bg-rose-500/20 border border-rose-500/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Low Stock (Min: {item.minThreshold})
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-4 mt-1.5 text-xs text-slate-400 font-mono">
                      <span>Location: <strong className="text-slate-300 font-sans">{item.binLocation}</strong></span>
                      <span>Cost: <strong className="text-slate-300 font-sans">${item.unitCost.toFixed(2)}</strong></span>
                      <span>Client Bill: <strong className="text-emerald-400 font-sans">${item.retailPrice.toFixed(2)}</strong></span>
                    </div>
                  </div>

                  {/* Right: Instant Quantity Adjusters */}
                  <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                    <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-xl p-1">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center transition-all disabled:opacity-40"
                        title="Deduct 1"
                        disabled={item.quantity <= 0}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>

                      <div className="w-12 text-center">
                        <span
                          className={`text-sm font-black font-mono ${
                            isLow ? 'text-rose-400' : 'text-white'
                          }`}
                        >
                          {item.quantity}
                        </span>
                      </div>

                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center transition-all"
                        title="Add 1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right w-16">
                      <div className="text-xs font-bold text-slate-200">
                        ${(item.quantity * item.unitCost).toFixed(2)}
                      </div>
                      <div className="text-[10px] text-slate-500">Value</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Supply Reorder Cart Modal / Sheet */}
      {showRestockCart && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">
                  Ferguson / Supply House Pickup Order
                </h3>
              </div>
              <button
                onClick={() => setShowRestockCart(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Below are all items in <strong>{selectedVan.name}</strong> currently below safety minimum threshold.
            </p>

            {lowStockItems.length === 0 ? (
              <div className="p-6 text-center bg-slate-950 rounded-xl border border-slate-800">
                <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm font-bold text-white">Van Stock Fully Replenished!</p>
                <p className="text-xs text-slate-400 mt-0.5">All parts are above safety minimum stock thresholds.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {lowStockItems.map((item) => {
                  const qtyToOrder = Math.max(1, item.minThreshold * 2 - item.quantity);
                  return (
                    <div
                      key={item.id}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-bold text-white">{item.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          SKU: {item.sku} | In Van: {item.quantity} (Min: {item.minThreshold})
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-xs border border-amber-500/30">
                          Order +{qtyToOrder}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          ~${(qtyToOrder * item.unitCost).toFixed(2)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="pt-2 flex flex-col sm:flex-row gap-2">
              <button
                onClick={copySupplyOrder}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-1.5"
              >
                {copiedOrder ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Copied to Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Supply List (Ferguson/Home Depot)</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onRestockLowItems(selectedVanId);
                  setShowRestockCart(false);
                }}
                className="py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Mark Restocked & Update Van</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Part Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-amber-400" />
                <span>Add Part to {selectedVan.name}</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddNewItem} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-bold uppercase block mb-1">Part Name & Specs</label>
                <input
                  type="text"
                  required
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder="e.g. 3/4 inch SharkBite Slip Coupling"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Category</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="fittings">Fittings</option>
                    <option value="valves">Valves</option>
                    <option value="pipes">Pipes</option>
                    <option value="sealants">Sealants & Glue</option>
                    <option value="tools">Tools</option>
                    <option value="fixtures">Fixtures</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">SKU / Model Number</label>
                  <input
                    type="text"
                    value={newItemSku}
                    onChange={(e) => setNewItemSku(e.target.value)}
                    placeholder="e.g. SB-SLIP-075"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Initial Quantity in Van</label>
                  <input
                    type="number"
                    min="1"
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Min Low Threshold</label>
                  <input
                    type="number"
                    min="1"
                    value={newItemMinThreshold}
                    onChange={(e) => setNewItemMinThreshold(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Wholesale Cost ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemUnitCost}
                    onChange={(e) => setNewItemUnitCost(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Client Bill Price ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newItemRetailPrice}
                    onChange={(e) => setNewItemRetailPrice(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Van Bin Location</label>
                  <input
                    type="text"
                    value={newItemBin}
                    onChange={(e) => setNewItemBin(e.target.value)}
                    placeholder="Bin B-2"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black"
                >
                  Save to Van Inventory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
