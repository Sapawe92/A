import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  RotateCcw,
  Trash2,
  Check,
  Type,
  PenTool,
  Palette,
  AlertCircle,
  FileCheck,
} from 'lucide-react';

interface Point {
  x: number;
  y: number;
  pressure?: number;
}

interface Stroke {
  points: Point[];
  color: string;
  width: number;
}

export interface SignaturePadProps {
  initialSignature?: string;
  signerName?: string;
  onSave?: (dataUrl: string) => void;
  onClear?: () => void;
  onCancel?: () => void;
  title?: string;
  subtitle?: string;
  required?: boolean;
  className?: string;
  height?: number;
}

const PEN_COLORS = [
  { label: 'Navy Ink', value: '#0f294a', preview: 'bg-[#0f294a]' },
  { label: 'Deep Black', value: '#111827', preview: 'bg-slate-900' },
  { label: 'Royal Blue', value: '#1d4ed8', preview: 'bg-blue-700' },
];

const PEN_WIDTHS = [
  { label: 'Fine', value: 2 },
  { label: 'Medium', value: 3 },
  { label: 'Bold', value: 4.5 },
];

const SCRIPT_FONTS = [
  { name: 'Classic Script', font: 'italic bold 28px "Caveat", "Brush Script MT", cursive' },
  { name: 'Formal Calligraphy', font: 'italic 26px "Great Vibes", "Apple Chancery", cursive' },
  { name: 'Modern Signature', font: 'italic 600 24px "Segoe Script", "Lucida Handwriting", cursive' },
];

export const SignaturePad: React.FC<SignaturePadProps> = ({
  initialSignature,
  signerName = '',
  onSave,
  onClear,
  onCancel,
  title = 'Customer Signature',
  subtitle = 'Please sign using finger, stylus, or mouse',
  required = true,
  className = '',
  height = 200,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [mode, setMode] = useState<'draw' | 'type'>('draw');
  const [typedName, setTypedName] = useState(signerName);
  const [selectedFontIndex, setSelectedFontIndex] = useState(0);

  const [penColor, setPenColor] = useState('#0f294a');
  const [penWidth, setPenWidth] = useState(3);
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<Point[]>([]);
  const [hasSignature, setHasSignature] = useState(Boolean(initialSignature));
  const [currentDataUrl, setCurrentDataUrl] = useState<string>(initialSignature || '');

  // Track dimensions
  const [canvasDimensions, setCanvasDimensions] = useState({ width: 500, height });

  // Update canvas size to match container responsive width
  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const newWidth = Math.max(300, Math.floor(rect.width));
        setCanvasDimensions({ width: newWidth, height });
      }
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, [height]);

  // Redraw all strokes on canvas
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvasDimensions.width * dpr;
    canvas.height = canvasDimensions.height * dpr;
    ctx.scale(dpr, dpr);

    // Fill clean off-white / light slate background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvasDimensions.width, canvasDimensions.height);

    // Draw baseline guideline
    const baselineY = canvasDimensions.height - 45;
    ctx.save();
    ctx.strokeStyle = '#cbd5e1'; // slate-300
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(40, baselineY);
    ctx.lineTo(canvasDimensions.width - 24, baselineY);
    ctx.stroke();
    ctx.restore();

    // Draw "X" signature indicator
    ctx.save();
    ctx.fillStyle = '#94a3b8'; // slate-400
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('✕', 20, baselineY + 2);
    ctx.font = '10px sans-serif';
    ctx.fillText('Customer Signature', 44, baselineY + 16);
    ctx.restore();

    // Draw date timestamp in corner
    ctx.save();
    ctx.fillStyle = '#94a3b8';
    ctx.font = '9px monospace';
    const dateStr = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
    ctx.textAlign = 'right';
    ctx.fillText(`Verified On: ${dateStr}`, canvasDimensions.width - 24, baselineY + 16);
    ctx.restore();

    if (mode === 'type') {
      if (typedName.trim()) {
        ctx.save();
        ctx.fillStyle = penColor;
        ctx.font = SCRIPT_FONTS[selectedFontIndex].font;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'bottom';
        ctx.fillText(typedName.trim(), 50, baselineY - 6);
        ctx.restore();
      }
      return;
    }

    // Draw all completed strokes
    strokes.forEach((stroke) => {
      if (stroke.points.length === 0) return;
      ctx.save();
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (stroke.points.length === 1) {
        ctx.fillStyle = stroke.color;
        ctx.beginPath();
        ctx.arc(stroke.points[0].x, stroke.points[0].y, stroke.width / 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

        for (let i = 1; i < stroke.points.length - 1; i++) {
          const xc = (stroke.points[i].x + stroke.points[i + 1].x) / 2;
          const yc = (stroke.points[i].y + stroke.points[i + 1].y) / 2;
          ctx.quadraticCurveTo(stroke.points[i].x, stroke.points[i].y, xc, yc);
        }
        const lastIdx = stroke.points.length - 1;
        ctx.lineTo(stroke.points[lastIdx].x, stroke.points[lastIdx].y);
        ctx.stroke();
      }
      ctx.restore();
    });

    // Draw stroke currently being drawn
    if (currentStroke.length > 0) {
      ctx.save();
      ctx.strokeStyle = penColor;
      ctx.lineWidth = penWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (currentStroke.length === 1) {
        ctx.fillStyle = penColor;
        ctx.beginPath();
        ctx.arc(currentStroke[0].x, currentStroke[0].y, penWidth / 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(currentStroke[0].x, currentStroke[0].y);

        for (let i = 1; i < currentStroke.length - 1; i++) {
          const xc = (currentStroke[i].x + currentStroke[i + 1].x) / 2;
          const yc = (currentStroke[i].y + currentStroke[i + 1].y) / 2;
          ctx.quadraticCurveTo(currentStroke[i].x, currentStroke[i].y, xc, yc);
        }
        const lastIdx = currentStroke.length - 1;
        ctx.lineTo(currentStroke[lastIdx].x, currentStroke[lastIdx].y);
        ctx.stroke();
      }
      ctx.restore();
    }
  }, [canvasDimensions, strokes, currentStroke, mode, typedName, selectedFontIndex, penColor, penWidth]);

  // Re-render when dependencies change
  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  // Keep hasSignature state updated
  useEffect(() => {
    if (mode === 'type') {
      const valid = typedName.trim().length > 1;
      setHasSignature(valid);
    } else {
      setHasSignature(strokes.length > 0);
    }
  }, [mode, typedName, strokes]);

  // Calculate coordinates relative to canvas
  const getCoordinates = (e: React.PointerEvent<HTMLCanvasElement>): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
      pressure: e.pressure,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (mode === 'type') return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    e.preventDefault();
    setIsDrawing(true);
    const point = getCoordinates(e);
    setCurrentStroke([point]);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || mode === 'type') return;
    e.preventDefault();
    const point = getCoordinates(e);
    setCurrentStroke((prev) => [...prev, point]);
  };

  const finishDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    if (currentStroke.length > 0) {
      setStrokes((prev) => [...prev, { points: currentStroke, color: penColor, width: penWidth }]);
      setCurrentStroke([]);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    finishDrawing();
  };

  const handlePointerLeave = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    finishDrawing();
  };

  // Undo last stroke
  const handleUndo = () => {
    if (strokes.length > 0) {
      setStrokes((prev) => prev.slice(0, prev.length - 1));
    }
  };

  // Clear all
  const handleClear = () => {
    setStrokes([]);
    setCurrentStroke([]);
    setTypedName('');
    setHasSignature(false);
    setCurrentDataUrl('');
    if (onClear) onClear();
  };

  // Export and Save
  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    setCurrentDataUrl(dataUrl);
    if (onSave) {
      onSave(dataUrl);
    }
  };

  return (
    <div className={`space-y-3 ${className}`}>
      {/* Title & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <PenTool className="w-4 h-4 text-amber-400" />
            <span>{title}</span>
            {required && <span className="text-rose-400 text-xs">*</span>}
          </h4>
          <p className="text-xs text-slate-400">{subtitle}</p>
        </div>

        {/* Draw vs Type Mode Pill Toggle */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setMode('draw')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              mode === 'draw'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PenTool className="w-3 h-3" />
            <span>Draw</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('type')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              mode === 'type'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Type className="w-3 h-3" />
            <span>Type Name</span>
          </button>
        </div>
      </div>

      {/* Mode Specific Controls */}
      {mode === 'draw' ? (
        <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-950/70 px-3 py-2 rounded-xl border border-slate-800/80 text-xs">
          {/* Pen Color Selector */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
              <Palette className="w-3 h-3 text-amber-400" />
              <span>Ink:</span>
            </span>
            <div className="flex items-center gap-1.5">
              {PEN_COLORS.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setPenColor(c.value)}
                  className={`w-5 h-5 rounded-full ${c.preview} border-2 transition-all ${
                    penColor === c.value
                      ? 'border-amber-400 scale-110 shadow-sm'
                      : 'border-slate-700 opacity-60 hover:opacity-100'
                  }`}
                  title={c.label}
                />
              ))}
            </div>
          </div>

          {/* Stroke Width Selector */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-[11px] font-medium">Width:</span>
            <div className="flex items-center gap-1">
              {PEN_WIDTHS.map((w) => (
                <button
                  key={w.value}
                  type="button"
                  onClick={() => setPenWidth(w.value)}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    penWidth === w.value
                      ? 'bg-slate-800 text-amber-400 font-bold border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {w.label}
                </button>
              ))}
            </div>
          </div>

          {/* Stroke Actions: Undo & Clear */}
          <div className="flex items-center gap-1.5 ml-auto">
            <button
              type="button"
              onClick={handleUndo}
              disabled={strokes.length === 0}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 disabled:opacity-30 disabled:pointer-events-none text-xs transition-colors"
              title="Undo last pen stroke"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Undo</span>
            </button>
            <button
              type="button"
              onClick={handleClear}
              disabled={strokes.length === 0 && !hasSignature}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 disabled:opacity-30 disabled:pointer-events-none text-xs transition-colors"
              title="Clear canvas"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>
        </div>
      ) : (
        /* Typed Signature Setup */
        <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800/80 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <label className="text-xs text-slate-400 shrink-0">Signer Full Legal Name:</label>
            <input
              type="text"
              value={typedName}
              onChange={(e) => setTypedName(e.target.value)}
              placeholder="e.g., Robert Vance"
              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap text-xs">
            <span className="text-slate-400 text-[11px]">Font Style:</span>
            {SCRIPT_FONTS.map((font, idx) => (
              <button
                key={font.name}
                type="button"
                onClick={() => setSelectedFontIndex(idx)}
                className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                  selectedFontIndex === idx
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                {font.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Canvas Drawing Container */}
      <div
        ref={containerRef}
        className="relative w-full rounded-2xl overflow-hidden border-2 border-slate-700/80 bg-white shadow-inner select-none transition-all focus-within:border-amber-400"
        style={{ height }}
      >
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerLeave}
          className="w-full h-full block cursor-crosshair touch-none"
          style={{ width: '100%', height: `${height}px` }}
        />

        {/* Live Placeholder when canvas is empty */}
        {!hasSignature && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <span className="text-slate-400/60 font-medium text-xs sm:text-sm tracking-wide">
              {mode === 'draw'
                ? 'Touch or click and drag here to sign'
                : 'Type customer legal name above to preview signature'}
            </span>
          </div>
        )}
      </div>

      {/* Bottom Status & Save Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div className="flex items-center gap-2 text-xs">
          {hasSignature ? (
            <span className="text-emerald-400 font-semibold flex items-center gap-1.5 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
              <Check className="w-3.5 h-3.5" />
              <span>Signature ready for customer sign-off</span>
            </span>
          ) : (
            <span className="text-amber-400/90 flex items-center gap-1.5 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Awaiting customer signature</span>
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-300 transition-colors"
            >
              Cancel
            </button>
          )}

          {onSave && (
            <button
              type="button"
              onClick={handleSave}
              disabled={!hasSignature}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40 disabled:pointer-events-none shadow-lg shadow-emerald-950/40 transition-all"
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Confirm & Save Signature</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
