import React, { useState } from 'react';
import {
  Users,
  Lock,
  Sparkles,
  Calendar,
  Clock,
  MapPin,
  Navigation,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Check,
  Truck,
  Wrench,
  Layers,
} from 'lucide-react';
import { SubscriptionTier, Technician, Job, Van } from '../types';
import { SUBSCRIPTION_PLANS } from '../data/subscriptionPlans';

interface TechDispatchPaywallProps {
  currentTier: SubscriptionTier;
  techs: Technician[];
  jobs: Job[];
  vans: Van[];
  onSelectTier: (tier: SubscriptionTier) => void;
  onOpenSubscriptionModal: () => void;
}

export const TechDispatchPaywall: React.FC<TechDispatchPaywallProps> = ({
  currentTier,
  techs,
  jobs,
  vans,
  onSelectTier,
  onOpenSubscriptionModal,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const proPlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'pro') || SUBSCRIPTION_PLANS[2];

  const previewJobs = jobs.slice(0, 4);

  return (
    <div className="space-y-8 animate-in fade-in duration-200 pb-12">
      {/* Hero Paywall Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/50 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-400 text-xs font-black uppercase tracking-wider mb-3">
            <Lock className="w-3.5 h-3.5" />
            <span>Master Pro &amp; Titan Enterprise Feature</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight flex items-center gap-3">
            <span className="p-2 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Users className="w-7 h-7 sm:w-8 h-8" />
            </span>
            <span>Technician Dispatch Board &amp; Fleet Scheduling</span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Coordinate your entire field team in real-time. 
            <span className="text-amber-400 font-bold"> Master Pro Fleet</span> unlocks live technician route tracking, emergency dispatch assignment, job progress boards, before/after photo history, and turn-in reconciliation.
          </p>

          {/* Quick Value Props */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Live Dispatch Board</div>
                <div className="text-[10px] text-slate-400">Drag &amp; drop routing</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Status Tracking</div>
                <div className="text-[10px] text-slate-400">En Route, On Site, Done</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Navigation className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Emergency Routing</div>
                <div className="text-[10px] text-slate-400">Nearest tech assignment</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Turn-In Approval</div>
                <div className="text-[10px] text-slate-400">Cash &amp; job sign-off</div>
              </div>
            </div>
          </div>

          {/* CTA Row */}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSelectTier('pro')}
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Unlock Tech Dispatch (Upgrade to Master Pro)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenSubscriptionModal}
              className="px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors border border-slate-700"
            >
              Compare All 4 Plans
            </button>

            {/* Quick 1-Click Demo Simulator */}
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950/90 border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mr-1">Demo:</span>
              <button
                onClick={() => onSelectTier('free')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'free' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Free
              </button>
              <button
                onClick={() => onSelectTier('standard')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'standard' ? 'bg-blue-600 text-white' : 'text-blue-400 hover:text-blue-300'
                }`}
              >
                Standard
              </button>
              <button
                onClick={() => onSelectTier('pro')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'pro' ? 'bg-amber-500 text-slate-950' : 'text-amber-400 hover:text-amber-300'
                }`}
              >
                Pro
              </button>
              <button
                onClick={() => onSelectTier('enterprise')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'enterprise' ? 'bg-purple-600 text-white' : 'text-purple-400 hover:text-purple-300'
                }`}
              >
                Enterprise
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Teaser Preview: Locked Dispatch Schedule Interface */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Live Field Dispatch Schedule Preview</span>
            </h3>
            <p className="text-xs text-slate-400">
              Active schedule board for {techs.length} field plumbers across {jobs.length} service tickets.
            </p>
          </div>
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
            <Lock className="w-3 h-3" />
            <span>Subscriber Locked</span>
          </span>
        </div>

        {/* Blurred Teaser Board with Floating Unlock Pill */}
        <div className="relative rounded-xl border border-slate-800 overflow-hidden bg-slate-950/70">
          <div className="filter blur-[2px] opacity-40 pointer-events-none p-4 space-y-3">
            {previewJobs.map((job) => (
              <div
                key={job.id}
                className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded bg-slate-800 text-blue-400">
                    <Wrench className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-white">{job.customerName}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {job.address} • {job.serviceType}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4 font-mono">
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[11px]">
                    {job.status}
                  </span>
                  <span className="text-white font-bold">${job.estimateAmount.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Overlay CTA */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs text-center space-y-3">
            <div className="p-3 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 shadow-xl">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white">
                Unlock Tech Dispatch &amp; Scheduling on Master Pro
              </h4>
              <p className="text-xs text-slate-300 max-w-md mt-1">
                Assign jobs, monitor technician drive times, review before/after repair photos, and approve daily turn-in collections.
              </p>
            </div>
            <button
              onClick={() => onSelectTier('pro')}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2"
            >
              <span>Activate Master Pro Plan ($95/mo)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
