import React, { useState } from 'react';
import {
  Users,
  MapPin,
  Calendar,
  Clock,
  Phone,
  Navigation,
  AlertCircle,
  CheckCircle2,
  Plus,
  Truck,
  DollarSign,
  ChevronRight,
  ShieldCheck,
  Compass,
  X,
  FileText,
  Images,
  History,
  ArrowLeftRight,
  Eye,
  Upload,
  Wrench,
  AlertTriangle,
  Check,
  PenTool,
} from 'lucide-react';
import { Technician, Job, Van, HistoricalRepairPhoto, CustomerSignOff, SubscriptionTier } from '../types';
import { CustomerSignOffModal } from './CustomerSignOffModal';
import { TechDispatchPaywall } from './TechDispatchPaywall';

interface TechSchedulerProps {
  techs: Technician[];
  jobs: Job[];
  vans: Van[];
  onUpdateTechStatus: (techId: string, newStatus: Technician['status']) => void;
  onUpdateJobStatus: (jobId: string, newStatus: Job['status']) => void;
  onDispatchNewJob: (job: Omit<Job, 'id'>) => void;
  onAddHistoricalPhoto?: (jobId: string, photo: HistoricalRepairPhoto) => void;
  onSaveJobSignOff?: (jobId: string, signOff: CustomerSignOff) => void;
  onNavigateToDrive?: () => void;
  subscriptionTier?: SubscriptionTier;
  onSelectTier?: (tier: SubscriptionTier) => void;
  onOpenSubscriptionModal?: () => void;
}

export const TechScheduler: React.FC<TechSchedulerProps> = ({
  techs,
  jobs,
  vans,
  onUpdateTechStatus,
  onUpdateJobStatus,
  onDispatchNewJob,
  onAddHistoricalPhoto,
  onSaveJobSignOff,
  onNavigateToDrive,
  subscriptionTier = 'free',
  onSelectTier = () => {},
  onOpenSubscriptionModal = () => {},
}) => {
  // If user is on Free or Standard tier, render the catchy Tech Dispatch PRO paywall
  if (subscriptionTier === 'free' || subscriptionTier === 'standard') {
    return (
      <TechDispatchPaywall
        currentTier={subscriptionTier}
        techs={techs}
        jobs={jobs}
        vans={vans}
        onSelectTier={onSelectTier}
        onOpenSubscriptionModal={onOpenSubscriptionModal}
      />
    );
  }
  const [viewMode, setViewMode] = useState<'schedule' | 'map'>('schedule');
  const [showDispatchModal, setShowDispatchModal] = useState<boolean>(false);
  const [selectedTechFilter, setSelectedTechFilter] = useState<string>('all');

  // Historical Photo Gallery & Comparison State
  const [selectedJobForHistory, setSelectedJobForHistory] = useState<Job | null>(null);
  const [selectedHistoricalIndex, setSelectedHistoricalIndex] = useState<number>(0);
  const [historyTab, setHistoryTab] = useState<'compare' | 'timeline' | 'add'>('compare');
  const [zoomedPhotoUrl, setZoomedPhotoUrl] = useState<string | null>(null);

  // Customer Sign-Off Modal State
  const [signOffModalJob, setSignOffModalJob] = useState<Job | null>(null);
  const [showSignOffModal, setShowSignOffModal] = useState<boolean>(false);

  const handleOpenSignOff = (job: Job) => {
    setSignOffModalJob(job);
    setShowSignOffModal(true);
  };

  const handleConfirmSignOff = (signOff: CustomerSignOff, jobId?: string) => {
    const targetId = jobId || signOffModalJob?.id;
    if (targetId && onSaveJobSignOff) {
      onSaveJobSignOff(targetId, signOff);
    } else if (targetId) {
      onUpdateJobStatus(targetId, 'completed');
    }
    setShowSignOffModal(false);
    setSignOffModalJob(null);
  };

  // New historical photo form state
  const [newPhotoTitle, setNewPhotoTitle] = useState('');
  const [newPhotoDate, setNewPhotoDate] = useState(
    new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  );
  const [newPhotoNotes, setNewPhotoNotes] = useState('');
  const [newPhotoParts, setNewPhotoParts] = useState('');
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoStatus, setNewPhotoStatus] = useState<HistoricalRepairPhoto['status']>('fixed');
  const [addPhotoSuccess, setAddPhotoSuccess] = useState(false);

  // Dispatch Form State
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [address, setAddress] = useState('');
  const [timeSlot, setTimeSlot] = useState('02:00 PM - 04:00 PM');
  const [urgency, setUrgency] = useState<Job['urgency']>('emergency');
  const [assignedTechId, setAssignedTechId] = useState(techs[0]?.id || 'tech-1');
  const [issueSummary, setIssueSummary] = useState('');

  const filteredJobs = jobs.filter(
    (job) => selectedTechFilter === 'all' || job.assignedTechId === selectedTechFilter
  );

  const handleDispatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim() || !address.trim()) return;

    const assignedTech = techs.find((t) => t.id === assignedTechId) || techs[0];

    onDispatchNewJob({
      customerName: custName.trim(),
      customerPhone: custPhone.trim() || '(555) 000-0000',
      address: address.trim(),
      timeSlot,
      urgency,
      status: 'dispatched',
      assignedTechId: assignedTech.id,
      assignedTechName: assignedTech.name,
      assignedVanName: assignedTech.assignedVanName,
      issueSummary: issueSummary.trim() || 'Urgent plumbing inspection & leak diagnostic',
      estimateTotal: 250.0,
    });

    // Reset
    setCustName('');
    setCustPhone('');
    setAddress('');
    setIssueSummary('');
    setShowDispatchModal(false);
  };

  const getStatusBadge = (status: Technician['status']) => {
    switch (status) {
      case 'on_site':
        return { label: 'ON SITE', bg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' };
      case 'en_route':
        return { label: 'EN ROUTE', bg: 'bg-blue-500/20 text-blue-400 border-blue-500/30' };
      case 'at_supply_house':
        return { label: 'SUPPLY HOUSE', bg: 'bg-purple-500/20 text-purple-400 border-purple-500/30' };
      case 'available':
        return { label: 'AVAILABLE', bg: 'bg-slate-500/20 text-slate-300 border-slate-500/30' };
      case 'off_duty':
        return { label: 'OFF DUTY', bg: 'bg-rose-500/20 text-rose-400 border-rose-500/30' };
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex flex-wrap items-center gap-2">
                <span>Technician Tracking & Dispatch Board</span>
                {subscriptionTier === 'enterprise' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[11px] font-bold">
                    👑 Titan Enterprise
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-bold">
                    ⭐ Master Pro Active
                  </span>
                )}
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-400 border border-sky-500/30 text-[11px] font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span>
                  Offline Cached
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Monitor field techs, live work orders, and assign emergency calls in real-time.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center gap-1 text-xs">
              <button
                onClick={() => setViewMode('schedule')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                  viewMode === 'schedule'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Schedule Board
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                  viewMode === 'map'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Fleet Radar Map
              </button>
            </div>

            <button
              onClick={() => setShowDispatchModal(true)}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center gap-1.5 shadow-md shadow-amber-500/20"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Dispatch Job</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tech Live Status Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {techs.map((tech) => {
          const badge = getStatusBadge(tech.status);
          return (
            <div
              key={tech.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3 relative overflow-hidden"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={tech.avatar}
                    alt={tech.name}
                    className="w-11 h-11 rounded-xl object-cover border-2 border-slate-700 shrink-0"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-white">{tech.name}</h3>
                    <div className="text-[11px] text-amber-400/90 font-mono flex items-center gap-1">
                      <Truck className="w-3 h-3 text-slate-400" />
                      <span>{tech.assignedVanName.split(' - ')[0]}</span>
                    </div>
                  </div>
                </div>

                <span
                  className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${badge.bg}`}
                >
                  {badge.label}
                </span>
              </div>

              {/* Current Location / ETA */}
              <div className="p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-xs">
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  Current Assignment
                </div>
                <div className="text-slate-200 font-medium truncate mt-0.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate">{tech.currentJobAddress || 'Main Shop Bay'}</span>
                </div>
                {tech.etaMinutes !== undefined && tech.etaMinutes > 0 && (
                  <div className="text-[10px] text-blue-400 mt-1 font-mono">
                    ETA: ~{tech.etaMinutes} mins in transit
                  </div>
                )}
              </div>

              {/* Performance numbers today */}
              <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/80">
                <div className="text-slate-400">
                  Today: <strong className="text-white">{tech.jobsCompletedToday} Jobs</strong>
                </div>
                <div className="text-emerald-400 font-bold font-mono">
                  ${tech.todayRevenue.toLocaleString()} billed
                </div>
              </div>

              {/* Fast Status Change Select */}
              <div className="pt-1">
                <select
                  value={tech.status}
                  onChange={(e) => onUpdateTechStatus(tech.id, e.target.value as Technician['status'])}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold text-slate-300 focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  <option value="on_site">Mark: On Site</option>
                  <option value="en_route">Mark: En Route</option>
                  <option value="at_supply_house">Mark: At Supply House</option>
                  <option value="available">Mark: Available</option>
                  <option value="off_duty">Mark: Off Duty</option>
                </select>
              </div>
            </div>
          );
        })}
      </div>

      {/* Schedule Board or Live Map View */}
      {viewMode === 'schedule' ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>Today's Field Dispatch Schedule</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Active work orders and emergency leak response dispatch.
              </p>
            </div>

            {/* Filter by Tech */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">Filter Tech:</span>
              <select
                value={selectedTechFilter}
                onChange={(e) => setSelectedTechFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="all">All Technicians</option>
                {techs.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Job Dispatch Cards */}
          <div className="space-y-3">
            {filteredJobs.map((job) => (
              <div
                key={job.id}
                className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                {/* Left: Customer & Address */}
                <div className="space-y-1.5 min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        job.urgency === 'emergency'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : job.urgency === 'high'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      }`}
                    >
                      {job.urgency}
                    </span>

                    <span className="text-xs font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      {job.timeSlot}
                    </span>

                    <h3 className="text-sm font-bold text-white">{job.customerName}</h3>
                  </div>

                  <div className="text-xs text-slate-300 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{job.address}</span>
                    <span className="text-slate-600">•</span>
                    <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="text-slate-400 font-mono">{job.customerPhone}</span>
                  </div>

                  <p className="text-xs text-slate-400 italic">
                    "{job.issueSummary}"
                  </p>

                  {/* Site History & Photo Gallery Trigger */}
                  <div className="flex items-center gap-2 pt-1.5 flex-wrap">
                    <button
                      onClick={() => {
                        setSelectedJobForHistory(job);
                        setSelectedHistoricalIndex(0);
                        setHistoryTab('compare');
                      }}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all shadow-sm"
                    >
                      <Images className="w-3.5 h-3.5 text-amber-400" />
                      <span>Compare Past Repairs ({job.historicalPhotos?.length || 0})</span>
                    </button>

                    {job.currentLeakPhoto && (
                      <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                        <Check className="w-3 h-3" />
                        <span>Current Leak Photo On File</span>
                      </span>
                    )}

                    {job.signOff && (
                      <button
                        onClick={() => handleOpenSignOff(job)}
                        className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 bg-emerald-500/10 hover:bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/20 transition-colors"
                        title="Customer signature verified on file - Click to view certificate"
                      >
                        <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        <span>Signed by {job.signOff.signerName}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Center: Tech Assignment */}
                <div className="lg:w-48 p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs shrink-0">
                  <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                    Assigned Rig
                  </div>
                  <div className="font-bold text-white mt-0.5">{job.assignedTechName}</div>
                  <div className="text-[11px] text-amber-400 font-mono">{job.assignedVanName}</div>
                </div>

                {/* Right: Estimate & Status Transitions */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 shrink-0 lg:w-80 justify-between">
                  <div className="text-left sm:text-right">
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Estimate Quote</div>
                    <div className="text-sm font-black text-emerald-400 font-mono">
                      ${job.estimateTotal ? job.estimateTotal.toFixed(2) : '350.00'}
                    </div>
                  </div>

                  {/* Status Action Buttons & Customer Sign-Off */}
                  <div className="flex items-center gap-1.5 flex-wrap justify-end">
                    {job.status === 'scheduled' && (
                      <button
                        onClick={() => onUpdateJobStatus(job.id, 'dispatched')}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white"
                      >
                        Dispatch Tech
                      </button>
                    )}

                    {job.status === 'dispatched' && (
                      <button
                        onClick={() => onUpdateJobStatus(job.id, 'en_route')}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950"
                      >
                        Mark En Route
                      </button>
                    )}

                    {job.status === 'en_route' && (
                      <button
                        onClick={() => onUpdateJobStatus(job.id, 'in_progress')}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950"
                      >
                        Start on Site
                      </button>
                    )}

                    {job.status === 'in_progress' && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleOpenSignOff(job)}
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center gap-1 shadow-sm transition-all"
                          title="Capture customer sign-off on completed repair"
                        >
                          <PenTool className="w-3.5 h-3.5" />
                          <span>Sign-Off & Complete</span>
                        </button>
                        <button
                          onClick={() => onUpdateJobStatus(job.id, 'completed')}
                          className="px-2 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-300 transition-colors"
                          title="Complete without customer signature"
                        >
                          Done
                        </button>
                      </div>
                    )}

                    {job.status === 'completed' && (
                      <div className="flex items-center gap-1.5">
                        {job.signOff ? (
                          <button
                            onClick={() => handleOpenSignOff(job)}
                            className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30 flex items-center gap-1 transition-all"
                            title="View verified customer sign-off certificate"
                          >
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Signed ({job.signOff.signerName.split(' ')[0]})</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleOpenSignOff(job)}
                            className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 flex items-center gap-1 transition-all"
                            title="Capture customer signature"
                          >
                            <PenTool className="w-3.5 h-3.5 text-amber-400" />
                            <span>Capture Sign-Off</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Visual Fleet Radar Map */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Compass className="w-4 h-4 text-amber-400" />
                <span>Live GPS Fleet Dispatch Radar</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Simulated real-time service radius, active vans, and customer job coordinates.
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              All Rigs Online (4/4)
            </span>
          </div>

          {/* Interactive Tactical Map Visual Container */}
          <div className="relative aspect-[16/9] sm:aspect-[21/9] rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center p-6">
            {/* Map Grid Pattern */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 1px 1px, #f59e0b 1px, transparent 0)',
                backgroundSize: '36px 36px',
              }}
            />

            {/* Radar Sweep Circle */}
            <div className="absolute w-96 h-96 rounded-full border border-amber-500/20 pointer-events-none" />
            <div className="absolute w-64 h-64 rounded-full border border-dashed border-amber-500/30 pointer-events-none" />

            {/* Map Simulated Markers */}
            {/* Van 1 Alex Pin */}
            <div className="absolute top-[28%] left-[32%] z-10 flex flex-col items-center">
              <div className="w-7 h-7 rounded-xl bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shadow-lg shadow-amber-500/40 animate-bounce">
                🚐 1
              </div>
              <div className="mt-1 px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] text-white font-bold whitespace-nowrap shadow">
                Alex Penchev (On Site)
              </div>
            </div>

            {/* Van 2 Marco Pin */}
            <div className="absolute top-[58%] left-[64%] z-10 flex flex-col items-center">
              <div className="w-7 h-7 rounded-xl bg-blue-500 text-white font-black text-xs flex items-center justify-center shadow-lg shadow-blue-500/40">
                🚐 2
              </div>
              <div className="mt-1 px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] text-white font-bold whitespace-nowrap shadow">
                Marco R. (En Route • 12m)
              </div>
            </div>

            {/* Van 3 Dmitry Pin */}
            <div className="absolute top-[35%] left-[80%] z-10 flex flex-col items-center">
              <div className="w-7 h-7 rounded-xl bg-purple-500 text-white font-black text-xs flex items-center justify-center shadow-lg shadow-purple-500/40">
                📦 3
              </div>
              <div className="mt-1 px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] text-white font-bold whitespace-nowrap shadow">
                Dmitry (Ferguson Supply)
              </div>
            </div>

            {/* Main Shop HQ */}
            <div className="absolute bottom-[20%] left-[20%] z-10 flex flex-col items-center">
              <div className="w-8 h-8 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center shadow-lg shadow-emerald-500/40">
                🏢 HQ
              </div>
              <div className="mt-1 px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] text-white font-bold whitespace-nowrap shadow">
                Main Shop & Warehouse
              </div>
            </div>

            <div className="absolute bottom-3 left-3 bg-slate-900/90 border border-slate-800 rounded-lg p-2 text-[10px] text-slate-400 font-mono backdrop-blur">
              LAT: 41.8781° N | LON: 87.6298° W | SERVICE RADIUS: 35 MILES
            </div>
          </div>
        </div>
      )}

      {/* Job Details & Historical Site Repair Gallery Modal */}
      {selectedJobForHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-5xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-start justify-between gap-3 bg-slate-950/60 shrink-0">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span
                    className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                      selectedJobForHistory.urgency === 'emergency'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : selectedJobForHistory.urgency === 'high'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                    }`}
                  >
                    {selectedJobForHistory.urgency}
                  </span>
                  <span className="text-xs font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {selectedJobForHistory.timeSlot}
                  </span>
                  <h3 className="text-base sm:text-lg font-black text-white truncate">
                    {selectedJobForHistory.customerName}
                  </h3>
                </div>
                <div className="text-xs text-slate-300 flex items-center gap-1.5 flex-wrap">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{selectedJobForHistory.address}</span>
                  <span className="text-slate-600">•</span>
                  <Truck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="text-slate-400">{selectedJobForHistory.assignedTechName} ({selectedJobForHistory.assignedVanName.split(' - ')[0]})</span>
                </div>
              </div>

              <button
                onClick={() => setSelectedJobForHistory(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Sub-Navigation Tabs */}
            <div className="px-4 pt-3 border-b border-slate-800 bg-slate-950/40 flex items-center gap-2 shrink-0 overflow-x-auto">
              <button
                onClick={() => setHistoryTab('compare')}
                className={`flex items-center gap-1.5 px-3.5 py-2 border-b-2 text-xs font-bold transition-all whitespace-nowrap ${
                  historyTab === 'compare'
                    ? 'border-amber-500 text-amber-400'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span>Side-by-Side Comparison</span>
              </button>

              <button
                onClick={() => setHistoryTab('timeline')}
                className={`flex items-center gap-1.5 px-3.5 py-2 border-b-2 text-xs font-bold transition-all whitespace-nowrap ${
                  historyTab === 'timeline'
                    ? 'border-amber-500 text-amber-400'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>Site History Timeline ({selectedJobForHistory.historicalPhotos?.length || 0})</span>
              </button>

              <button
                onClick={() => setHistoryTab('add')}
                className={`flex items-center gap-1.5 px-3.5 py-2 border-b-2 text-xs font-bold transition-all whitespace-nowrap ${
                  historyTab === 'add'
                    ? 'border-amber-500 text-amber-400'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Log New Site Photo</span>
              </button>
            </div>

            {/* Modal Content Body */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
              {/* TAB 1: SIDE-BY-SIDE COMPARISON */}
              {historyTab === 'compare' && (
                <div className="space-y-4">
                  {/* Past Repair Selector Pills */}
                  {selectedJobForHistory.historicalPhotos && selectedJobForHistory.historicalPhotos.length > 0 ? (
                    <div>
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1.5">
                        <History className="w-3.5 h-3.5 text-amber-400" />
                        <span>Select Past Visit to Compare Against Today:</span>
                      </div>
                      <div className="flex items-center gap-2 overflow-x-auto pb-1">
                        {selectedJobForHistory.historicalPhotos.map((photo, idx) => (
                          <button
                            key={photo.id}
                            onClick={() => setSelectedHistoricalIndex(idx)}
                            className={`flex items-center gap-2 p-1.5 pr-3 rounded-xl border text-xs font-bold transition-all shrink-0 ${
                              selectedHistoricalIndex === idx
                                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <img
                              src={photo.photoUrl}
                              alt={photo.title}
                              className="w-7 h-7 rounded-lg object-cover"
                            />
                            <div className="text-left">
                              <div>{photo.date}</div>
                              <div className="text-[10px] text-slate-500 font-normal">{photo.title}</div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : null}

                  {/* Two Column Split Comparison */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Left: Today's Current Active Leak */}
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-black uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                            Current Active Leak (Today)
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">Job #{selectedJobForHistory.id}</span>
                        </div>

                        {/* Current Photo View */}
                        <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 border border-slate-800 group">
                          <img
                            src={selectedJobForHistory.currentLeakPhoto || 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80'}
                            alt="Current leak condition"
                            className="w-full h-full object-cover"
                          />
                          <button
                            onClick={() => setZoomedPhotoUrl(selectedJobForHistory.currentLeakPhoto || 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80')}
                            className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-white text-xs font-semibold backdrop-blur flex items-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Zoom</span>
                          </button>
                        </div>
                      </div>

                      <div className="space-y-1.5 text-xs">
                        <div className="font-bold text-white">{selectedJobForHistory.issueSummary}</div>
                        <div className="text-[11px] text-slate-400">
                          Reported: Active spray observed by customer. Assigned to {selectedJobForHistory.assignedTechName}.
                        </div>
                        <div className="pt-1 flex items-center justify-between text-[11px] text-emerald-400 font-mono font-bold">
                          <span>Quote: ${selectedJobForHistory.estimateTotal ? selectedJobForHistory.estimateTotal.toFixed(2) : '350.00'}</span>
                          <span className="text-amber-400 uppercase">{selectedJobForHistory.status}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right: Selected Past Repair at this Site */}
                    {selectedJobForHistory.historicalPhotos && selectedJobForHistory.historicalPhotos[selectedHistoricalIndex] ? (
                      (() => {
                        const past = selectedJobForHistory.historicalPhotos[selectedHistoricalIndex];
                        return (
                          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                                  <History className="w-3.5 h-3.5" />
                                  Past Site Repair ({past.date})
                                </span>
                                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-bold uppercase">
                                  {past.status}
                                </span>
                              </div>

                              {/* Past Photo View */}
                              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 border border-slate-800 group">
                                <img
                                  src={past.photoUrl}
                                  alt={past.title}
                                  className="w-full h-full object-cover"
                                />
                                <button
                                  onClick={() => setZoomedPhotoUrl(past.photoUrl)}
                                  className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-white text-xs font-semibold backdrop-blur flex items-center gap-1"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  <span>Zoom</span>
                                </button>
                              </div>
                            </div>

                            <div className="space-y-1.5 text-xs">
                              <div className="font-bold text-white flex items-center justify-between">
                                <span>{past.title}</span>
                                <span className="text-[10px] text-slate-400 font-mono">Tech: {past.technicianName}</span>
                              </div>

                              <div className="text-[11px] text-slate-300 leading-relaxed bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                                <strong className="text-slate-400">Past Notes: </strong>
                                {past.repairNotes}
                              </div>

                              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                                <span className="text-[10px] text-slate-400 font-bold">Parts Previously Installed:</span>
                                {past.partsUsed.map((part, pIdx) => (
                                  <span
                                    key={pIdx}
                                    className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono"
                                  >
                                    {part}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      <div className="p-8 rounded-xl bg-slate-950 border border-slate-800 flex flex-col items-center justify-center text-center text-slate-400">
                        <History className="w-8 h-8 text-slate-600 mb-2" />
                        <h4 className="text-sm font-bold text-white">No Prior Repair Photos Recorded</h4>
                        <p className="text-xs text-slate-500 mt-1 max-w-xs">
                          This is the first visit logged for this address. Use the "Log New Site Photo" tab to upload initial baseline pictures!
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Technician Diagnostic Comparison Insight Banner */}
                  <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5 text-xs">
                    <Wrench className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-amber-400 font-bold">Contractor Site Comparison Insight: </strong>
                      <span className="text-slate-300">
                        Technicians can cross-verify whether the current leak is a failure of previous work under warranty, or a new pinhole occurring downstream due to water pressure or pipe aging.
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: HISTORICAL SITE TIMELINE */}
              {historyTab === 'timeline' && (
                <div className="space-y-3">
                  <div className="text-xs text-slate-400 flex items-center justify-between">
                    <span>Complete property repair timeline for {selectedJobForHistory.address}:</span>
                    <span className="font-mono text-amber-400 font-bold">
                      {selectedJobForHistory.historicalPhotos?.length || 0} Total Records
                    </span>
                  </div>

                  {selectedJobForHistory.historicalPhotos && selectedJobForHistory.historicalPhotos.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {selectedJobForHistory.historicalPhotos.map((photo, idx) => (
                        <div
                          key={photo.id}
                          className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between"
                        >
                          <div className="relative aspect-[16/10] bg-slate-900 group">
                            <img
                              src={photo.photoUrl}
                              alt={photo.title}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-slate-950/80 text-[10px] font-bold text-amber-400 backdrop-blur border border-slate-800">
                              {photo.date}
                            </div>
                            <button
                              onClick={() => setZoomedPhotoUrl(photo.photoUrl)}
                              className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-slate-900/80 text-white hover:bg-slate-800 backdrop-blur"
                              title="Zoom Photo"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="p-3 space-y-2 text-xs flex-1 flex flex-col justify-between">
                            <div>
                              <div className="font-bold text-white flex items-center justify-between">
                                <span>{photo.title}</span>
                                <span className="text-[10px] text-emerald-400 font-semibold">{photo.status}</span>
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                Serviced by: {photo.technicianName}
                              </div>
                              <p className="text-slate-300 text-[11px] mt-1.5 leading-relaxed">
                                {photo.repairNotes}
                              </p>
                            </div>

                            <div className="pt-2 border-t border-slate-900">
                              <div className="text-[10px] text-slate-500 font-bold mb-1">Parts Used:</div>
                              <div className="flex flex-wrap gap-1">
                                {photo.partsUsed.map((p, pIdx) => (
                                  <span
                                    key={pIdx}
                                    className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300"
                                  >
                                    {p}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center text-slate-400">
                      <p>No past visits recorded for this property yet.</p>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: LOG NEW SITE PHOTO */}
              {historyTab === 'add' && (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 max-w-2xl mx-auto">
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span>Log a New Photo to Property History</span>
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Save a baseline photo, post-repair verification, or prior leak snapshot for {selectedJobForHistory.address}.
                    </p>
                  </div>

                  {addPhotoSuccess && (
                    <div className="p-2.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs flex items-center gap-2">
                      <Check className="w-4 h-4" />
                      <span>Photo added to property history!</span>
                    </div>
                  )}

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!newPhotoTitle.trim()) return;

                      const partsArray = newPhotoParts
                        .split(',')
                        .map((p) => p.trim())
                        .filter(Boolean);

                      const newPhoto: HistoricalRepairPhoto = {
                        id: `hist-${Date.now()}`,
                        date: newPhotoDate,
                        photoUrl: newPhotoUrl.trim() || 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80',
                        title: newPhotoTitle.trim(),
                        technicianName: selectedJobForHistory.assignedTechName,
                        partsUsed: partsArray.length > 0 ? partsArray : ['Coupling', 'Teflon tape'],
                        repairNotes: newPhotoNotes.trim() || 'Work verified and pressure tested.',
                        status: newPhotoStatus,
                      };

                      if (onAddHistoricalPhoto) {
                        onAddHistoricalPhoto(selectedJobForHistory.id, newPhoto);
                      }

                      // Update local job state
                      setSelectedJobForHistory({
                        ...selectedJobForHistory,
                        historicalPhotos: [newPhoto, ...(selectedJobForHistory.historicalPhotos || [])],
                      });

                      setAddPhotoSuccess(true);
                      setNewPhotoTitle('');
                      setNewPhotoNotes('');
                      setNewPhotoParts('');
                      setNewPhotoUrl('');
                      setTimeout(() => setAddPhotoSuccess(false), 2500);
                    }}
                    className="space-y-3 text-xs"
                  >
                    <div>
                      <label className="text-slate-400 font-bold uppercase block mb-1">Photo Title / Repair Description</label>
                      <input
                        type="text"
                        required
                        value={newPhotoTitle}
                        onChange={(e) => setNewPhotoTitle(e.target.value)}
                        placeholder="e.g. Post-Repair 3/4 SharkBite 90° Elbow Replacement"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-400 font-bold uppercase block mb-1">Date</label>
                        <input
                          type="text"
                          value={newPhotoDate}
                          onChange={(e) => setNewPhotoDate(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-slate-400 font-bold uppercase block mb-1">Status Tag</label>
                        <select
                          value={newPhotoStatus}
                          onChange={(e) => setNewPhotoStatus(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                        >
                          <option value="fixed">Fixed (Completed Repair)</option>
                          <option value="after">After (Post-Work Photo)</option>
                          <option value="before">Before (Pre-Work Condition)</option>
                          <option value="prior_leak">Prior Leak (Historical Problem)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-400 font-bold uppercase block mb-1">Photo Image URL or Sample</label>
                      <input
                        type="url"
                        value={newPhotoUrl}
                        onChange={(e) => setNewPhotoUrl(e.target.value)}
                        placeholder="https://... (or leave blank to use camera preset photo)"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 font-bold uppercase block mb-1">Parts Installed (Comma Separated)</label>
                      <input
                        type="text"
                        value={newPhotoParts}
                        onChange={(e) => setNewPhotoParts(e.target.value)}
                        placeholder="3/4 SharkBite Elbow, 10ft Type L Copper, PTFE Tape"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 font-bold uppercase block mb-1">Technician Notes & Observations</label>
                      <textarea
                        rows={2}
                        value={newPhotoNotes}
                        onChange={(e) => setNewPhotoNotes(e.target.value)}
                        placeholder="Details of what was repaired, torque specs, pipe wall thickness, water pressure..."
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div className="pt-2 flex justify-end gap-2">
                      <button
                        type="submit"
                        className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center gap-1.5"
                      >
                        <Upload className="w-4 h-4" />
                        <span>Save to Site History</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Lightbox / Zoom Photo Modal */}
      {zoomedPhotoUrl && (
        <div
          onClick={() => setZoomedPhotoUrl(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md cursor-zoom-out animate-in fade-in"
        >
          <div className="relative max-w-4xl max-h-[90vh] rounded-2xl overflow-hidden shadow-2xl border border-slate-700">
            <img
              src={zoomedPhotoUrl}
              alt="High resolution repair photo"
              className="w-full h-full object-contain"
            />
            <button
              onClick={() => setZoomedPhotoUrl(null)}
              className="absolute top-3 right-3 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white backdrop-blur"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Customer Sign-Off Modal */}
      <CustomerSignOffModal
        isOpen={showSignOffModal}
        onClose={() => {
          setShowSignOffModal(false);
          setSignOffModalJob(null);
        }}
        job={signOffModalJob}
        availableJobs={jobs}
        onConfirmSignOff={handleConfirmSignOff}
        onNavigateToDrive={onNavigateToDrive}
      />
    </div>
  );
};
