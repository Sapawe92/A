import React, { useState } from 'react';
import { Smartphone, QrCode, Copy, Check, X, ExternalLink, Globe } from 'lucide-react';

interface TestOnPhoneModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestOnPhoneModal: React.FC<TestOnPhoneModalProps> = ({ isOpen, onClose }) => {
  const [copiedUrl, setCopiedUrl] = useState(false);

  // We offer both the Public Shared URL (best for mobile devices) and the current dev origin
  const sharedUrl = 'https://ais-pre-4bcyj2lhd25hymvqzgloee-89711648349.us-east5.run.app';
  const currentOrigin =
    typeof window !== 'undefined' && window.location.origin.includes('http')
      ? window.location.origin
      : sharedUrl;

  const [useSharedUrl, setUseSharedUrl] = useState(true);

  if (!isOpen) return null;

  const targetUrl = useSharedUrl ? sharedUrl : currentOrigin;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=8&data=${encodeURIComponent(
    targetUrl
  )}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(targetUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4 text-center relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-2 shadow-inner">
            <Smartphone className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-black text-white">Test LeakScan AI on Your Phone</h3>
          <p className="text-xs text-slate-300 mt-1 max-w-xs">
            Scan this QR code with your phone camera to test live leak detection and mobile features.
          </p>
        </div>

        {/* QR Code Container */}
        <div className="space-y-2">
          <div className="bg-white p-3.5 rounded-2xl w-60 h-60 mx-auto shadow-xl flex items-center justify-center border-4 border-amber-400/20">
            <img
              src={qrCodeUrl}
              alt="Scan QR code to open LeakScan on your phone"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Phone Symbol & Status Badge directly in the down side of the QR code image */}
          <div className="flex items-center justify-center gap-2 pt-1">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-400 text-xs font-semibold">
              <Smartphone className="w-3.5 h-3.5 animate-bounce" />
              <span>Point Phone Camera at Code</span>
              <QrCode className="w-3.5 h-3.5 opacity-80" />
            </div>
          </div>
        </div>

        {/* URL selector toggle */}
        <div className="flex items-center justify-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-[11px]">
          <button
            type="button"
            onClick={() => setUseSharedUrl(true)}
            className={`flex-1 py-1 px-2 rounded-md font-semibold transition ${
              useSharedUrl
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Public Mobile Link (Recommended)
          </button>
          <button
            type="button"
            onClick={() => setUseSharedUrl(false)}
            className={`flex-1 py-1 px-2 rounded-md font-semibold transition ${
              !useSharedUrl
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Dev Session Link
          </button>
        </div>

        {/* Direct URL with Copy and Open Buttons */}
        <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-left">
          <div className="min-w-0 flex-1">
            <div className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
              <Globe className="w-3 h-3 text-amber-400" />
              <span>Target Link</span>
            </div>
            <div className="text-xs font-mono text-amber-400 truncate mt-0.5">
              {targetUrl}
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={handleCopy}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 flex items-center gap-1 transition"
              title="Copy URL to clipboard"
            >
              {copiedUrl ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
            <a
              href={targetUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
              title="Open link directly"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="text-left bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 text-[11px] text-slate-300 space-y-1.5">
          <div className="font-bold text-white flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>How to test on your phone:</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">1</span>
            <span>Open your phone's built-in <strong>Camera</strong> app.</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">2</span>
            <span>Aim at the QR code above and tap the yellow banner that appears.</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">3</span>
            <span>Tap <strong>Open Camera</strong> on your phone to scan real pipes, valves, and water heaters!</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
        >
          Close
        </button>
      </div>
    </div>
  );
};
