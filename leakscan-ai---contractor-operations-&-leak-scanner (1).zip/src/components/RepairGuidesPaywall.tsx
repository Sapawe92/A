import React, { useState } from 'react';
import {
  Lock,
  Sparkles,
  Check,
  X,
  ShieldCheck,
  BookOpen,
  PenTool,
  Globe,
  HardDrive,
  Volume2,
  ArrowRight,
  Zap,
  Eye,
  Star,
  Layers,
  Wrench,
  Clock,
} from 'lucide-react';
import { SubscriptionTier, TechLanguage } from '../types';
import { REPAIR_GUIDES } from '../data/repairGuidesData';
import { SUBSCRIPTION_PLANS, FEATURE_COMPARISON_MATRIX } from '../data/subscriptionPlans';
import { LANGUAGES } from '../data/mockData';

interface RepairGuidesPaywallProps {
  currentTier: SubscriptionTier;
  selectedLanguage: TechLanguage;
  onUpgradeToStandard: () => void;
  onSelectTier: (tier: SubscriptionTier) => void;
  onOpenFullModal: () => void;
}

export const RepairGuidesPaywall: React.FC<RepairGuidesPaywallProps> = ({
  currentTier,
  selectedLanguage,
  onUpgradeToStandard,
  onSelectTier,
  onOpenFullModal,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [previewGuideId, setPreviewGuideId] = useState<string | null>(null);

  const selectedLangObj = LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0];
  const standardPlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'standard') || SUBSCRIPTION_PLANS[1];
  const freePlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'free') || SUBSCRIPTION_PLANS[0];

  return (
    <div className="space-y-8 animate-in fade-in duration-200 pb-12">
      {/* Top Standard Subscription Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/40 p-6 sm:p-8 shadow-2xl">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider mb-3">
            <Lock className="w-3.5 h-3.5" />
            <span>Standard Subscriber Feature</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
            Plumbing Repair Guides &amp; Customer Sign-Off
          </h1>

          <p className="text-sm sm:text-base text-slate-300 mt-2.5 leading-relaxed">
            This module is reserved for <span className="text-amber-400 font-bold">Standard Contractor Subscribers</span>. 
            Standardize field repairs across your entire crew, eliminate warranty callbacks, and capture legally-binding customer sign-offs before leaving the job site.
          </p>

          {/* Quick Value Props */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">10+ Procedures</div>
                <div className="text-[10px] text-slate-400">Copper, PEX, Water Heaters</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">7 ESL Languages</div>
                <div className="text-[10px] text-slate-400">Spanish, Bulgarian, Ukrainian</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                <PenTool className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Digital Sign-Off</div>
                <div className="text-[10px] text-slate-400">Customer signature pad</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                <HardDrive className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Google Drive</div>
                <div className="text-[10px] text-slate-400">Auto work order sync</div>
              </div>
            </div>
          </div>

          {/* CTA & Simulator Switcher */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={onUpgradeToStandard}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-400 hover:to-blue-500 text-white font-black text-sm shadow-xl shadow-blue-500/25 flex items-center gap-2 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Unlock Journeyman Standard ($39/mo)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenFullModal}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs transition-colors"
            >
              Compare All 4 Plans
            </button>

            {/* Quick 1-Click Demo Simulator */}
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950/90 border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mr-1">Demo:</span>
              <button
                onClick={() => onSelectTier('free')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'free' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Free
              </button>
              <button
                onClick={() => onSelectTier('standard')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'standard' ? 'bg-blue-600 text-white' : 'text-blue-400 hover:text-blue-300'
                }`}
              >
                Standard
              </button>
              <button
                onClick={() => onSelectTier('pro')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'pro' ? 'bg-amber-500 text-slate-950' : 'text-amber-400 hover:text-amber-300'
                }`}
              >
                Pro
              </button>
              <button
                onClick={() => onSelectTier('enterprise')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'enterprise' ? 'bg-purple-600 text-white' : 'text-purple-400 hover:text-purple-300'
                }`}
              >
                Enterprise
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Standard Subscription Layout: Free vs Standard Comparison */}
      <div>
        <div className="text-center max-w-xl mx-auto mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs font-semibold mb-2">
            Standard Subscription Plans
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white">
            Choose Your Contractor Tier
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Free version covers foundational camera scans and inventory. Upgrade to Standard when you are ready to scale technician quality.
          </p>

          {/* Billing Cycle Toggle */}
          <div className="mt-4 inline-flex items-center gap-3 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                billingCycle === 'monthly' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                billingCycle === 'annual' ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Annual Billing</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                SAVE 20%
              </span>
            </button>
          </div>
        </div>

        {/* 2-Card Direct Free vs Standard Side-by-Side */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {/* Card 1: Free Community (Current) */}
          <div className="rounded-2xl p-6 bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <h3 className="text-lg font-bold text-slate-200">Free Community</h3>
                <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold border border-slate-700">
                  Current Free Tier
                </span>
              </div>
              <p className="text-xs text-slate-400 min-h-[36px]">
                Basic field tools for single technicians and small jobs.
              </p>

              <div className="my-4 py-3 border-y border-slate-800 flex items-baseline gap-1">
                <span className="text-3xl font-black text-white">$0</span>
                <span className="text-xs text-slate-400">/ forever</span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Included in Free:
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>AI Camera Leak Detection (15 scans/mo)</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>1 Van Stock inventory tracking</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Daily Turn-Ins cash &amp; mileage log</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Check className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Technician Dispatch (up to 3 jobs)</span>
                </div>

                <div className="pt-3 border-t border-slate-800/80 mt-3 space-y-2">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-rose-400/80">
                    Locked in Free Version:
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <X className="w-3.5 h-3.5 text-rose-500/70 shrink-0" />
                    <span>Plumbing Repair Guides &amp; SOP Library</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <X className="w-3.5 h-3.5 text-rose-500/70 shrink-0" />
                    <span>7 ESL Language Translations</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <X className="w-3.5 h-3.5 text-rose-500/70 shrink-0" />
                    <span>Customer Digital Sign-Off Pad</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <X className="w-3.5 h-3.5 text-rose-500/70 shrink-0" />
                    <span>Audio Voice Repair Guidance</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              disabled
              className="mt-6 w-full py-2.5 rounded-xl bg-slate-800 text-slate-400 font-bold text-xs cursor-default text-center"
            >
              Current Active Version
            </button>
          </div>

          {/* Card 2: Standard Contractor (Recommended / Subscriber Only) */}
          <div className="relative rounded-2xl p-6 bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/30 border-2 border-amber-500 shadow-xl shadow-amber-500/10 flex flex-col justify-between">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-[11px] font-black uppercase tracking-wider shadow-md">
              Recommended For Field Crews
            </div>

            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <span>Standard Contractor</span>
                  <Sparkles className="w-4 h-4 text-amber-400" />
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-black border border-amber-500/30">
                  Unlocks Repair Guides
                </span>
              </div>
              <p className="text-xs text-slate-300 min-h-[36px]">
                Everything contractors need to eliminate callbacks, translate protocols, and sign off jobs.
              </p>

              <div className="my-4 py-3 border-y border-slate-800/80 flex items-baseline gap-1.5">
                <span className="text-3xl font-black text-amber-400">
                  ${billingCycle === 'annual' ? standardPlan.priceAnnual : standardPlan.priceMonthly}
                </span>
                <span className="text-xs text-slate-400">/ month</span>
                {billingCycle === 'annual' && (
                  <span className="ml-auto text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Billed $288 / year
                  </span>
                )}
              </div>

              <div className="space-y-2 text-xs">
                <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 mb-2">
                  Complete Standard Privileges:
                </div>
                <div className="flex items-center gap-2 text-white font-medium">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Full Repair Guides Library (Copper, PEX, PRV, etc.)</span>
                </div>
                <div className="flex items-center gap-2 text-white font-medium">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>7 ESL Languages (Spanish, Bulgarian, Ukrainian, etc.)</span>
                </div>
                <div className="flex items-center gap-2 text-white font-medium">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Customer Digital Signature Pad &amp; Certificates</span>
                </div>
                <div className="flex items-center gap-2 text-white font-medium">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Hands-free voice audio instructions on site</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Google Drive automated work order sync</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Up to 5 Vans &amp; 12 Field Technicians</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Unlimited AI Leak Scans &amp; Photo Comparisons</span>
                </div>
              </div>
            </div>

            <div className="mt-6 space-y-2">
              <button
                onClick={onUpgradeToStandard}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all"
              >
                <span>Upgrade to Standard Contractor</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => onSelectTier('standard')}
                className="w-full py-2 px-3 rounded-lg text-slate-400 hover:text-amber-400 text-[11px] font-mono flex items-center justify-center gap-1.5 transition-colors"
              >
                <Zap className="w-3 h-3 text-amber-400" />
                <span>Simulate 1-Click Upgrade (Demo)</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Teaser Preview: Locked Repair Guides Catalog */}
      <div className="pt-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <span>Catalog Preview: 10+ Standard Repair Guides</span>
              <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px] font-bold border border-amber-500/30">
                🔒 Subscriber Only
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Browse the library of step-by-step procedures waiting inside the Standard Subscription.
            </p>
          </div>

          <div className="text-xs text-slate-400 hidden sm:flex items-center gap-1.5">
            <span>Viewing in:</span>
            <span className="font-bold text-slate-200">{selectedLangObj.flag} {selectedLangObj.nativeLabel}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {REPAIR_GUIDES.map((guide) => {
            const localized = guide.translations[selectedLanguage] || guide.translations.en;
            return (
              <div
                key={guide.id}
                onClick={onUpgradeToStandard}
                className="group relative rounded-xl p-4 bg-slate-900/60 border border-slate-800/90 hover:border-amber-500/50 transition-all cursor-pointer overflow-hidden flex flex-col justify-between"
              >
                {/* Locked overlay badge */}
                <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-950/80 border border-amber-500/30 text-[10px] font-bold text-amber-400 shadow-sm">
                  <Lock className="w-3 h-3" />
                  <span>Standard</span>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-1.5 text-[11px] text-slate-400">
                    <span className="capitalize">{guide.categoryLabel}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {guide.estimatedMinutes}m
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors pr-16 line-clamp-1">
                    {localized?.title || guide.title}
                  </h4>

                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                    {localized?.summary || 'Factory-standard technician replacement protocol and safety precautions.'}
                  </p>

                  {/* Blurred step preview */}
                  <div className="mt-3 p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 filter blur-[1px] group-hover:blur-none transition-all">
                    <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1">
                      Step 1 • Diagnostic &amp; Safety
                    </div>
                    <div className="text-[11px] text-slate-400 line-clamp-1">
                      {localized?.steps[0]?.instruction || 'Isolate main supply valve and verify pressure drop...'}
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/70 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Globe className="w-3 h-3" />
                    <span>{guide.supportedLanguages.length} Languages</span>
                  </span>

                  <span className="text-amber-400 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-1 text-[11px]">
                    <span>Unlock Guide</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Feature Comparison Table */}
      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-sm font-bold text-white">Full Capability Matrix: Free vs Standard</h4>
            <p className="text-xs text-slate-400">
              See everything included when you upgrade your contractor account.
            </p>
          </div>
          <button
            onClick={onUpgradeToStandard}
            className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
          >
            Upgrade ($24/mo)
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2.5 px-3 font-bold">Feature</th>
                <th className="py-2.5 px-3 font-bold text-center w-32">Free Community</th>
                <th className="py-2.5 px-3 font-bold text-center w-40 bg-amber-500/10 text-amber-300">
                  Standard Contractor
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {FEATURE_COMPARISON_MATRIX.map((item, idx) => (
                <tr key={idx} className={item.highlight ? 'bg-amber-500/5' : ''}>
                  <td className="py-2.5 px-3 text-slate-200 font-medium">
                    {item.name}
                    {item.highlight && (
                      <span className="ml-2 px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                        SUBSCRIBER
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {typeof item.free === 'boolean' ? (
                      item.free ? (
                        <Check className="w-4 h-4 text-emerald-400 mx-auto" />
                      ) : (
                        <X className="w-4 h-4 text-slate-600 mx-auto" />
                      )
                    ) : (
                      <span className="text-slate-400">{item.free}</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-center bg-amber-500/5 font-semibold text-white">
                    {typeof item.standard === 'boolean' ? (
                      item.standard ? (
                        <Check className="w-4 h-4 text-amber-400 mx-auto" />
                      ) : (
                        <X className="w-4 h-4 text-slate-600 mx-auto" />
                      )
                    ) : (
                      <span className="text-amber-300">{item.standard}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
