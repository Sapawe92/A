import React, { useState } from 'react';
import { Camera, Truck, Users, FileCheck, BarChart3, Globe, ShieldAlert, ChevronDown, Wrench, Bell, Smartphone, QrCode, Copy, Check, X, ExternalLink, HardDrive, BookOpen, Sparkles, Lock } from 'lucide-react';
import { TechLanguage, SubscriptionTier } from '../types';
import { LANGUAGES } from '../data/mockData';
import { LeakScanLogo } from './Logo';
import { PWAInstallButton } from './PWAInstallButton';
import { TestOnPhoneModal } from './TestOnPhoneModal';

interface NavbarProps {
  activeTab: 'scan' | 'guides' | 'van' | 'techs' | 'turnins' | 'reports' | 'drive';
  setActiveTab: (tab: 'scan' | 'guides' | 'van' | 'techs' | 'turnins' | 'reports' | 'drive') => void;
  selectedLanguage: TechLanguage;
  setSelectedLanguage: (lang: TechLanguage) => void;
  lowStockCount: number;
  pendingTurnInsCount: number;
  activeTechName: string;
  subscriptionTier?: SubscriptionTier;
  onOpenSubscriptionModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  selectedLanguage,
  setSelectedLanguage,
  lowStockCount,
  pendingTurnInsCount,
  activeTechName,
  subscriptionTier = 'free',
  onOpenSubscriptionModal,
}) => {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const currentLang = LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('scan')}
              className="text-left group focus:outline-none"
            >
              <LeakScanLogo />
            </button>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/60 p-1.5 rounded-xl border border-slate-800/80">
            <button
              onClick={() => setActiveTab('scan')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'scan'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>Camera & AI</span>
            </button>

            <button
              onClick={() => setActiveTab('guides')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'guides'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Repair Guides</span>
              {subscriptionTier === 'free' ? (
                <span className="text-[10px] font-black bg-blue-500/20 text-blue-300 px-1.5 py-0.2 rounded border border-blue-500/30 flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" />
                  <span>STD</span>
                </span>
              ) : (
                <span className="text-[10px] font-black bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">
                  ✓
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('techs')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'techs'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Techs & Dispatch</span>
              {(subscriptionTier === 'free' || subscriptionTier === 'standard') && (
                <span className="text-[10px] font-black bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30 flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" />
                  <span>PRO</span>
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('turnins')}
              className={`relative flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'turnins'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              <span>Turn-Ins</span>
              {pendingTurnInsCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'reports'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Yearly Reports</span>
            </button>

            <button
              onClick={() => setActiveTab('van')}
              className={`relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'van'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Truck className="w-4 h-4" />
              <span>Van Stock</span>
              {(subscriptionTier === 'free' || subscriptionTier === 'standard') ? (
                <span className="text-[10px] font-black bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30 flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" />
                  <span>PRO</span>
                </span>
              ) : lowStockCount > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-rose-500 text-white">
                  {lowStockCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('drive')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'drive'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <HardDrive className={`w-4 h-4 ${activeTab === 'drive' ? 'text-slate-950' : 'text-blue-400'}`} />
              <span>Google Drive</span>
            </button>
          </nav>

          {/* Right Header: Language Selector & Tech Badge */}
          <div className="flex items-center gap-2">
            {/* Multilingual Selector (Crucial for non-native English speakers) */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700/80 hover:border-amber-500/50 text-slate-200 text-xs font-semibold transition-all"
                title="Select Technician Preferred Language"
              >
                <span className="text-base">{currentLang.flag}</span>
                <span className="hidden sm:inline">{currentLang.nativeLabel}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {langMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setLangMenuOpen(false)}
                  />
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-2 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-2 py-1.5 text-[11px] font-bold text-amber-400 uppercase tracking-wider border-b border-slate-800 mb-1 flex items-center justify-between">
                      <span>Tech Native Language</span>
                      <Globe className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                    <div className="space-y-1">
                      {LANGUAGES.map((lang) => (
                        <button
                          key={lang.code}
                          onClick={() => {
                            setSelectedLanguage(lang.code);
                            setLangMenuOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-left transition-colors ${
                            selectedLanguage === lang.code
                              ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30'
                              : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-base">{lang.flag}</span>
                            <div>
                              <div className="font-medium">{lang.nativeLabel}</div>
                              <div className="text-[10px] text-slate-400">{lang.label}</div>
                            </div>
                          </div>
                          {selectedLanguage === lang.code && (
                            <span className="text-amber-400 font-black">✓</span>
                          )}
                        </button>
                      ))}
                    </div>
                    <div className="mt-2 pt-2 border-t border-slate-800 px-2 text-[10px] text-slate-400">
                      AI guides & audio will play in this language.
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Contractor Subscription Status Badge / Upgrade Button */}
            <button
              onClick={onOpenSubscriptionModal}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all shadow-sm ${
                subscriptionTier === 'enterprise'
                  ? 'bg-gradient-to-r from-purple-500/20 to-indigo-600/30 border border-purple-500/50 text-purple-300 hover:bg-purple-500/30'
                  : subscriptionTier === 'pro'
                  ? 'bg-gradient-to-r from-amber-500/20 to-amber-600/30 border border-amber-500/50 text-amber-300 hover:bg-amber-500/30'
                  : subscriptionTier === 'standard'
                  ? 'bg-blue-500/20 border border-blue-500/40 text-blue-300 hover:bg-blue-500/30'
                  : 'bg-gradient-to-r from-amber-500/20 via-amber-500/30 to-amber-500/20 hover:from-amber-500/30 hover:to-amber-500/40 border border-amber-500/50 text-amber-300 shadow-amber-500/10'
              }`}
              title="View Contractor Subscription Plans"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">
                {subscriptionTier === 'enterprise'
                  ? 'Titan Enterprise 👑'
                  : subscriptionTier === 'pro'
                  ? 'Master Pro ⭐'
                  : subscriptionTier === 'standard'
                  ? 'Journeyman (Upgrade to Pro)'
                  : 'Free Apprentice • Upgrade'}
              </span>
              <span className="sm:hidden text-[11px]">
                {subscriptionTier === 'enterprise'
                  ? 'Enterprise'
                  : subscriptionTier === 'pro'
                  ? 'Pro'
                  : subscriptionTier === 'standard'
                  ? 'Journeyman'
                  : 'Upgrade'}
              </span>
            </button>

            {/* Install PWA Button */}
            <PWAInstallButton />

            {/* Test on Phone Button */}
            <button
              onClick={() => setShowPhoneModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-300 hover:text-white text-xs font-medium transition-all shadow-sm"
              title="Scan QR code to open on your phone camera"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Test on Phone</span>
              <QrCode className="w-3.5 h-3.5 hidden sm:block opacity-70" />
            </button>

            {/* Field Tech Active Indicator */}
            <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-slate-800 text-xs">
              <div className="w-7 h-7 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center font-bold text-amber-400">
                {activeTechName.charAt(0)}
              </div>
              <div className="text-left">
                <div className="font-semibold text-slate-200 leading-tight">{activeTechName}</div>
                <div className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Online / Van #1
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Test on Phone Modal */}
      <TestOnPhoneModal
        isOpen={showPhoneModal}
        onClose={() => setShowPhoneModal(false)}
      />

      {/* Mobile Bottom / Sub Navigation Bar */}
      <div className="md:hidden flex items-center justify-between overflow-x-auto no-scrollbar bg-slate-950 border-t border-slate-800/80 px-1 py-1.5 gap-1">
        <button
          onClick={() => setActiveTab('scan')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors shrink-0 ${
            activeTab === 'scan' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Camera className="w-5 h-5 mb-0.5" />
          <span>Scan AI</span>
        </button>

        <button
          onClick={() => setActiveTab('guides')}
          className={`relative flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors shrink-0 ${
            activeTab === 'guides' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <BookOpen className="w-5 h-5 mb-0.5" />
          <span>Guides</span>
          {subscriptionTier === 'free' && (
            <span className="absolute top-0 right-0 text-[8px] bg-blue-500 text-white font-black px-1 rounded-full">
              STD
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('techs')}
          className={`relative flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors ${
            activeTab === 'techs' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>Dispatch</span>
          {(subscriptionTier === 'free' || subscriptionTier === 'standard') && (
            <span className="absolute top-0 right-0 text-[8px] bg-amber-500 text-slate-950 font-black px-1 rounded-full">
              PRO
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('turnins')}
          className={`relative flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors ${
            activeTab === 'turnins' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <FileCheck className="w-5 h-5 mb-0.5" />
          <span>Turn-Ins</span>
          {pendingTurnInsCount > 0 && (
            <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors ${
            activeTab === 'reports' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <BarChart3 className="w-5 h-5 mb-0.5" />
          <span>Reports</span>
        </button>

        <button
          onClick={() => setActiveTab('van')}
          className={`relative flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors ${
            activeTab === 'van' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Truck className="w-5 h-5 mb-0.5" />
          <span>Van Stock</span>
          {(subscriptionTier === 'free' || subscriptionTier === 'standard') ? (
            <span className="absolute top-0 right-0 text-[8px] bg-amber-500 text-slate-950 font-black px-1 rounded-full">
              PRO
            </span>
          ) : lowStockCount > 0 && (
            <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-rose-500" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('drive')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[11px] font-medium transition-colors ${
            activeTab === 'drive' ? 'text-amber-400 font-bold' : 'text-slate-400'
          }`}
        >
          <HardDrive className="w-5 h-5 mb-0.5 text-blue-400" />
          <span>Drive</span>
        </button>
      </div>
    </header>
  );
};
