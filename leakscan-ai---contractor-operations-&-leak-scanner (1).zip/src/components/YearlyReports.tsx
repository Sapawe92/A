import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Briefcase,
  Percent,
  Download,
  Calendar,
  Award,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  Cell,
} from 'recharts';
import { FinancialMetric } from '../types';
import { FINANCIAL_METRICS } from '../data/mockData';

interface MonthlyReportItem {
  month: string;
  revenue: number;
  netProfit: number;
  jobs: number;
  averageTicket: number;
}

const YEARLY_MONTHLY_DATA: Record<number, MonthlyReportItem[]> = {
  2026: [
    { month: 'Jan', revenue: 26500, netProfit: 11130, jobs: 64, averageTicket: 414.06 },
    { month: 'Feb', revenue: 29800, netProfit: 12516, jobs: 72, averageTicket: 413.88 },
    { month: 'Mar', revenue: 34200, netProfit: 14364, jobs: 83, averageTicket: 412.04 },
    { month: 'Apr', revenue: 38900, netProfit: 16338, jobs: 94, averageTicket: 413.82 },
    { month: 'May', revenue: 42100, netProfit: 17682, jobs: 102, averageTicket: 412.74 },
    { month: 'Jun', revenue: 46800, netProfit: 19656, jobs: 112, averageTicket: 417.85 },
    { month: 'Jul', revenue: 48200, netProfit: 20244, jobs: 116, averageTicket: 415.51 },
    { month: 'Aug', revenue: 44100, netProfit: 18522, jobs: 106, averageTicket: 416.03 },
    { month: 'Sep', revenue: 37900, netProfit: 15918, jobs: 93, averageTicket: 407.52 },
    { month: 'Oct', revenue: 30000, netProfit: 12600, jobs: 74, averageTicket: 405.40 },
  ],
  2025: [
    { month: 'Jan', revenue: 28400, netProfit: 11360, jobs: 72, averageTicket: 394.44 },
    { month: 'Feb', revenue: 29200, netProfit: 11680, jobs: 74, averageTicket: 394.59 },
    { month: 'Mar', revenue: 33500, netProfit: 13400, jobs: 85, averageTicket: 394.11 },
    { month: 'Apr', revenue: 36000, netProfit: 14400, jobs: 91, averageTicket: 395.60 },
    { month: 'May', revenue: 39400, netProfit: 15760, jobs: 100, averageTicket: 394.00 },
    { month: 'Jun', revenue: 42800, netProfit: 17120, jobs: 108, averageTicket: 396.29 },
    { month: 'Jul', revenue: 44500, netProfit: 17800, jobs: 113, averageTicket: 393.80 },
    { month: 'Aug', revenue: 41200, netProfit: 16480, jobs: 105, averageTicket: 392.38 },
    { month: 'Sep', revenue: 36800, netProfit: 14720, jobs: 93, averageTicket: 395.69 },
    { month: 'Oct', revenue: 34200, netProfit: 13680, jobs: 87, averageTicket: 393.10 },
    { month: 'Nov', revenue: 26500, netProfit: 10600, jobs: 67, averageTicket: 395.52 },
    { month: 'Dec', revenue: 19500, netProfit: 7800, jobs: 50, averageTicket: 390.00 },
  ],
  2024: [
    { month: 'Jan', revenue: 22000, netProfit: 8360, jobs: 58, averageTicket: 379.31 },
    { month: 'Feb', revenue: 23500, netProfit: 8930, jobs: 61, averageTicket: 385.24 },
    { month: 'Mar', revenue: 26800, netProfit: 10184, jobs: 70, averageTicket: 382.85 },
    { month: 'Apr', revenue: 29100, netProfit: 11058, jobs: 76, averageTicket: 382.89 },
    { month: 'May', revenue: 31400, netProfit: 11932, jobs: 82, averageTicket: 382.92 },
    { month: 'Jun', revenue: 34200, netProfit: 12996, jobs: 89, averageTicket: 384.26 },
    { month: 'Jul', revenue: 35600, netProfit: 13528, jobs: 93, averageTicket: 382.79 },
    { month: 'Aug', revenue: 32800, netProfit: 12464, jobs: 85, averageTicket: 385.88 },
    { month: 'Sep', revenue: 28400, netProfit: 10792, jobs: 74, averageTicket: 383.78 },
    { month: 'Oct', revenue: 26200, netProfit: 9956, jobs: 68, averageTicket: 385.29 },
    { month: 'Nov', revenue: 28000, netProfit: 10640, jobs: 73, averageTicket: 383.56 },
    { month: 'Dec', revenue: 27000, netProfit: 10260, jobs: 71, averageTicket: 380.28 },
  ],
};

export const YearlyReports: React.FC = () => {
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [chartMode, setChartMode] = useState<'revenue' | 'comparison' | 'jobs'>('revenue');
  const [showAvgLine, setShowAvgLine] = useState<boolean>(true);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);

  const currentMetric =
    FINANCIAL_METRICS.find((m) => m.year === selectedYear) || FINANCIAL_METRICS[0];

  const monthlyData = YEARLY_MONTHLY_DATA[selectedYear] || YEARLY_MONTHLY_DATA[2026];

  const peakMonth = monthlyData.reduce(
    (prev, curr) => (curr.revenue > prev.revenue ? curr : prev),
    monthlyData[0]
  );
  const lowestMonth = monthlyData.reduce(
    (prev, curr) => (curr.revenue < prev.revenue ? curr : prev),
    monthlyData[0]
  );
  const totalYearRevenue = monthlyData.reduce((sum, d) => sum + d.revenue, 0);
  const avgMonthlyRevenue = Math.round(totalYearRevenue / monthlyData.length);
  const totalYearJobs = monthlyData.reduce((sum, d) => sum + d.jobs, 0);

  const activeInspectedMonth = selectedMonth
    ? monthlyData.find((m) => m.month === selectedMonth) || peakMonth
    : null;

  const handleExportCsv = () => {
    const csvRows = [
      ['Metric', 'Value'],
      ['Reporting Year', currentMetric.year.toString()],
      ['Gross Revenue', `$${currentMetric.grossRevenue.toFixed(2)}`],
      ['Total Completed Jobs', currentMetric.completedJobs.toString()],
      ['Average Ticket Size', `$${currentMetric.averageTicket.toFixed(2)}`],
      ['Parts Material Costs', `$${currentMetric.partsCosts.toFixed(2)}`],
      ['Technician Labor Costs', `$${currentMetric.laborCosts.toFixed(2)}`],
      ['Net Contractor Profit', `$${currentMetric.netProfit.toFixed(2)}`],
      ['Profit Margin', `${currentMetric.profitMarginPercent}%`],
      [''],
      ['Month', 'Gross Revenue', 'Net Profit', 'Jobs Completed', 'Average Ticket'],
      ...monthlyData.map((d) => [
        d.month,
        `$${d.revenue}`,
        `$${d.netProfit}`,
        d.jobs.toString(),
        `$${d.averageTicket.toFixed(2)}`,
      ]),
    ];

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      csvRows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LeakScan_AI_Financial_Report_${selectedYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  // Custom Tooltip for Recharts Bar Chart
  const CustomBarTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data: MonthlyReportItem = payload[0].payload;
      const isPeak = data.month === peakMonth.month;
      return (
        <div className="bg-slate-900/95 backdrop-blur-md border border-slate-700/90 p-3.5 rounded-xl shadow-2xl text-xs space-y-2 min-w-[210px] pointer-events-none">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-black text-white text-sm flex items-center gap-1.5">
              <span>{label} {selectedYear}</span>
            </span>
            {isPeak && (
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Peak Month ★
              </span>
            )}
          </div>

          <div className="space-y-1.5 font-mono">
            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" />
                Gross Revenue:
              </span>
              <span className="font-bold text-amber-400">
                ${data.revenue.toLocaleString()}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
                Net Profit:
              </span>
              <span className="font-bold text-emerald-400">
                ${data.netProfit.toLocaleString()}
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-sky-500" />
                Jobs Completed:
              </span>
              <span className="font-bold text-white">
                {data.jobs} jobs
              </span>
            </div>

            <div className="flex items-center justify-between text-slate-400 text-[11px] pt-1.5 border-t border-slate-800">
              <span>Avg Ticket Size:</span>
              <span className="font-semibold text-slate-200">
                ${data.averageTicket.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <span>Yearly Business & Financial Reports</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Executive revenue analytics, monthly trends, profit margins, and technician leaderboard.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Year Switcher */}
            <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center gap-1 text-xs">
              {[2026, 2025, 2024].map((year) => (
                <button
                  key={year}
                  onClick={() => {
                    setSelectedYear(year);
                    setSelectedMonth(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                    selectedYear === year
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {year} {year === 2026 && 'YTD'}
                </button>
              ))}
            </div>

            <button
              onClick={handleExportCsv}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>{downloadSuccess ? 'Downloaded!' : 'Export CSV'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Top Financial KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Gross Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-400">
            ${currentMetric.grossRevenue.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-500 font-mono flex items-center gap-1 mt-0.5">
            <TrendingUp className="w-3 h-3" />
            +18.4% vs previous year
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Net Profit</span>
            <Percent className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-400">
            ${currentMetric.netProfit.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
            {currentMetric.profitMarginPercent}% net profit margin
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Completed Jobs</span>
            <Briefcase className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            {currentMetric.completedJobs}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
            100% customer invoice sign-off
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Average Ticket Size</span>
            <DollarSign className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            ${currentMetric.averageTicket.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
            Parts + Labor + Trip Fee
          </div>
        </div>
      </div>

      {/* Monthly Revenue Trends - Interactive Recharts Bar Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl space-y-5">
        {/* Chart Header with Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
                <BarChart3 className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Monthly Revenue Trends ({selectedYear})
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Visualizing month-over-month performance, sales volume, and retained margin.
            </p>
          </div>

          {/* Interactive Chart Options */}
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Toggle */}
            <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center gap-1 text-xs">
              <button
                onClick={() => setChartMode('revenue')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  chartMode === 'revenue'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Revenue
              </button>
              <button
                onClick={() => setChartMode('comparison')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  chartMode === 'comparison'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Revenue vs Profit
              </button>
              <button
                onClick={() => setChartMode('jobs')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  chartMode === 'jobs'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Revenue & Jobs
              </button>
            </div>

            {/* Reference Line Toggle */}
            <button
              onClick={() => setShowAvgLine(!showAvgLine)}
              className={`px-2.5 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                showAvgLine
                  ? 'bg-slate-800 text-amber-400 border-amber-500/40'
                  : 'bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-300'
              }`}
              title="Toggle average benchmark line"
            >
              <span className={`w-2 h-2 rounded-full ${showAvgLine ? 'bg-amber-400' : 'bg-slate-600'}`} />
              <span>Avg Line</span>
            </button>
          </div>
        </div>

        {/* Quick Highlights Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/70 p-3 sm:p-4 rounded-xl border border-slate-800/80 text-xs">
          <div className="space-y-0.5">
            <span className="text-[11px] text-slate-400 uppercase font-bold tracking-wider">Peak Month</span>
            <div className="text-sm font-black text-amber-400 font-mono flex items-center gap-1.5">
              <span>{peakMonth.month}</span>
              <span className="text-xs text-slate-300">(${peakMonth.revenue.toLocaleString()})</span>
            </div>
            <div className="text-[10px] text-slate-500">{peakMonth.jobs} completed repairs</div>
          </div>

          <div className="space-y-0.5">
            <span className="text-[11px] text-slate-400 uppercase font-bold tracking-wider">Monthly Average</span>
            <div className="text-sm font-black text-white font-mono">
              ${avgMonthlyRevenue.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-500">Run rate / month</div>
          </div>

          <div className="space-y-0.5">
            <span className="text-[11px] text-slate-400 uppercase font-bold tracking-wider">Lowest Month</span>
            <div className="text-sm font-black text-slate-300 font-mono flex items-center gap-1.5">
              <span>{lowestMonth.month}</span>
              <span className="text-xs text-slate-400">(${lowestMonth.revenue.toLocaleString()})</span>
            </div>
            <div className="text-[10px] text-slate-500">{lowestMonth.jobs} jobs</div>
          </div>

          <div className="space-y-0.5">
            <span className="text-[11px] text-slate-400 uppercase font-bold tracking-wider">Total Volume</span>
            <div className="text-sm font-black text-emerald-400 font-mono">
              {totalYearJobs} Jobs
            </div>
            <div className="text-[10px] text-slate-500">${(totalYearRevenue / (totalYearJobs || 1)).toFixed(0)} avg / ticket</div>
          </div>
        </div>

        {/* Recharts Bar Chart Canvas */}
        <div className="w-full h-72 sm:h-80 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthlyData}
              margin={{ top: 20, right: 15, left: 0, bottom: 5 }}
              onClick={(state) => {
                if (state && state.activeLabel !== undefined && state.activeLabel !== null) {
                  const labelStr = String(state.activeLabel);
                  setSelectedMonth(labelStr === selectedMonth ? null : labelStr);
                }
              }}
            >
              <defs>
                <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#b45309" stopOpacity={0.7} />
                </linearGradient>
                <linearGradient id="profitGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#047857" stopOpacity={0.7} />
                </linearGradient>
                <linearGradient id="jobsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity={0.7} />
                </linearGradient>
                <linearGradient id="peakBarGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#fbbf24" stopOpacity={1} />
                  <stop offset="100%" stopColor="#d97706" stopOpacity={0.9} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} vertical={false} />

              <XAxis
                dataKey="month"
                stroke="#94a3b8"
                tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 600 }}
                axisLine={{ stroke: '#475569' }}
                tickLine={{ stroke: '#475569' }}
              />

              <YAxis
                stroke="#94a3b8"
                tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
                tick={{ fill: '#94a3b8', fontSize: 11, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#475569' }}
                tickLine={{ stroke: '#475569' }}
                width={50}
              />

              <Tooltip content={<CustomBarTooltip />} cursor={{ fill: 'rgba(255, 255, 255, 0.05)' }} />

              <Legend
                verticalAlign="top"
                align="right"
                wrapperStyle={{ paddingBottom: '12px', fontSize: '12px' }}
              />

              {showAvgLine && (
                <ReferenceLine
                  y={avgMonthlyRevenue}
                  stroke="#fbbf24"
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                  label={{
                    value: `Avg: $${(avgMonthlyRevenue / 1000).toFixed(1)}k`,
                    fill: '#fbbf24',
                    fontSize: 11,
                    position: 'top',
                    fontFamily: 'monospace',
                  }}
                />
              )}

              {chartMode === 'revenue' && (
                <Bar
                  dataKey="revenue"
                  name="Gross Revenue ($)"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={44}
                  animationDuration={800}
                >
                  {monthlyData.map((entry, index) => {
                    const isPeak = entry.month === peakMonth.month;
                    const isSelected = selectedMonth === entry.month;
                    return (
                      <Cell
                        key={`cell-${index}`}
                        fill={isPeak ? 'url(#peakBarGradient)' : 'url(#revenueGradient)'}
                        stroke={isSelected ? '#38bdf8' : isPeak ? '#fef08a' : 'transparent'}
                        strokeWidth={isSelected ? 2.5 : isPeak ? 1.5 : 0}
                        style={{ cursor: 'pointer' }}
                      />
                    );
                  })}
                </Bar>
              )}

              {chartMode === 'comparison' && (
                <>
                  <Bar
                    dataKey="revenue"
                    name="Gross Revenue ($)"
                    fill="url(#revenueGradient)"
                    radius={[5, 5, 0, 0]}
                    maxBarSize={30}
                    animationDuration={800}
                  />
                  <Bar
                    dataKey="netProfit"
                    name="Net Profit ($)"
                    fill="url(#profitGradient)"
                    radius={[5, 5, 0, 0]}
                    maxBarSize={30}
                    animationDuration={800}
                  />
                </>
              )}

              {chartMode === 'jobs' && (
                <>
                  <Bar
                    dataKey="revenue"
                    name="Gross Revenue ($)"
                    fill="url(#revenueGradient)"
                    radius={[5, 5, 0, 0]}
                    maxBarSize={30}
                    animationDuration={800}
                  />
                  <Bar
                    dataKey="jobs"
                    name="Completed Jobs"
                    fill="url(#jobsGradient)"
                    radius={[5, 5, 0, 0]}
                    maxBarSize={30}
                    animationDuration={800}
                  />
                </>
              )}
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Interactive Month Selector & Drill-down Inspection Bar */}
        <div className="pt-2 border-t border-slate-800/80 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <span>Inspect Month Breakdown</span>
              <span className="text-[11px] text-slate-500 font-normal hidden sm:inline">(click bar or month chip)</span>
            </span>
            {selectedMonth && (
              <button
                onClick={() => setSelectedMonth(null)}
                className="text-xs text-amber-400 hover:text-amber-300 font-semibold"
              >
                Clear selection
              </button>
            )}
          </div>

          <div className="flex flex-wrap gap-1.5">
            {monthlyData.map((item) => {
              const isSelected = selectedMonth === item.month;
              const isPeak = item.month === peakMonth.month;
              return (
                <button
                  key={item.month}
                  onClick={() => setSelectedMonth(isSelected ? null : item.month)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 shadow-md ring-2 ring-amber-400/50'
                      : isPeak
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20'
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <span>{item.month}</span>
                  {isPeak && <span className="text-[10px]">★</span>}
                </button>
              );
            })}
          </div>

          {/* Detailed Inspector Card when a month is clicked */}
          {activeInspectedMonth && (
            <div className="bg-slate-950 border border-amber-500/40 rounded-xl p-3.5 sm:p-4 text-xs space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="font-black text-white text-sm">
                    {activeInspectedMonth.month} {selectedYear} Detail
                  </span>
                  {activeInspectedMonth.month === peakMonth.month && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Highest Performing Month ★
                    </span>
                  )}
                </div>
                <span className="text-slate-400 font-mono">
                  {((activeInspectedMonth.revenue / totalYearRevenue) * 100).toFixed(1)}% of yearly revenue
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono pt-1">
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-sans">Gross Receipts</div>
                  <div className="text-base font-black text-amber-400">
                    ${activeInspectedMonth.revenue.toLocaleString()}
                  </div>
                </div>

                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-sans">Retained Profit</div>
                  <div className="text-base font-black text-emerald-400">
                    ${activeInspectedMonth.netProfit.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {((activeInspectedMonth.netProfit / activeInspectedMonth.revenue) * 100).toFixed(1)}% margin
                  </div>
                </div>

                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-sans">Repairs Completed</div>
                  <div className="text-base font-black text-white">
                    {activeInspectedMonth.jobs}
                  </div>
                  <div className="text-[10px] text-slate-500">Service tickets</div>
                </div>

                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400 uppercase font-sans">Average Ticket</div>
                  <div className="text-base font-black text-purple-400">
                    ${activeInspectedMonth.averageTicket.toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-500">Per customer visit</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Two Column Section: Cost Distribution & Tech Leaderboard */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Cost Allocation & Contractor Margins</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">{selectedYear} Totals</span>
          </div>

          <div className="space-y-3 text-xs">
            {/* Net Profit */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <span>Net Contractor Profit (42.0%)</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">Retained contractor earnings</div>
              </div>
              <div className="text-sm font-black text-emerald-300 font-mono">
                ${currentMetric.netProfit.toLocaleString()}
              </div>
            </div>

            {/* Labor Costs */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-blue-400 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-400" />
                  <span>Tech Labor & Payroll (40.0%)</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">Hourly field technician compensation</div>
              </div>
              <div className="text-sm font-black text-white font-mono">
                ${currentMetric.laborCosts.toLocaleString()}
              </div>
            </div>

            {/* Parts & Materials Overhead */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-amber-400 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  <span>Parts & Supply House Cost (18.0%)</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">Ferguson, valves, PEX, fittings, gas</div>
              </div>
              <div className="text-sm font-black text-white font-mono">
                ${currentMetric.partsCosts.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {/* Technician Performance Leaderboard */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Technician Performance Leaderboard</span>
            </h3>
            <span className="text-xs text-amber-400 font-mono">Yearly Standings</span>
          </div>

          <div className="space-y-2.5 text-xs">
            {[
              {
                rank: 1,
                name: 'Alex Penchev',
                van: 'Van #1 - Master Rig',
                jobs: 320,
                revenue: 138400,
                rating: 4.95,
              },
              {
                rank: 2,
                name: 'Marco Rodriguez',
                van: 'Van #2 - Rapid Response',
                jobs: 285,
                revenue: 118200,
                rating: 4.88,
              },
              {
                rank: 3,
                name: 'Dmitry Kovalenko',
                van: 'Van #3 - Heavy Duty',
                jobs: 237,
                revenue: 91900,
                rating: 4.91,
              },
            ].map((tech) => (
              <div
                key={tech.rank}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs ${
                      tech.rank === 1
                        ? 'bg-amber-500 text-slate-950'
                        : tech.rank === 2
                        ? 'bg-slate-300 text-slate-950'
                        : 'bg-amber-700 text-white'
                    }`}
                  >
                    #{tech.rank}
                  </span>
                  <div>
                    <h4 className="font-bold text-white">{tech.name}</h4>
                    <div className="text-[11px] text-slate-400 font-mono">{tech.van}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-black text-emerald-400 font-mono text-sm">
                    ${tech.revenue.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {tech.jobs} Jobs • ★ {tech.rating}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
