import React, { useState, useEffect } from 'react';
import {
  WifiOff,
  Wifi,
  Database,
  RefreshCw,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  Radio,
  X,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import {
  getOfflineCacheStats,
  getSyncQueue,
  clearSyncQueue,
  setSimulatedOffline,
  OfflineCacheStats,
  SyncQueueAction,
} from '../services/offlineStorage';

interface OfflineIndicatorProps {
  onForceSync?: () => void;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({ onForceSync }) => {
  const { isOnline, browserOnline, isSimulated } = useOnlineStatus();
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [stats, setStats] = useState<OfflineCacheStats | null>(null);
  const [queue, setQueue] = useState<SyncQueueAction[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccessMessage, setSyncSuccessMessage] = useState<string | null>(null);

  // Refresh stats periodically or on status change
  const refreshStats = () => {
    setStats(getOfflineCacheStats());
    setQueue(getSyncQueue());
  };

  useEffect(() => {
    refreshStats();
    const interval = setInterval(refreshStats, 3000);
    return () => clearInterval(interval);
  }, [isOnline]);

  // When connection comes back online, trigger auto-sync notification
  useEffect(() => {
    if (isOnline && queue.length > 0) {
      handleManualSync();
    }
  }, [isOnline]);

  const handleManualSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      if (onForceSync) {
        onForceSync();
      }
      const count = queue.length;
      clearSyncQueue();
      refreshStats();
      setIsSyncing(false);
      setSyncSuccessMessage(`Synced ${count} offline changes with central server!`);
      setTimeout(() => setSyncSuccessMessage(null), 4000);
    }, 900);
  };

  const handleToggleSimulation = () => {
    setSimulatedOffline(!isSimulated);
  };

  return (
    <>
      {/* Top Banner when Offline or Simulated Offline */}
      {!isOnline && (
        <div className="bg-gradient-to-r from-amber-950 via-amber-900 to-amber-950 border-b border-amber-500/30 px-3 py-2 text-xs text-amber-200 shadow-md">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
              <div className="flex items-center gap-1.5 font-bold text-amber-100">
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {isSimulated ? 'Simulated Basement / Dead Zone Mode' : 'Offline Mode (No Cellular Service)'}
                </span>
              </div>
              <span className="hidden md:inline text-amber-300/80">
                • Working from local cache. Van stock & job records will auto-sync when connection restores.
              </span>
            </div>

            <div className="flex items-center gap-2">
              {queue.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30 text-[11px]">
                  {queue.length} pending edit{queue.length !== 1 ? 's' : ''}
                </span>
              )}

              <button
                onClick={() => setShowDetailsModal(true)}
                className="px-2.5 py-1 rounded-md bg-amber-800/60 hover:bg-amber-800 text-amber-200 border border-amber-600/40 text-[11px] font-medium transition"
              >
                Cache Details
              </button>

              <button
                onClick={handleToggleSimulation}
                className="px-2.5 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-[11px] font-medium transition"
              >
                {isSimulated ? 'Resume Online' : 'Simulate Dead Zone'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reconnected notification banner */}
      {syncSuccessMessage && (
        <div className="bg-emerald-950/90 border-b border-emerald-500/40 px-3 py-2 text-xs text-emerald-200 shadow-md">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-emerald-100">{syncSuccessMessage}</span>
            </div>
            <button
              onClick={() => setSyncSuccessMessage(null)}
              className="text-emerald-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Floating Mini Offline / Cache Status Pill (bottom right) */}
      <div className="fixed bottom-16 sm:bottom-4 right-4 z-40">
        <button
          onClick={() => setShowDetailsModal(true)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold shadow-lg backdrop-blur-md border transition-all ${
            !isOnline
              ? 'bg-amber-950/90 border-amber-500/50 text-amber-200 hover:bg-amber-900/90'
              : 'bg-slate-900/90 border-slate-700/80 text-slate-300 hover:text-white hover:border-slate-600'
          }`}
          title="Inspect Offline Storage Cache & Sync Queue"
        >
          <span
            className={`w-2 h-2 rounded-full ${
              !isOnline ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'
            }`}
          />
          <span className="flex items-center gap-1">
            <Database className="w-3 h-3 text-sky-400" />
            {!isOnline ? 'Offline Cached' : 'Offline Ready'}
          </span>
          {queue.length > 0 && (
            <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-extrabold flex items-center justify-center">
              {queue.length}
            </span>
          )}
        </button>
      </div>

      {/* Cache & Sync Status Details Modal */}
      {showDetailsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-200 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    Offline Cache & Storage
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                        !isOnline
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {!isOnline ? 'Offline Mode' : 'Online & Synchronized'}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Local storage caching for poor cellular reception in basements
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="mt-4 space-y-4 overflow-y-auto pr-1">
              {/* Storage Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                  <div className="text-[11px] text-slate-400 font-medium">Cached Jobs</div>
                  <div className="text-lg font-bold text-sky-400 mt-0.5">
                    {stats?.jobsCount || 0}
                  </div>
                  <div className="text-[10px] text-slate-500">records stored</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                  <div className="text-[11px] text-slate-400 font-medium">Van Stock Items</div>
                  <div className="text-lg font-bold text-emerald-400 mt-0.5">
                    {stats?.stockCount || 0}
                  </div>
                  <div className="text-[10px] text-slate-500">parts tracked</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                  <div className="text-[11px] text-slate-400 font-medium">Queue Edits</div>
                  <div className="text-lg font-bold text-amber-400 mt-0.5">
                    {queue.length}
                  </div>
                  <div className="text-[10px] text-slate-500">pending sync</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
                  <div className="text-[11px] text-slate-400 font-medium">Local Cache</div>
                  <div className="text-lg font-bold text-purple-400 mt-0.5">
                    {stats?.estimatedStorageKb || 0} KB
                  </div>
                  <div className="text-[10px] text-slate-500">offline storage</div>
                </div>
              </div>

              {/* Cellular Simulation Toggle */}
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-amber-400" />
                    Simulate Basement Cell Dead Zone
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Forces offline caching mode to test job dispatch, inventory deduction, and turn-ins.
                  </div>
                </div>
                <button
                  onClick={handleToggleSimulation}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    isSimulated
                      ? 'bg-amber-600 hover:bg-amber-500 text-white'
                      : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                  }`}
                >
                  {isSimulated ? 'Exit Sim' : 'Enable Sim'}
                </button>
              </div>

              {/* Pending Sync Queue List */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Offline Sync Queue ({queue.length})
                  </h4>
                  {queue.length > 0 && (
                    <button
                      onClick={() => {
                        clearSyncQueue();
                        refreshStats();
                      }}
                      className="text-[11px] text-red-400 hover:text-red-300 font-medium"
                    >
                      Clear Queue
                    </button>
                  )}
                </div>

                {queue.length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/50 text-center text-xs text-slate-400">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto mb-1.5 opacity-80" />
                    All records and van inventory modifications are synchronized.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {queue.map((action) => (
                      <div
                        key={action.id}
                        className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700/80 text-xs flex items-center justify-between"
                      >
                        <div>
                          <div className="font-semibold text-slate-200">
                            {action.description}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            Type: <span className="font-mono text-sky-400">{action.type}</span> •{' '}
                            {new Date(action.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-semibold border border-amber-500/30">
                          Pending
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Service Worker Info */}
              <div className="p-3 rounded-xl bg-sky-950/30 border border-sky-500/20 text-xs text-sky-300/90 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-sky-200">
                    Vite PWA & Workbox Service Worker Active:
                  </span>{' '}
                  App shell, AI camera logic, repair guidance, and mock diagnostic presets are precached.
                  Technicians can open and use this application anywhere with zero internet connectivity.
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
              <button
                onClick={() => {
                  refreshStats();
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Refresh Stats
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowDetailsModal(false)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
                >
                  Close
                </button>
                <button
                  onClick={handleManualSync}
                  disabled={isSyncing || queue.length === 0}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-50 disabled:pointer-events-none text-white text-xs font-bold transition shadow-sm"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  {isSyncing ? 'Syncing...' : 'Sync Pending Edits'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
