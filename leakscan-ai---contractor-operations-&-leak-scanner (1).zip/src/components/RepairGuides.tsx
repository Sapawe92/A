import React, { useState, useMemo } from 'react';
import {
  Search,
  BookOpen,
  Filter,
  Globe,
  Volume2,
  VolumeX,
  Check,
  AlertTriangle,
  Clock,
  Wrench,
  Copy,
  HardDrive,
  Bookmark,
  BookmarkCheck,
  ChevronRight,
  ShieldAlert,
  Lightbulb,
  Camera,
  Layers,
  Sparkles,
  RotateCcw,
  Package,
  PenTool,
  ShieldCheck,
  FileCheck,
} from 'lucide-react';
import { TechLanguage, RepairGuide, StockItem, Job, CustomerSignOff, SubscriptionTier } from '../types';
import { LANGUAGES } from '../data/mockData';
import { REPAIR_GUIDES } from '../data/repairGuidesData';
import { speakText, stopSpeaking } from '../utils/audioPlayer';
import { getAccessToken } from '../services/googleAuth';
import { saveLogToDrive } from '../services/googleDrive';
import { CustomerSignOffModal } from './CustomerSignOffModal';
import { RepairGuidesPaywall } from './RepairGuidesPaywall';

interface RepairGuidesProps {
  selectedLanguage: TechLanguage;
  setSelectedLanguage: (lang: TechLanguage) => void;
  stockItems?: StockItem[];
  jobs?: Job[];
  onSaveJobSignOff?: (jobId: string, signOff: CustomerSignOff) => void;
  onNavigateToScan?: () => void;
  onNavigateToDrive?: () => void;
  subscriptionTier?: SubscriptionTier;
  onSelectTier?: (tier: SubscriptionTier) => void;
  onOpenSubscriptionModal?: () => void;
}

export const RepairGuides: React.FC<RepairGuidesProps> = ({
  selectedLanguage,
  setSelectedLanguage,
  stockItems = [],
  jobs = [],
  onSaveJobSignOff,
  onNavigateToScan,
  onNavigateToDrive,
  subscriptionTier = 'free',
  onSelectTier,
  onOpenSubscriptionModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [filterBySelectedLanguageOnly, setFilterBySelectedLanguageOnly] = useState<boolean>(true);
  const [activeGuideId, setActiveGuideId] = useState<string | null>(REPAIR_GUIDES[0]?.id || null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [copiedGuideId, setCopiedGuideId] = useState<string | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('leakscan_bookmarked_guides');
      return saved ? JSON.parse(saved) : ['guide-copper-pinhole', 'guide-tpr-valve'];
    } catch {
      return ['guide-copper-pinhole'];
    }
  });
  const [showBookmarksOnly, setShowBookmarksOnly] = useState<boolean>(false);
  const [isSavingToDrive, setIsSavingToDrive] = useState<boolean>(false);
  const [driveSaveSuccess, setDriveSaveSuccess] = useState<string | null>(null);

  // Customer Sign-Off Modal state
  const [showSignOffModal, setShowSignOffModal] = useState<boolean>(false);
  const [signOffSuccessMessage, setSignOffSuccessMessage] = useState<string | null>(null);

  const currentLangObj = useMemo(
    () => LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0],
    [selectedLanguage]
  );

  const toggleBookmark = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setBookmarkedIds((prev) => {
      const updated = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('leakscan_bookmarked_guides', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  // Filter guides
  const filteredGuides = useMemo(() => {
    return REPAIR_GUIDES.filter((guide) => {
      // 1. Language availability filter
      if (filterBySelectedLanguageOnly) {
        const hasLang = guide.supportedLanguages.includes(selectedLanguage) && !!guide.translations[selectedLanguage];
        if (!hasLang) return false;
      }

      // 2. Bookmarks filter
      if (showBookmarksOnly && !bookmarkedIds.includes(guide.id)) {
        return false;
      }

      // 3. Category filter
      if (selectedCategory !== 'all' && guide.category !== selectedCategory) {
        return false;
      }

      // 4. Difficulty filter
      if (selectedDifficulty !== 'all' && guide.difficulty !== selectedDifficulty) {
        return false;
      }

      // 5. Search query matching across English AND selectedLanguage
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const localized = guide.translations[selectedLanguage] || guide.translations.en;

        const matchTitleEn = guide.title.toLowerCase().includes(q);
        const matchTitleLocal = localized?.title.toLowerCase().includes(q);
        const matchSummary = localized?.summary.toLowerCase().includes(q);
        const matchTags = guide.tags.some((t) => t.toLowerCase().includes(q));
        const matchTools = guide.requiredTools.some((t) => t.toLowerCase().includes(q));
        const matchMaterials = guide.requiredMaterials.some((m) => m.toLowerCase().includes(q));
        const matchSymptoms = localized?.symptoms.some((s) => s.toLowerCase().includes(q)) ||
          guide.symptoms.some((s) => s.toLowerCase().includes(q));
        const matchSteps = localized?.steps.some((st) =>
          st.title.toLowerCase().includes(q) || st.instruction.toLowerCase().includes(q)
        );

        return (
          matchTitleEn ||
          matchTitleLocal ||
          matchSummary ||
          matchTags ||
          matchTools ||
          matchMaterials ||
          matchSymptoms ||
          matchSteps
        );
      }

      return true;
    });
  }, [
    searchQuery,
    selectedCategory,
    selectedDifficulty,
    filterBySelectedLanguageOnly,
    selectedLanguage,
    showBookmarksOnly,
    bookmarkedIds,
  ]);

  // Active guide details
  const activeGuide = useMemo(() => {
    if (!activeGuideId) return filteredGuides[0] || REPAIR_GUIDES[0];
    return REPAIR_GUIDES.find((g) => g.id === activeGuideId) || filteredGuides[0] || REPAIR_GUIDES[0];
  }, [activeGuideId, filteredGuides]);

  // Localized content for the active guide
  const activeLocalized = useMemo(() => {
    if (!activeGuide) return null;
    return activeGuide.translations[selectedLanguage] || activeGuide.translations.en || null;
  }, [activeGuide, selectedLanguage]);

  // Audio Playback of Procedure
  const handleToggleAudio = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    if (!activeLocalized) return;

    // Build speech text from localized steps
    const speechLines: string[] = [];
    speechLines.push(`${activeLocalized.title}.`);
    speechLines.push(`Summary: ${activeLocalized.summary}.`);
    if (activeLocalized.safetyWarning) {
      speechLines.push(`Safety warning: ${activeLocalized.safetyWarning}.`);
    }

    activeLocalized.steps.forEach((step) => {
      speechLines.push(`Step ${step.stepNumber}: ${step.title}. ${step.instruction}`);
      if (step.safetyWarning) {
        speechLines.push(`Warning: ${step.safetyWarning}`);
      }
      if (step.proTip) {
        speechLines.push(`Pro tip: ${step.proTip}`);
      }
    });

    const fullText = speechLines.join(' ');
    setIsSpeaking(true);
    speakText(fullText, selectedLanguage, () => {
      setIsSpeaking(false);
    });
  };

  // Copy procedure to clipboard
  const handleCopyProcedure = async (guide: RepairGuide) => {
    const loc = guide.translations[selectedLanguage] || guide.translations.en;
    if (!loc) return;

    const text = [
      `=== REPAIR PROCEDURE: ${loc.title.toUpperCase()} ===`,
      `Language: ${currentLangObj.nativeLabel} (${currentLangObj.label})`,
      `Estimated Duration: ~${guide.estimatedMinutes} minutes | Difficulty: ${guide.difficulty.toUpperCase()}`,
      `Category: ${guide.categoryLabel}`,
      '',
      `SUMMARY:`,
      loc.summary,
      '',
      `SYMPTOMS:`,
      ...loc.symptoms.map((s) => `• ${s}`),
      '',
      `REQUIRED TOOLS:`,
      ...guide.requiredTools.map((t) => `• ${t}`),
      '',
      `REQUIRED MATERIALS:`,
      ...guide.requiredMaterials.map((m) => `• ${m}`),
      '',
      `STEP-BY-STEP REPAIR PROTOCOL:`,
      ...loc.steps.map((st) => [
        `Step ${st.stepNumber}: ${st.title}`,
        `  ${st.instruction}`,
        st.safetyWarning ? `  ⚠️ SAFETY: ${st.safetyWarning}` : '',
        st.proTip ? `  💡 PRO TIP: ${st.proTip}` : '',
      ].filter(Boolean).join('\n')),
      '',
      loc.safetyWarning ? `OVERALL SAFETY WARNING: ${loc.safetyWarning}` : '',
      `=============================================`,
      `Generated by LeakScan AI - Contractor Field Assistant`,
    ].filter(Boolean).join('\n');

    try {
      await navigator.clipboard.writeText(text);
      setCopiedGuideId(guide.id);
      setTimeout(() => setCopiedGuideId(null), 2500);
    } catch {
      // fallback
    }
  };

  // Save Guide as separate file to Google Drive
  const handleSaveGuideToDrive = async (guide: RepairGuide) => {
    const token = await getAccessToken();
    if (!token) {
      alert('Please connect your Google Drive account first in the Google Drive tab.');
      if (onNavigateToDrive) onNavigateToDrive();
      return;
    }

    const loc = guide.translations[selectedLanguage] || guide.translations.en;
    if (!loc) return;

    setIsSavingToDrive(true);
    setDriveSaveSuccess(null);

    try {
      const guideContent = [
        `=================================================================`,
        `LEAKSCAN AI - FIELD REPAIR PROCEDURE GUIDE`,
        `=================================================================`,
        `Procedure:       ${loc.title}`,
        `English Title:   ${guide.title}`,
        `Target Language: ${currentLangObj.nativeLabel} (${currentLangObj.label})`,
        `Category:        ${guide.categoryLabel}`,
        `Difficulty:      ${guide.difficulty.toUpperCase()}`,
        `Estimated Time:  ~${guide.estimatedMinutes} mins`,
        `Export Date:     ${new Date().toLocaleString()}`,
        `=================================================================`,
        ``,
        `EXECUTIVE SUMMARY:`,
        loc.summary,
        ``,
        `INDICATIONS & SYMPTOMS:`,
        ...loc.symptoms.map((s) => `  - ${s}`),
        ``,
        `REQUIRED TOOLS:`,
        ...guide.requiredTools.map((t) => `  [ ] ${t}`),
        ``,
        `REQUIRED MATERIALS:`,
        ...guide.requiredMaterials.map((m) => `  [ ] ${m}`),
        ``,
        `STEP-BY-STEP INSTRUCTIONS:`,
        ...loc.steps.map((st) => [
          `-----------------------------------------------------------------`,
          `STEP ${st.stepNumber}: ${st.title.toUpperCase()}`,
          `INSTRUCTION: ${st.instruction}`,
          st.safetyWarning ? `SAFETY NOTE: ${st.safetyWarning}` : '',
          st.proTip ? `PRO TIP:     ${st.proTip}` : '',
        ].filter(Boolean).join('\n')),
        `-----------------------------------------------------------------`,
        loc.safetyWarning ? `\nSAFETY MANDATE: ${loc.safetyWarning}\n` : '',
        `=================================================================`,
        `Exported for Field Technicians - LeakScan AI`,
      ].filter(Boolean).join('\n');

      const safeName = guide.title.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 30);
      const filename = `Guide_${safeName}_${selectedLanguage.toUpperCase()}_${Date.now()}.txt`;

      await saveLogToDrive(token, filename, guideContent, 'Plumbing Field Repair Guide');
      setDriveSaveSuccess(filename);
      setTimeout(() => setDriveSaveSuccess(null), 4000);
    } catch (err: any) {
      alert(`Could not save to Drive: ${err?.message || 'Unknown error'}`);
    } finally {
      setIsSavingToDrive(false);
    }
  };

  // Check if a material name matches any van stock item
  const checkVanInventory = (materialName: string) => {
    if (!stockItems || stockItems.length === 0) return null;
    const clean = materialName.toLowerCase();
    const matched = stockItems.find(
      (item) =>
        item.name.toLowerCase().includes(clean.slice(0, 10)) ||
        clean.includes(item.name.toLowerCase().slice(0, 10))
    );
    return matched;
  };

  // If user is on Free tier, display the Standard Subscription layout & Paywall
  if (subscriptionTier === 'free') {
    return (
      <RepairGuidesPaywall
        currentTier={subscriptionTier}
        selectedLanguage={selectedLanguage}
        onUpgradeToStandard={() => {
          if (onSelectTier) onSelectTier('standard');
        }}
        onSelectTier={(tier) => {
          if (onSelectTier) onSelectTier(tier);
        }}
        onOpenFullModal={() => {
          if (onOpenSubscriptionModal) onOpenSubscriptionModal();
        }}
      />
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Active Subscriber Status Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 px-4 rounded-xl bg-gradient-to-r from-amber-500/15 via-slate-900 to-slate-900 border border-amber-500/30 text-xs">
        <div className="flex items-center gap-2">
          <span className="p-1 rounded-md bg-amber-500/20 text-amber-400">
            <Sparkles className="w-3.5 h-3.5" />
          </span>
          <span className="font-bold text-amber-300">
            {subscriptionTier === 'enterprise'
              ? '👑 Titan Mechanical Enterprise Plan Active'
              : subscriptionTier === 'pro'
              ? '⭐ Master Pro Fleet Plan Active'
              : '⚡ Journeyman Standard Plan Active'}
          </span>
          <span className="text-slate-400 hidden sm:inline">
            — Full access to 10+ factory repair procedures, 7 languages &amp; digital customer sign-offs.
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onOpenSubscriptionModal && (
            <button
              onClick={onOpenSubscriptionModal}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium text-[11px] border border-slate-700 transition-colors"
            >
              Manage Subscription
            </button>
          )}
          {onSelectTier && (
            <button
              onClick={() => onSelectTier('free')}
              className="px-2 py-1 rounded-lg text-slate-500 hover:text-slate-300 font-mono text-[10px] transition-colors"
              title="Test the locked free version view"
            >
              (Switch to Free)
            </button>
          )}
        </div>
      </div>

      {/* Hero Header & Language Filter Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <BookOpen className="w-5 h-5" />
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Contractor Field Procedures
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                {REPAIR_GUIDES.length} Standard Guides
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Plumbing Repair Guides & SOPs
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              Search step-by-step repair procedures, required van parts, and safety instructions,
              filtered and translated in your preferred language.
            </p>
          </div>

          {/* Language Filter Pill Selector */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2.5 bg-slate-950/80 p-2.5 rounded-xl border border-slate-800 text-xs w-full lg:w-auto">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-amber-400" />
              <span className="text-slate-400 font-medium">Language:</span>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {LANGUAGES.map((lang) => {
                const isSelected = selectedLanguage === lang.code;
                return (
                  <button
                    key={lang.code}
                    onClick={() => setSelectedLanguage(lang.code)}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                        : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    <span>{lang.flag}</span>
                    <span>{lang.nativeLabel}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Active Filter Notification Bar */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>
              Filtering by: <strong className="text-amber-300">{currentLangObj.flag} {currentLangObj.nativeLabel} ({currentLangObj.label})</strong>
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">
              {filteredGuides.length} matching {filteredGuides.length === 1 ? 'procedure' : 'procedures'} found
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Filter by selected language toggle */}
            <label className="flex items-center gap-2 cursor-pointer select-none text-slate-300 hover:text-white">
              <input
                type="checkbox"
                checked={filterBySelectedLanguageOnly}
                onChange={(e) => setFilterBySelectedLanguageOnly(e.target.checked)}
                className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400 bg-slate-950 border-slate-700"
              />
              <span className="font-semibold text-xs">
                Filter guides available in {currentLangObj.nativeLabel}
              </span>
            </label>

            {/* Bookmarks toggle */}
            <button
              onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                showBookmarksOnly
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white border border-slate-700'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>Saved ({bookmarkedIds.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search and Category Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 shadow-lg">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          {/* Main Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search repair procedures in ${currentLangObj.nativeLabel} or English (e.g. copper, PEX, P-trap, TPR valve, wax ring, PRV)...`}
              className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white bg-slate-800 px-1.5 py-0.5 rounded"
              >
                Clear
              </button>
            )}
          </div>

          {/* Difficulty Dropdown Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 hidden sm:block" />
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-amber-500"
            >
              <option value="all">All Difficulties</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced (Master Tech)</option>
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', label: 'All Categories' },
            { id: 'water_supply', label: 'Water Supply' },
            { id: 'drainage', label: 'Drainage & Waste' },
            { id: 'water_heaters', label: 'Water Heaters' },
            { id: 'fixtures', label: 'Fixtures & Faucets' },
            { id: 'valves', label: 'Valves & Pressure' },
            { id: 'emergency', label: 'Emergency Fixes' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area: Split View (List on left, Detailed Guide on right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Guides List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-semibold">
            <span>Procedures ({filteredGuides.length})</span>
            {searchQuery && (
              <span className="text-amber-400">
                Matches for "{searchQuery}"
              </span>
            )}
          </div>

          {filteredGuides.length === 0 ? (
            <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 space-y-3">
              <BookOpen className="w-10 h-10 mx-auto text-slate-600" />
              <p className="font-bold text-slate-200">No procedures matched your filters</p>
              <p className="text-xs">
                Try clearing your search query or unchecking "Filter guides available in {currentLangObj.nativeLabel}".
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                  setSelectedDifficulty('all');
                  setFilterBySelectedLanguageOnly(false);
                  setShowBookmarksOnly(false);
                }}
                className="inline-flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 font-bold mt-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset all filters</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[800px] overflow-y-auto pr-1">
              {filteredGuides.map((guide) => {
                const isSelected = activeGuide?.id === guide.id;
                const loc = guide.translations[selectedLanguage] || guide.translations.en;
                const isBookmarked = bookmarkedIds.includes(guide.id);
                const hasNativeTranslation = guide.supportedLanguages.includes(selectedLanguage);

                return (
                  <div
                    key={guide.id}
                    onClick={() => {
                      setActiveGuideId(guide.id);
                      if (isSpeaking) {
                        stopSpeaking();
                        setIsSpeaking(false);
                      }
                    }}
                    className={`p-4 rounded-xl border text-left cursor-pointer transition-all relative ${
                      isSelected
                        ? 'bg-slate-800/95 border-amber-500 shadow-md ring-1 ring-amber-500/40'
                        : 'bg-slate-900 hover:bg-slate-850 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              guide.difficulty === 'beginner'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : guide.difficulty === 'intermediate'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}
                          >
                            {guide.difficulty.toUpperCase()}
                          </span>

                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300">
                            {guide.categoryLabel}
                          </span>

                          <span className="flex items-center gap-1 text-[11px] text-slate-400">
                            <Clock className="w-3 h-3 text-slate-500" />
                            ~{guide.estimatedMinutes}m
                          </span>

                          {hasNativeTranslation && (
                            <span
                              className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 flex items-center gap-1"
                              title={`Translated into ${currentLangObj.label}`}
                            >
                              <span>{currentLangObj.flag}</span>
                              <span className="text-[9px]">Verified</span>
                            </span>
                          )}
                        </div>

                        {/* Title in Selected Language */}
                        <h3 className="font-bold text-sm text-slate-100 leading-snug">
                          {loc?.title || guide.title}
                        </h3>

                        {/* English subtitle if viewing in other language */}
                        {selectedLanguage !== 'en' && (
                          <div className="text-[11px] text-slate-400 italic">
                            EN: {guide.title}
                          </div>
                        )}
                      </div>

                      {/* Bookmark Icon Button */}
                      <button
                        onClick={(e) => toggleBookmark(guide.id, e)}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isBookmarked
                            ? 'text-amber-400 bg-amber-500/10'
                            : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800'
                        }`}
                        title={isBookmarked ? 'Remove bookmark' : 'Bookmark for offline reference'}
                      >
                        {isBookmarked ? (
                          <BookmarkCheck className="w-4 h-4 fill-amber-400" />
                        ) : (
                          <Bookmark className="w-4 h-4" />
                        )}
                      </button>
                    </div>

                    {/* Summary Snippet */}
                    <p className="text-xs text-slate-400 line-clamp-2 mt-2 leading-relaxed">
                      {loc?.summary}
                    </p>

                    {/* Footer pills & chevron */}
                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <div className="flex items-center gap-2">
                        <span>{loc?.steps.length || 0} steps</span>
                        <span>•</span>
                        <span>{guide.requiredMaterials.length} materials</span>
                      </div>
                      <div className="flex items-center gap-1 text-amber-400 font-semibold group">
                        <span>View Protocol</span>
                        <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Detailed Procedure Protocol Card */}
        <div className="lg:col-span-7">
          {activeGuide && activeLocalized ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 space-y-6 shadow-2xl relative">
              {/* Header section with Actions */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                        activeGuide.difficulty === 'beginner'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : activeGuide.difficulty === 'intermediate'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {activeGuide.difficulty.toUpperCase()} PROCEDURE
                    </span>

                    <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                      {activeGuide.categoryLabel}
                    </span>

                    <span className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      Est. Time: ~{activeGuide.estimatedMinutes} mins
                    </span>
                  </div>

                  {/* Audio Speaker & Actions Toolbar */}
                  <div className="flex items-center gap-2">
                    {/* Audio TTS Button */}
                    <button
                      onClick={handleToggleAudio}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm ${
                        isSpeaking
                          ? 'bg-amber-500 text-slate-950 animate-pulse'
                          : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700'
                      }`}
                      title="Listen to hands-free voice audio instructions"
                    >
                      {isSpeaking ? (
                        <>
                          <VolumeX className="w-4 h-4" />
                          <span>Stop Voice</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-4 h-4 text-amber-400" />
                          <span>Audio Guide ({currentLangObj.flag})</span>
                        </>
                      )}
                    </button>

                    {/* Copy Procedure Button */}
                    <button
                      onClick={() => handleCopyProcedure(activeGuide)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                      title="Copy complete repair instructions to clipboard"
                    >
                      {copiedGuideId === activeGuide.id ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    {/* Save to Drive Button */}
                    <button
                      onClick={() => handleSaveGuideToDrive(activeGuide)}
                      disabled={isSavingToDrive}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-xs font-bold transition-all"
                      title="Save this guide as a separate file in your Google Drive"
                    >
                      <HardDrive className="w-3.5 h-3.5 text-blue-400" />
                      <span>{isSavingToDrive ? 'Saving...' : 'Save to Drive'}</span>
                    </button>

                    {/* Customer Sign-Off on Repair Button */}
                    <button
                      onClick={() => setShowSignOffModal(true)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-bold transition-all shadow-sm"
                      title="Capture customer signature sign-off on this completed procedure"
                    >
                      <PenTool className="w-3.5 h-3.5 text-amber-400" />
                      <span>Customer Sign-Off</span>
                    </button>
                  </div>
                </div>

                {signOffSuccessMessage && (
                  <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span>{signOffSuccessMessage}</span>
                    </span>
                    <button
                      onClick={() => setShowSignOffModal(true)}
                      className="underline text-emerald-200 hover:text-white font-bold ml-2"
                    >
                      View Certificate
                    </button>
                  </div>
                )}

                {driveSaveSuccess && (
                  <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Saved <strong>{driveSaveSuccess}</strong> as separate file to Google Drive!</span>
                    </span>
                    {onNavigateToDrive && (
                      <button
                        onClick={onNavigateToDrive}
                        className="underline text-emerald-200 hover:text-white font-bold ml-2"
                      >
                        Open Drive
                      </button>
                    )}
                  </div>
                )}

                {/* Primary Title in Selected Language */}
                <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
                  {activeLocalized.title}
                </h2>

                {/* Secondary English reference title if viewing in another language */}
                {selectedLanguage !== 'en' && (
                  <p className="text-xs text-slate-400">
                    <strong className="text-slate-300">English Standard:</strong> {activeGuide.title}
                  </p>
                )}

                {/* Summary */}
                <p className="text-sm text-slate-300 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 leading-relaxed">
                  {activeLocalized.summary}
                </p>
              </div>

              {/* Symptoms / Clinical Indications */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Symptom Verification & Leak Signs</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeLocalized.symptoms.map((symptom, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2 p-2.5 bg-slate-950/50 rounded-lg border border-slate-800 text-xs text-slate-300"
                    >
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{symptom}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Required Tools and Materials with Van Stock Audit */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Tools */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-amber-400" />
                    <span>Required Field Tools</span>
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {activeGuide.requiredTools.map((tool, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{tool}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Materials & Van Stock availability */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-amber-400" />
                    <span>Required Parts & Van Stock Check</span>
                  </h4>
                  <ul className="space-y-2 text-xs">
                    {activeGuide.requiredMaterials.map((mat, idx) => {
                      const vanMatch = checkVanInventory(mat);
                      return (
                        <li
                          key={idx}
                          className="flex items-center justify-between gap-2 p-1.5 rounded-lg bg-slate-900 border border-slate-800/80"
                        >
                          <span className="text-slate-200 font-medium leading-tight">{mat}</span>
                          {vanMatch ? (
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                                vanMatch.quantity > 0
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              }`}
                            >
                              Van: {vanMatch.quantity} in stock
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-400 shrink-0">
                              Standard Part
                            </span>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>

              {/* Step-by-Step Procedure Instructions */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span>Step-by-Step Protocol ({currentLangObj.nativeLabel})</span>
                  </h4>
                  <span className="text-xs text-slate-400">
                    {activeLocalized.steps.length} sequential steps
                  </span>
                </div>

                <div className="space-y-3.5">
                  {activeLocalized.steps.map((step) => (
                    <div
                      key={step.stepNumber}
                      className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0">
                          {step.stepNumber}
                        </span>
                        <h5 className="font-bold text-sm text-slate-100">
                          {step.title}
                        </h5>
                      </div>

                      <p className="text-xs sm:text-sm text-slate-300 pl-8 leading-relaxed">
                        {step.instruction}
                      </p>

                      {step.safetyWarning && (
                        <div className="ml-8 mt-2 p-2.5 rounded-lg bg-rose-950/40 border border-rose-500/30 flex items-start gap-2 text-xs text-rose-300">
                          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                          <span>
                            <strong>Safety Warning:</strong> {step.safetyWarning}
                          </span>
                        </div>
                      )}

                      {step.proTip && (
                        <div className="ml-8 mt-2 p-2.5 rounded-lg bg-amber-950/30 border border-amber-500/30 flex items-start gap-2 text-xs text-amber-300">
                          <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <span>
                            <strong>Master Tech Pro Tip:</strong> {step.proTip}
                          </span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Customer Sign-off on Completed Repair Protocol */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/20 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <h5 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <FileCheck className="w-4 h-4 text-emerald-400" />
                      <span>Repair Completed? Capture Customer Sign-Off</span>
                    </h5>
                  </div>
                  <p className="text-xs text-slate-400">
                    Capture homeowner/property manager signature, verify hydrostatic leak testing, and issue signed work order completion slip.
                  </p>
                </div>

                <button
                  onClick={() => setShowSignOffModal(true)}
                  className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-amber-500/25 shrink-0"
                >
                  <PenTool className="w-4 h-4" />
                  <span>Open Signature Pad</span>
                </button>
              </div>

              {/* Bottom Quick-Action Buttons */}
              <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  {onNavigateToScan && (
                    <button
                      onClick={onNavigateToScan}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-amber-500/20"
                    >
                      <Camera className="w-4 h-4" />
                      <span>Diagnose with AI Camera</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleCopyProcedure(activeGuide)}
                    className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold border border-slate-700 transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Copy All Steps</span>
                  </button>
                </div>

                <div className="text-xs text-slate-400 italic">
                  Guide complies with IPC (International Plumbing Code) standards.
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-400">
              Select a procedure on the left to view instructions.
            </div>
          )}
        </div>
      </div>

      {/* Customer Sign-Off Modal */}
      {activeLocalized && (
        <CustomerSignOffModal
          isOpen={showSignOffModal}
          onClose={() => setShowSignOffModal(false)}
          procedureTitle={activeLocalized.title}
          availableJobs={jobs}
          onConfirmSignOff={(signOff, jobId) => {
            if (jobId && onSaveJobSignOff) {
              onSaveJobSignOff(jobId, signOff);
            }
            setSignOffSuccessMessage(`Customer sign-off successfully recorded for ${signOff.signerName}!`);
            setTimeout(() => setSignOffSuccessMessage(null), 6000);
          }}
          onNavigateToDrive={onNavigateToDrive}
        />
      )}
    </div>
  );
};
