import React, { useState } from 'react';
import {
  Truck,
  Lock,
  Sparkles,
  Check,
  Package,
  AlertTriangle,
  ShoppingCart,
  ArrowRight,
  ShieldCheck,
  DollarSign,
  Layers,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { SubscriptionTier, StockItem, Van } from '../types';
import { SUBSCRIPTION_PLANS } from '../data/subscriptionPlans';

interface VanStockPaywallProps {
  currentTier: SubscriptionTier;
  vans: Van[];
  stockItems: StockItem[];
  onSelectTier: (tier: SubscriptionTier) => void;
  onOpenSubscriptionModal: () => void;
}

export const VanStockPaywall: React.FC<VanStockPaywallProps> = ({
  currentTier,
  vans,
  stockItems,
  onSelectTier,
  onOpenSubscriptionModal,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const proPlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'pro') || SUBSCRIPTION_PLANS[2];
  const enterprisePlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'enterprise') || SUBSCRIPTION_PLANS[3];

  const proPrice = billingCycle === 'annual' ? proPlan.priceAnnual : proPlan.priceMonthly;

  // Sample items to show as teaser
  const previewItems = stockItems.slice(0, 5);

  return (
    <div className="space-y-8 animate-in fade-in duration-200 pb-12">
      {/* Hero Paywall Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/50 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-400 text-xs font-black uppercase tracking-wider mb-3">
            <Lock className="w-3.5 h-3.5" />
            <span>Master Pro &amp; Titan Enterprise Feature</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight flex items-center gap-3">
            <span className="p-2 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Truck className="w-7 h-7 sm:w-8 h-8" />
            </span>
            <span>Van Stock Inventory Tracking &amp; Restock POs</span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
            Stop losing $1,000s in forgotten inventory and wasted trips to Ferguson. 
            <span className="text-amber-400 font-bold"> Master Pro Fleet</span> unlocks real-time parts counting, low-stock threshold alerts, bin locations, wholesale vs retail profit margins, and one-click supply house order generation.
          </p>

          {/* Quick Value Props */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 text-xs">
            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Package className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Bin Locations</div>
                <div className="text-[10px] text-slate-400">Racks, Shelves &amp; Bins</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Low-Stock Alerts</div>
                <div className="text-[10px] text-slate-400">Automated restock list</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Profit Margins</div>
                <div className="text-[10px] text-slate-400">Wholesale cost vs retail</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-slate-200">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <ShoppingCart className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold">Ferguson POs</div>
                <div className="text-[10px] text-slate-400">1-Click supply order</div>
              </div>
            </div>
          </div>

          {/* CTA Row */}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSelectTier('pro')}
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Unlock Van Stock (Upgrade to Master Pro)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenSubscriptionModal}
              className="px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors border border-slate-700"
            >
              Compare All 4 Plans
            </button>

            {/* Quick 1-Click Demo Simulator */}
            <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950/90 border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mr-1">Demo:</span>
              <button
                onClick={() => onSelectTier('free')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'free' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Free
              </button>
              <button
                onClick={() => onSelectTier('standard')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'standard' ? 'bg-blue-600 text-white' : 'text-blue-400 hover:text-blue-300'
                }`}
              >
                Standard
              </button>
              <button
                onClick={() => onSelectTier('pro')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'pro' ? 'bg-amber-500 text-slate-950' : 'text-amber-400 hover:text-amber-300'
                }`}
              >
                Pro
              </button>
              <button
                onClick={() => onSelectTier('enterprise')}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  currentTier === 'enterprise' ? 'bg-purple-600 text-white' : 'text-purple-400 hover:text-purple-300'
                }`}
              >
                Enterprise
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Teaser Preview: Locked Van Stock Interface */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Van Fleet Inventory Catalog Preview</span>
            </h3>
            <p className="text-xs text-slate-400">
              Live tracking for {vans.length} vehicles &amp; {stockItems.length} active parts in fleet.
            </p>
          </div>
          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
            <Lock className="w-3 h-3" />
            <span>Subscriber Locked</span>
          </span>
        </div>

        {/* Blurred Teaser Table with Floating Unlock Pill */}
        <div className="relative rounded-xl border border-slate-800 overflow-hidden bg-slate-950/70">
          <div className="filter blur-[2px] opacity-40 pointer-events-none p-4 space-y-3">
            {previewItems.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded bg-slate-800 text-amber-400">
                    <Package className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-white">{item.name}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {item.sku} • {item.binLocation}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4 font-mono">
                  <span className="text-slate-400">{item.quantity} units</span>
                  <span className="text-emerald-400 font-bold">${item.retailPrice.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Overlay CTA */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs text-center space-y-3">
            <div className="p-3 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 shadow-xl">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white">
                Unlock Van Stock Inventory on Master Pro
              </h4>
              <p className="text-xs text-slate-300 max-w-md mt-1">
                Keep every rig stocked with SharkBite fittings, copper tubing, valves, and PRVs with automated low-stock warnings.
              </p>
            </div>
            <button
              onClick={() => onSelectTier('pro')}
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2"
            >
              <span>Activate Master Pro Plan ($95/mo)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
