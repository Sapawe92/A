import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const LeakScanLogo: React.FC<LogoProps> = ({ size = 'md', showText = true }) => {
  const boxDimensions =
    size === 'sm'
      ? 'w-8 h-8 rounded-lg'
      : size === 'lg'
      ? 'w-12 h-12 rounded-2xl'
      : 'w-11 h-11 rounded-xl';

  return (
    <div className="flex items-center gap-2.5">
      {/* Contractor orange badge with enlarged magnifying glass & droplet dripping into the pond */}
      <div
        className={`relative flex items-center justify-center ${boxDimensions} bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/25 group-hover:scale-105 transition-all duration-200 shrink-0 overflow-hidden ring-1 ring-inset ring-amber-300/40`}
      >
        <svg
          viewBox="0 0 36 36"
          className="w-full h-full select-none"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Water droplet gradient */}
            <linearGradient id="dropGrad" x1="15" y1="5.5" x2="15" y2="26.5" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#60a5fa" />
              <stop offset="55%" stopColor="#2563eb" />
              <stop offset="100%" stopColor="#1d4ed8" />
            </linearGradient>

            {/* Pond gradient */}
            <linearGradient id="pondGrad" x1="18" y1="27" x2="18" y2="36" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#2563eb" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#1e3a8a" stopOpacity="0.98" />
            </linearGradient>

            {/* Lens subtle glass tint */}
            <linearGradient id="lensTint" x1="8" y1="5" x2="22" y2="21" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#0f172a" stopOpacity="0.12" />
            </linearGradient>
          </defs>

          {/* === BIGGER MAGNIFYING GLASS === */}
          {/* Lens Glass Tint */}
          <circle cx="15" cy="13" r="9.3" fill="url(#lensTint)" />

          {/* Bold Magnifier Outer Frame */}
          <circle
            cx="15"
            cy="13"
            r="9.5"
            stroke="#090d16"
            strokeWidth="2.6"
          />

          {/* Top Lens Reflection Arc */}
          <path
            d="M 9.8 9 A 7.5 7.5 0 0 1 19.5 7.5"
            stroke="#ffffff"
            strokeOpacity="0.55"
            strokeWidth="1"
            strokeLinecap="round"
          />

          {/* Bold Magnifier Handle */}
          <path
            d="M 21.8 19.8 L 30 28"
            stroke="#090d16"
            strokeWidth="3.2"
            strokeLinecap="round"
          />

          {/* Handle Grip Detail */}
          <path
            d="M 24 22 L 28.2 26.2"
            stroke="#334155"
            strokeWidth="1.8"
            strokeLinecap="round"
          />

          {/* === WATER DROPLET DRIPPING DOWN INTO THE POND (REDUCED & REFINED) === */}
          {/* Main Droplet inside the Lens - a bit smaller and centered */}
          <path
            d="M 15 7.8 C 15 7.8 11.2 12.0 11.2 14.2 C 11.2 16.3 12.9 18.0 15 18.0 C 17.1 18.0 18.8 16.3 18.8 14.2 C 18.8 12.0 15 7.8 15 7.8 Z"
            fill="url(#dropGrad)"
            stroke="#1e40af"
            strokeWidth="0.5"
          />

          {/* Droplet Highlight / Curved Shine */}
          <path
            d="M 13.0 12.6 C 12.5 13.6 12.8 15.4 14.0 16.2"
            stroke="#ffffff"
            strokeOpacity="0.9"
            strokeWidth="0.9"
            strokeLinecap="round"
          />

          {/* Droplet Specular Sparkle */}
          <circle cx="16.6" cy="12.2" r="0.55" fill="#ffffff" fillOpacity="0.9" />

          {/* Dripping Water Stream / Falling Drip Bead into the Pond */}
          <path
            d="M 15 20.2 C 14.3 20.2 14.0 21.6 14.3 23.4 C 14.5 24.6 15 26.2 15 26.2 C 15 26.2 15.5 24.6 15.7 23.4 C 16.0 21.6 15.7 20.2 15 20.2 Z"
            fill="url(#dropGrad)"
          />

          {/* Tiny drip highlight */}
          <ellipse cx="14.7" cy="23.0" rx="0.3" ry="0.8" fill="#bfdbfe" fillOpacity="0.8" />

          {/* === PUDDLE OF WATER AT THE BOTTOM (A BIT SMALLER & LOWER PROFILE) === */}
          {/* Fluid Puddle Water Base - lowered profile */}
          <path
            d="M -2 36 L -2 32.2 C 4 31.4 9 32.6 14 31.5 C 19 30.6 24 31.8 38 31.0 L 38 36 Z"
            fill="url(#pondGrad)"
          />

          {/* Glowing Surface Liquid Rim */}
          <path
            d="M -2 32.2 C 4 31.4 9 32.6 14 31.5 C 19 30.6 24 31.8 38 31.0"
            stroke="#38bdf8"
            strokeWidth="0.9"
            strokeLinecap="round"
            fill="none"
          />

          {/* Concentric Impact Ripples where Drip hits the Puddle - more compact */}
          <ellipse
            cx="15"
            cy="31.8"
            rx="2.6"
            ry="0.65"
            stroke="#7dd3fc"
            strokeWidth="0.75"
            fill="none"
          />

          <ellipse
            cx="15"
            cy="32.8"
            rx="5.0"
            ry="1.0"
            stroke="#60a5fa"
            strokeWidth="0.65"
            strokeOpacity="0.9"
            fill="none"
          />

          <ellipse
            cx="15"
            cy="34.0"
            rx="8.0"
            ry="1.3"
            stroke="#93c5fd"
            strokeWidth="0.5"
            strokeOpacity="0.6"
            fill="none"
          />

          {/* Puddle water gloss reflection across the base */}
          <ellipse
            cx="24.5"
            cy="34.2"
            rx="3.8"
            ry="0.7"
            fill="#93c5fd"
            fillOpacity="0.45"
          />
        </svg>
      </div>

      {showText && (
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-lg font-black tracking-tight text-white">LEAKSCAN</span>
            <span className="text-xs font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
              AI PRO
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden sm:block">Contractor Field Operations & Diagnostics</p>
        </div>
      )}
    </div>
  );
};
