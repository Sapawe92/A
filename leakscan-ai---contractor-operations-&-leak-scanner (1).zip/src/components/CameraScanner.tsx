import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  RefreshCw,
  Volume2,
  VolumeX,
  CheckCircle2,
  AlertTriangle,
  Package,
  FileText,
  DollarSign,
  Clock,
  Sparkles,
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  Share2,
  Printer,
  X,
  Flame,
  Check,
  Search,
  Mic,
  MicOff,
  Loader2,
  StopCircle,
  HardDrive,
  Cloud,
  ExternalLink,
  Smartphone,
  QrCode,
  Images,
  Plus,
  ScrollText,
} from 'lucide-react';
import { TechLanguage, LeakDiagnosis, Van, StockItem } from '../types';
import { LANGUAGES, SAMPLE_LEAK_PRESETS } from '../data/mockData';
import { speakText, stopSpeaking } from '../utils/audioPlayer';
import { getAccessToken, googleSignIn } from '../services/googleAuth';
import { uploadPhotoToDrive, saveReportToDrive, saveLogToDrive, DriveFileItem } from '../services/googleDrive';
import { TestOnPhoneModal } from './TestOnPhoneModal';

interface CameraScannerProps {
  selectedLanguage: TechLanguage;
  setSelectedLanguage: (lang: TechLanguage) => void;
  vans: Van[];
  stockItems: StockItem[];
  onDeductPartsFromVan: (parts: Array<{ name: string; quantity: number }>, vanId: string) => void;
  onAddEstimateToJobs: (diagnosis: LeakDiagnosis, customerName?: string, address?: string) => void;
  initialImage?: string | null;
  initialNotes?: string;
  onNavigateToDrive?: () => void;
}

export const CameraScanner: React.FC<CameraScannerProps> = ({
  selectedLanguage,
  setSelectedLanguage,
  vans,
  stockItems,
  onDeductPartsFromVan,
  onAddEstimateToJobs,
  initialImage,
  initialNotes,
  onNavigateToDrive,
}) => {
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [capturedImages, setCapturedImages] = useState<string[]>(
    initialImage ? [initialImage] : []
  );
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const capturedImage = capturedImages[activeImageIndex] || capturedImages[0] || null;
  const [selectedVanId, setSelectedVanId] = useState<string>(vans[0]?.id || 'van-1');
  const [jobNotes, setJobNotes] = useState<string>(initialNotes || '');
  const [quickTags, setQuickTags] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [diagnosis, setDiagnosis] = useState<LeakDiagnosis | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [showPhoneModal, setShowPhoneModal] = useState<boolean>(false);

  // Audio / Speech state
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const cancelSpeechRef = useRef<(() => void) | null>(null);

  // Success notifications
  const [stockDeductedSuccess, setStockDeductedSuccess] = useState<boolean>(false);
  const [jobAddedSuccess, setJobAddedSuccess] = useState<boolean>(false);

  // Video stream ref
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Voice-to-Text Recording state (gemini-3.5-transcribe)
  const [isRecordingVoice, setIsRecordingVoice] = useState<boolean>(false);
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);

  const currentLang = LANGUAGES.find((l) => l.code === selectedLanguage) || LANGUAGES[0];
  const selectedVan = vans.find((v) => v.id === selectedVanId) || vans[0];

  // Quick preset tags
  const COMMON_TAGS = [
    'Basement pipe leak',
    'Under sink blowout',
    'Water heater drip',
    'Pinhole copper spray',
    'Corroded shutoff valve',
    'Slab leak pooling',
  ];

  // Start camera
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setCameraError('Camera access unavailable. You can upload a photo or pick a contractor preset below.');
      setCameraActive(false);
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCamera();
      stopSpeaking();
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Start voice dictation recording
  const startVoiceRecording = async () => {
    setVoiceError(null);
    audioChunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : MediaRecorder.isTypeSupported('audio/mp4')
        ? 'audio/mp4'
        : '';

      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: recorder.mimeType || 'audio/webm',
        });
        if (audioStreamRef.current) {
          audioStreamRef.current.getTracks().forEach((track) => track.stop());
          audioStreamRef.current = null;
        }

        if (audioBlob.size > 0) {
          await transcribeAudioBlob(audioBlob, recorder.mimeType || 'audio/webm');
        }
      };

      recorder.start(250);
      setIsRecordingVoice(true);
      setRecordingDuration(0);

      // Start duration counter
      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => {
          if (prev >= 60) {
            stopVoiceRecording();
            return 60;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err: any) {
      console.warn('Microphone access denied:', err);
      setVoiceError('Microphone permission required for voice dictation. Please enable microphone access.');
      setIsRecordingVoice(false);
    }
  };

  // Stop voice dictation and trigger transcription with gemini-3.5-transcribe
  const stopVoiceRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecordingVoice(false);
  };

  // Cancel voice dictation without transcribing
  const cancelVoiceRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    audioChunksRef.current = [];
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }
    setIsRecordingVoice(false);
    setRecordingDuration(0);
  };

  // Send audio blob to /api/transcribe-audio
  const transcribeAudioBlob = async (blob: Blob, mimeType: string) => {
    setIsTranscribing(true);
    setVoiceError(null);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Audio = reader.result as string;
        try {
          const res = await fetch('/api/transcribe-audio', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64Audio,
              mimeType: mimeType || 'audio/webm',
              techLanguage: selectedLanguage,
            }),
          });
          const data = await res.json();
          if (data.success && data.transcript) {
            setJobNotes((prev) => (prev ? `${prev}. ${data.transcript}` : data.transcript));
          } else {
            throw new Error(data.error || 'Failed to transcribe');
          }
        } catch (postErr: any) {
          console.error('Transcription API error:', postErr);
          setVoiceError('Could not transcribe audio. Please check network or try again.');
        } finally {
          setIsTranscribing(false);
        }
      };
      reader.readAsDataURL(blob);
    } catch (err: any) {
      console.error('Blob reading error:', err);
      setIsTranscribing(false);
      setVoiceError('Failed to process recorded audio.');
    }
  };

  // Capture snapshot from video
  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setCapturedImages((prev) => {
        const next = [...prev, dataUrl];
        setActiveImageIndex(next.length - 1);
        return next;
      });
      stopCamera();
    }
  };

  // Switch camera facing mode
  const toggleFacingMode = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    if (cameraActive) {
      setTimeout(() => startCamera(), 100);
    }
  };

  // Handle multiple file upload simultaneously
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const fileList = Array.from(files);
      const readPromises = fileList.map((file) => {
        return new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
      });

      Promise.all(readPromises).then((results) => {
        setCapturedImages((prev) => {
          const next = [...prev, ...results];
          setActiveImageIndex(next.length - 1);
          return next;
        });
        stopCamera();
        // Reset file input so same files can be re-selected if needed
        if (fileInputRef.current) fileInputRef.current.value = '';
      });
    }
  };

  // Remove one photo from the multi-upload gallery
  const handleRemovePhoto = (indexToRemove: number) => {
    setCapturedImages((prev) => {
      const updated = prev.filter((_, idx) => idx !== indexToRemove);
      if (activeImageIndex >= updated.length) {
        setActiveImageIndex(Math.max(0, updated.length - 1));
      }
      return updated;
    });
  };

  // Select sample preset
  const selectPreset = (preset: typeof SAMPLE_LEAK_PRESETS[0]) => {
    setCapturedImages([preset.imageUrl]);
    setActiveImageIndex(0);
    setJobNotes(preset.description);
    stopCamera();
  };

  // Trigger AI Analysis with multiple pictures
  const runAiAnalysis = async () => {
    if (capturedImages.length === 0) return;

    setIsAnalyzing(true);
    setDiagnosis(null);
    setStockDeductedSuccess(false);
    setJobAddedSuccess(false);

    // Get current items in selected van to send to AI
    const vanItems = stockItems.filter((i) => i.vanId === selectedVanId);

    try {
      const notesCombined = [
        jobNotes,
        quickTags.length > 0 ? `Tags: ${quickTags.join(', ')}` : '',
        capturedImages.length > 1 ? `[Multiple angles attached: ${capturedImages.length} photos]` : '',
      ].filter(Boolean).join('. ');

      const response = await fetch('/api/scan-leak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: capturedImages[0],
          imagesBase64: capturedImages,
          mimeType: 'image/jpeg',
          techLanguage: selectedLanguage,
          jobNotes: notesCombined,
          vanStockItems: vanItems,
        }),
      });

      const result = await response.json();
      if (result.success && result.data) {
        // Cross-check items with van stock
        const enrichedMaterials = result.data.requiredMaterials.map((mat: any) => {
          const matchInVan = vanItems.find((vi) =>
            vi.name.toLowerCase().includes(mat.name.toLowerCase().slice(0, 10)) ||
            mat.name.toLowerCase().includes(vi.name.toLowerCase().slice(0, 10))
          );
          return {
            ...mat,
            inVanStock: Boolean(matchInVan && matchInVan.quantity >= mat.quantity),
            vanStockCount: matchInVan ? matchInVan.quantity : 0,
          };
        });

        const fullDiagnosis: LeakDiagnosis = {
          ...result.data,
          requiredMaterials: enrichedMaterials,
          imageUrl: capturedImages[0],
          imageUrls: capturedImages,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setDiagnosis(fullDiagnosis);

        // Auto-play spoken repair guidance in tech's native language if available
        if (fullDiagnosis.audioScript) {
          playAudioGuidance(fullDiagnosis.audioScript);
        }
      } else {
        throw new Error(result.error || 'Failed to process leak image');
      }
    } catch (err: any) {
      console.error('Diagnosis failed:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Play audio readout
  const playAudioGuidance = (text: string) => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
      return;
    }

    setIsPlayingAudio(true);
    cancelSpeechRef.current = speakText(text, selectedLanguage, () => {
      setIsPlayingAudio(false);
    });
  };

  // Deduct parts from selected van
  const handleDeductParts = () => {
    if (!diagnosis) return;
    const partsToDeduct = diagnosis.requiredMaterials.map((m) => ({
      name: m.name,
      quantity: m.quantity,
    }));
    onDeductPartsFromVan(partsToDeduct, selectedVanId);
    setStockDeductedSuccess(true);
  };

  // Create job / work order from this estimate
  const handleCreateJob = () => {
    if (!diagnosis) return;
    onAddEstimateToJobs(diagnosis);
    setJobAddedSuccess(true);
  };

  // Google Drive saving state
  // Google Drive saving state
  const [isSavingToDrive, setIsSavingToDrive] = useState<boolean>(false);
  const [isSavingLogOnly, setIsSavingLogOnly] = useState<boolean>(false);
  const [driveSaveSuccess, setDriveSaveSuccess] = useState<{
    photo?: DriveFileItem;
    report?: DriveFileItem;
    logFile?: DriveFileItem;
  } | null>(null);
  const [driveError, setDriveError] = useState<string | null>(null);

  // Sync initialImage / initialNotes props when changed
  useEffect(() => {
    if (initialImage) {
      setCapturedImages([initialImage]);
      setActiveImageIndex(0);
      setDiagnosis(null);
      setDriveSaveSuccess(null);
    }
    if (initialNotes) {
      setJobNotes(initialNotes);
    }
  }, [initialImage, initialNotes]);

  // Build formatted technical diagnostic and audit log text
  const generateDiagnosticLogContent = (safeName: string, timestamp: string) => {
    if (!diagnosis) return '';
    return `================================================================================
LEAKSCAN AI - FIELD DIAGNOSTIC & AUDIT EVENT LOG
================================================================================
Log Generated:       ${new Date().toISOString()} (${new Date().toLocaleString()})
Session ID:          SES-${Date.now().toString(36).toUpperCase()}
Vehicle Assignment:  ${selectedVan.name} (Van ID: ${selectedVan.id})
Technician Language: ${currentLang.nativeLabel} (${currentLang.code})
Camera Angles:       ${capturedImages.length} photo(s) captured & analyzed
Severity Level:      ${diagnosis.severity.toUpperCase()}
Diagnostic Score:    ${diagnosis.confidenceScore || 96}% confidence

--------------------------------------------------------------------------------
[EVENT 01: SYSTEM_SESSION_INIT]
--------------------------------------------------------------------------------
Timestamp:           ${new Date().toISOString()}
Camera Source:       Contractor Field Viewfinder
Photos Analyzed:     ${capturedImages.length} high-resolution inspection frame(s)
Status:              All angles evaluated by Gemini Vision Engine

--------------------------------------------------------------------------------
[EVENT 02: AI_COMPUTER_VISION_DIAGNOSIS]
--------------------------------------------------------------------------------
Detected Fault:      ${diagnosis.issueName}
Localized Term:      ${diagnosis.issueNameLocal || diagnosis.issueName}
Severity Rating:     ${diagnosis.severity.toUpperCase()}
Confidence Index:    ${diagnosis.confidenceScore || 96}%
Detected Root Cause: ${diagnosis.rootCause}
Diagnostic Note:     ${diagnosis.rootCauseLocal || 'N/A'}

--------------------------------------------------------------------------------
[EVENT 03: BILL_OF_MATERIALS & VAN STOCK AUDIT]
--------------------------------------------------------------------------------
Total Requisite Items: ${diagnosis.requiredMaterials.length}
Cross-Reference with Active Van Inventory (${selectedVan.name}):
${diagnosis.requiredMaterials
  .map(
    (m, idx) =>
      `  [#${idx + 1}] ${m.name} | Specs: ${m.specs || 'Std'} | Req Qty: ${m.quantity} | Unit Cost: $${(m.standardRetailPrice || m.unitCost || 0).toFixed(2)} | In Van Stock: ${m.inVanStock ? `YES (Verified: ${m.vanStockCount ?? 'In Stock'})` : 'NO (Supply Run Needed)'}`
  )
  .join('\n')}

--------------------------------------------------------------------------------
[EVENT 04: PRICING & LABOR AUDIT]
--------------------------------------------------------------------------------
Labor Allocation:    ${diagnosis.customerEstimate.laborHours}h @ $${diagnosis.customerEstimate.recommendedLaborRate}/hr
Labor Subtotal:      $${(diagnosis.customerEstimate.laborHours * diagnosis.customerEstimate.recommendedLaborRate).toFixed(2)}
Materials Subtotal:  $${diagnosis.customerEstimate.partsSubtotal.toFixed(2)}
Trip & Diag Fee:     $${diagnosis.customerEstimate.tripDiagnosticFee.toFixed(2)}
Total Gross Quote:   $${diagnosis.customerEstimate.totalEstimate.toFixed(2)}

--------------------------------------------------------------------------------
[EVENT 05: REPAIR PROCEDURAL STEPS]
--------------------------------------------------------------------------------
${diagnosis.repairSteps
  .map(
    (s) =>
      `  Step ${s.stepNumber} [${s.title}]:\n    Instruction: ${s.instruction}${s.safetyWarning ? `\n    [SAFETY WARNING]: ${s.safetyWarning}` : ''}`
  )
  .join('\n')}

--------------------------------------------------------------------------------
[EVENT 06: CONTRACTOR FIELD NOTES]
--------------------------------------------------------------------------------
${jobNotes ? jobNotes : 'No additional field observations entered by technician.'}

--------------------------------------------------------------------------------
[EVENT 07: GOOGLE DRIVE PERSISTENCE RECORD]
--------------------------------------------------------------------------------
Target Folder:       LeakScan AI Reports & Photos
Photos Saved:        ${capturedImages.length} image(s)
Estimate File:       ${safeName}_Estimate_${timestamp}.txt
Audit Log File:      ${safeName}_Diagnostic_Log_${timestamp}.log
Log State:           COMMITTED TO SEPARATE FILE IN GOOGLE DRIVE
================================================================================
END OF DIAGNOSTIC LOG FILE
`;
  };

  // Save current leak scan, photos, estimate & separate log file to Google Drive
  const handleSaveToDrive = async () => {
    if (!diagnosis || capturedImages.length === 0) return;
    setIsSavingToDrive(true);
    setDriveError(null);
    try {
      let token = await getAccessToken();
      if (!token) {
        const signInResult = await googleSignIn();
        token = signInResult?.accessToken || null;
      }
      if (!token) {
        throw new Error('Google sign-in required to save to Drive.');
      }

      const timestamp = new Date().toISOString().slice(0, 10);
      const safeName = diagnosis.issueName.replace(/[^a-zA-Z0-9_-]/g, '_');

      // 1. Upload all captured photos to Drive
      let uploadedPhoto: DriveFileItem | undefined;
      for (let i = 0; i < capturedImages.length; i++) {
        const photoName = `${safeName}_Photo_${i + 1}_${timestamp}.jpg`;
        const photoDesc = `LeakScan AI Jobsite Photo (${i + 1}/${capturedImages.length}) - ${diagnosis.severity.toUpperCase()} severity. ${jobNotes ? `Tech Notes: ${jobNotes}` : ''}`;
        const photoResult = await uploadPhotoToDrive(token, capturedImages[i], photoName, photoDesc);
        if (i === 0) uploadedPhoto = photoResult;
      }

      // 2. Generate and save complete estimate & report text file
      const reportText = `=====================================================
LEAKSCAN AI CONTRACTOR DIAGNOSTIC & ESTIMATE REPORT
Generated: ${new Date().toLocaleString()}
Van: ${selectedVan.name}
Severity: ${diagnosis.severity.toUpperCase()}
Issue: ${diagnosis.issueName}
Translated: ${diagnosis.issueNameLocal || diagnosis.issueName}
Root Cause: ${diagnosis.rootCause} (${diagnosis.rootCauseLocal || ''})
=====================================================

JOB SITE NOTES / OBSERVATIONS:
${jobNotes || 'Standard leak inspection'}

REPAIR STEPS (${currentLang.nativeLabel.toUpperCase()}):
${diagnosis.repairSteps.map((s) => `${s.stepNumber}. ${s.title}\n   ${s.instruction}${s.safetyWarning ? `\n   [SAFETY WARNING]: ${s.safetyWarning}` : ''}`).join('\n\n')}

REQUIRED MATERIALS & PARTS:
${diagnosis.requiredMaterials.map((m) => `- ${m.name} (${m.specs || ''}) (Qty: ${m.quantity}) - $${(m.standardRetailPrice || m.unitCost || 0).toFixed(2)} [In Van Stock: ${m.inVanStock ? 'YES' : 'NO'}]`).join('\n')}

ESTIMATE & INVOICE BREAKDOWN:
- Labor: ${diagnosis.customerEstimate.laborHours} hrs @ $${diagnosis.customerEstimate.recommendedLaborRate}/hr = $${(diagnosis.customerEstimate.laborHours * diagnosis.customerEstimate.recommendedLaborRate).toFixed(2)}
- Materials Subtotal: $${diagnosis.customerEstimate.partsSubtotal.toFixed(2)}
- Trip & Diagnostic Fee: $${diagnosis.customerEstimate.tripDiagnosticFee.toFixed(2)}
-----------------------------------------------------
TOTAL ESTIMATE QUOTE: $${diagnosis.customerEstimate.totalEstimate.toFixed(2)}
-----------------------------------------------------

CLIENT INVOICE DESCRIPTION:
${diagnosis.customerEstimate.clientSummaryEnglish}
`;

      const reportTitle = `${safeName}_Estimate_${timestamp}.txt`;
      const uploadedReport = await saveReportToDrive(token, reportTitle, reportText);

      // 3. Generate and save dedicated Diagnostic Log on a separate file in Drive
      const logText = generateDiagnosticLogContent(safeName, timestamp);
      const logTitle = `${safeName}_Diagnostic_Log_${timestamp}.log`;
      const uploadedLog = await saveLogToDrive(token, logTitle, logText);

      setDriveSaveSuccess({ photo: uploadedPhoto, report: uploadedReport, logFile: uploadedLog });
    } catch (err: any) {
      console.error('Save to Drive error:', err);
      setDriveError(err.message || 'Failed to save to Google Drive.');
    } finally {
      setIsSavingToDrive(false);
    }
  };

  // Save only the diagnostic log file to Google Drive
  const handleSaveLogOnlyToDrive = async () => {
    if (!diagnosis) return;
    setIsSavingLogOnly(true);
    setDriveError(null);
    try {
      let token = await getAccessToken();
      if (!token) {
        const signInResult = await googleSignIn();
        token = signInResult?.accessToken || null;
      }
      if (!token) {
        throw new Error('Google sign-in required to save to Drive.');
      }

      const timestamp = new Date().toISOString().slice(0, 10);
      const safeName = diagnosis.issueName.replace(/[^a-zA-Z0-9_-]/g, '_');
      const logText = generateDiagnosticLogContent(safeName, timestamp);
      const logTitle = `${safeName}_Diagnostic_Log_${timestamp}.log`;
      const uploadedLog = await saveLogToDrive(token, logTitle, logText);

      setDriveSaveSuccess((prev) => ({
        ...prev,
        logFile: uploadedLog,
      }));
    } catch (err: any) {
      console.error('Save Log to Drive error:', err);
      setDriveError(err.message || 'Failed to save log to Google Drive.');
    } finally {
      setIsSavingLogOnly(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner: Quick Instructions for Contractors */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <span>AI Jobsite Scanner & Estimate Writer</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Snap a photo of the leak. AI detects the fault, gives repair steps in your language, lists parts & checks your van stock.
              </p>
            </div>
          </div>

          {/* Van Selector & Language Quick Check */}
          <div className="flex items-center gap-2 bg-slate-950/70 p-2 rounded-xl border border-slate-800">
            <div className="text-left">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Active Van</div>
              <select
                value={selectedVanId}
                onChange={(e) => setSelectedVanId(e.target.value)}
                className="bg-transparent text-xs font-bold text-amber-400 focus:outline-none cursor-pointer"
              >
                {vans.map((van) => (
                  <option key={van.id} value={van.id} className="bg-slate-900 text-white">
                    {van.name}
                  </option>
                ))}
              </select>
            </div>
            <span className="text-slate-700">|</span>
            <div className="text-left">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">AI Voice</div>
              <span className="text-xs font-bold text-slate-200">
                {currentLang.flag} {currentLang.nativeLabel}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Viewport Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Camera Viewfinder & Controls (5 or 6 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Camera Viewfinder
              </span>
              <div className="flex items-center gap-1">
                {cameraActive && (
                  <button
                    onClick={toggleFacingMode}
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs flex items-center gap-1"
                    title="Flip Camera"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Flip</span>
                  </button>
                )}
              </div>
            </div>

            {/* Viewfinder Window */}
            <div className="relative aspect-[4/3] sm:aspect-[16/10] rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
              {cameraActive ? (
                <div className="w-full h-full relative">
                  <video
                    ref={videoRef}
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  {/* Tactical Camera HUD Overlay */}
                  <div className="absolute inset-0 pointer-events-none border-2 border-amber-500/30 m-3 rounded-lg flex flex-col justify-between p-3">
                    <div className="flex justify-between items-center text-[10px] font-mono text-amber-400">
                      <span>[LEAKSCAN HUD 24FPS]</span>
                      <span>{selectedVan.name.split(' - ')[0]}</span>
                    </div>
                    <div className="self-center w-16 h-16 border border-dashed border-amber-400/60 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-amber-400 rounded-full" />
                    </div>
                    <div className="text-center text-[11px] text-amber-300 font-medium bg-slate-950/70 px-2 py-0.5 rounded self-center">
                      Center leak pipe in crosshair
                    </div>
                  </div>
                </div>
              ) : capturedImage ? (
                <div className="w-full h-full relative group">
                  <img
                    src={capturedImage}
                    alt={`Captured leak angle ${activeImageIndex + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {/* Photo Counter Badge if multiple images */}
                  {capturedImages.length > 1 && (
                    <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-700 text-amber-400 font-mono text-[11px] font-bold backdrop-blur flex items-center gap-1.5 shadow-md">
                      <Images className="w-3.5 h-3.5" />
                      <span>Photo {activeImageIndex + 1} of {capturedImages.length}</span>
                    </div>
                  )}

                  <div className="absolute bottom-2 right-2 flex gap-1.5 z-20">
                    <button
                      type="button"
                      onClick={() => handleRemovePhoto(activeImageIndex)}
                      className="px-2.5 py-1 bg-slate-900/90 hover:bg-slate-800 text-rose-400 text-xs font-semibold rounded-lg border border-slate-700 backdrop-blur shadow"
                      title="Remove current photo"
                    >
                      Remove Photo
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCapturedImages([]);
                        setActiveImageIndex(0);
                        setDiagnosis(null);
                      }}
                      className="px-2.5 py-1 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold rounded-lg border border-slate-700 backdrop-blur shadow"
                      title="Clear all photos"
                    >
                      Clear All
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6 space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 text-amber-400 flex items-center justify-center mx-auto shadow-inner">
                    <Camera className="w-7 h-7" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-200">No Photos Selected</p>
                    <p className="text-xs text-slate-400 mt-0.5 max-w-xs mx-auto">
                      Upload multiple pictures at once (wide shot, pipe zoom, valve angle), use live camera, or pick a preset.
                    </p>
                  </div>
                </div>
              )}

              {/* Scanning Animation Overlay when AI is computing */}
              {isAnalyzing && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center z-20 text-center p-4">
                  <div className="relative w-20 h-20 mb-4">
                    <div className="absolute inset-0 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
                    <div className="absolute inset-2 border-4 border-blue-500/20 border-b-blue-500 rounded-full animate-spin" style={{ animationDirection: 'reverse' }} />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Sparkles className="w-6 h-6 text-amber-400 animate-pulse" />
                    </div>
                  </div>
                  <h3 className="text-base font-bold text-white tracking-wide">
                    Analyzing {capturedImages.length > 1 ? `${capturedImages.length} Leak Photos` : 'Leak'} with AI...
                  </h3>
                  <p className="text-xs text-amber-400 mt-1 font-mono">
                    Generating steps in {currentLang.nativeLabel} & matching Van Stock...
                  </p>
                </div>
              )}
              {/* Test on Phone symbol positioned in the down side of the image */}
              <div className="absolute bottom-2.5 left-2.5 z-20">
                <button
                  type="button"
                  onClick={() => setShowPhoneModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/90 hover:bg-slate-900 border border-amber-500/60 hover:border-amber-400 text-amber-400 hover:text-amber-300 text-xs font-bold shadow-xl backdrop-blur-md transition-all active:scale-95 group cursor-pointer"
                  title="Test on Phone: Open QR Code to scan with your phone camera"
                >
                  <Smartphone className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span>Test on Phone</span>
                  <QrCode className="w-3.5 h-3.5 opacity-80" />
                </button>
              </div>
            </div>

            {/* Multiple Photos Thumbnails Strip */}
            {capturedImages.length > 0 && !cameraActive && (
              <div className="mt-3 p-2.5 bg-slate-950/90 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-slate-300 font-bold">
                    <Images className="w-3.5 h-3.5 text-amber-400" />
                    <span>Attached Photos ({capturedImages.length})</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 px-2 py-0.5 rounded-lg border border-amber-500/30 transition-all"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add More Pictures</span>
                  </button>
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scrollbar-thin">
                  {capturedImages.map((img, idx) => (
                    <div
                      key={idx}
                      className={`relative shrink-0 group rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                        activeImageIndex === idx
                          ? 'border-amber-400 ring-2 ring-amber-400/40 shadow-md'
                          : 'border-slate-700 hover:border-slate-500 opacity-70 hover:opacity-100'
                      }`}
                      onClick={() => setActiveImageIndex(idx)}
                    >
                      <img
                        src={img}
                        alt={`Thumbnail ${idx + 1}`}
                        className="w-14 h-14 object-cover"
                      />
                      <span className="absolute bottom-0.5 left-0.5 px-1 bg-slate-950/80 rounded text-[9px] font-mono text-slate-200">
                        #{idx + 1}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemovePhoto(idx);
                        }}
                        className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full bg-slate-950/90 text-rose-400 hover:bg-rose-500 hover:text-white flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete photo"
                      >
                        ×
                      </button>
                    </div>
                  ))}

                  {/* Add more photo card in strip */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="shrink-0 w-14 h-14 rounded-lg border-2 border-dashed border-slate-700 hover:border-amber-400/60 bg-slate-900/60 hover:bg-slate-900 flex flex-col items-center justify-center text-slate-400 hover:text-amber-400 transition-all"
                    title="Upload more pictures"
                  >
                    <Plus className="w-4 h-4" />
                    <span className="text-[9px] font-semibold mt-0.5">Add</span>
                  </button>
                </div>
              </div>
            )}

            {/* Viewfinder Action Buttons */}
            <div className="mt-4 grid grid-cols-2 gap-2.5">
              {cameraActive ? (
                <>
                  <button
                    onClick={capturePhoto}
                    className="col-span-2 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/25 transition-transform active:scale-95"
                  >
                    <div className="w-4 h-4 rounded-full border-2 border-slate-950 bg-white" />
                    <span>{capturedImages.length > 0 ? 'SNAP ADDITIONAL PHOTO' : 'SNAP PHOTO'}</span>
                  </button>
                  <button
                    onClick={stopCamera}
                    className="col-span-2 py-2 text-xs font-semibold text-slate-400 hover:text-white"
                  >
                    Cancel Camera
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={startCamera}
                    className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all"
                  >
                    <Camera className="w-4 h-4" />
                    <span>{capturedImages.length > 0 ? 'Take Another Photo' : 'Open Camera'}</span>
                  </button>

                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all group"
                  >
                    <Upload className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                    <span>Upload Multiple Pictures</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleFileUpload}
                    className="hidden"
                  />

                  {/* Test on Phone Action Button below image */}
                  <button
                    type="button"
                    onClick={() => setShowPhoneModal(true)}
                    className="col-span-2 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/40 text-xs font-bold transition-all shadow-sm"
                    title="Scan QR code to open and test on your mobile device"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Test on Phone (Scan QR)</span>
                    <QrCode className="w-3.5 h-3.5 opacity-80" />
                  </button>

                  {onNavigateToDrive && (
                    <button
                      type="button"
                      onClick={onNavigateToDrive}
                      className="col-span-2 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs font-bold transition-all"
                    >
                      <HardDrive className="w-3.5 h-3.5" />
                      <span>Browse or Upload via Google Drive</span>
                    </button>
                  )}
                </>
              )}
            </div>

            {cameraError && (
              <div className="mt-3 p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{cameraError}</span>
              </div>
            )}
          </div>

          {/* Quick Leak Presets (Crucial for testing/demo in office or classroom) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                1-Tap Jobsite Presets (Instant Demo)
              </span>
              <span className="text-[10px] text-amber-400 font-mono">Common Field Leaks</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {SAMPLE_LEAK_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => selectPreset(preset)}
                  className="flex items-start gap-2 p-2 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-500/40 text-left transition-all group"
                >
                  <img
                    src={preset.imageUrl}
                    alt={preset.title}
                    className="w-11 h-11 rounded-lg object-cover border border-slate-700 shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="text-[10px] font-bold text-amber-400 px-1 py-0.2 rounded bg-amber-400/10">
                      {preset.badge}
                    </span>
                    <p className="text-xs font-semibold text-slate-200 truncate mt-0.5 group-hover:text-amber-300">
                      {preset.title}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Field Notes & Quick Symptoms */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  Technician Notes / Customer Complaint
                </label>

                {/* Voice Dictation Button (gemini-3.5-transcribe) */}
                {!isRecordingVoice ? (
                  <button
                    type="button"
                    onClick={startVoiceRecording}
                    disabled={isTranscribing}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 transition-all shadow-sm"
                    title={`Dictate notes in ${currentLang.nativeLabel} or English`}
                  >
                    {isTranscribing ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
                        <span>Transcribing...</span>
                      </>
                    ) : (
                      <>
                        <Mic className="w-3.5 h-3.5 text-amber-400" />
                        <span>Voice Dictate</span>
                        <span className="text-[10px] text-amber-400/80 font-normal">({currentLang.flag})</span>
                      </>
                    )}
                  </button>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={stopVoiceRecording}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-500 hover:bg-rose-600 text-white shadow-md animate-pulse"
                      title="Stop and transcribe speech"
                    >
                      <StopCircle className="w-3.5 h-3.5" />
                      <span>Stop & Transcribe</span>
                      <span className="font-mono text-[11px] bg-rose-700/80 px-1 rounded">
                        {recordingDuration}s
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={cancelVoiceRecording}
                      className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white text-xs"
                      title="Cancel recording"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Active Recording Waveform Indicator Bar */}
              {isRecordingVoice && (
                <div className="mb-2 p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/40 flex items-center justify-between text-xs animate-in fade-in">
                  <div className="flex items-center gap-2 text-rose-300">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                    <span className="font-bold">Listening... Speak now</span>
                    <span className="text-[11px] text-rose-400/90 font-mono">
                      (Speaking in {currentLang.nativeLabel} or English)
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-1 h-3 bg-rose-400 animate-pulse rounded-full" />
                    <span className="w-1 h-5 bg-rose-400 animate-pulse delay-75 rounded-full" />
                    <span className="w-1 h-2 bg-rose-400 animate-pulse delay-150 rounded-full" />
                    <span className="w-1 h-4 bg-rose-400 animate-pulse delay-100 rounded-full" />
                  </div>
                </div>
              )}

              {/* Transcribing state banner */}
              {isTranscribing && (
                <div className="mb-2 p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300 animate-in fade-in">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
                  <span>Transcribing speech with Gemini 3.5 audio model...</span>
                </div>
              )}

              {/* Voice Error notice if any */}
              {voiceError && (
                <div className="mb-2 p-2 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
                  <span>{voiceError}</span>
                  <button onClick={() => setVoiceError(null)} className="text-slate-400 hover:text-white">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <textarea
                value={jobNotes}
                onChange={(e) => setJobNotes(e.target.value)}
                placeholder="e.g. Water dripping under laundry sink when upstairs bathroom runs. Main valve stiff."
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
              />
            </div>

            {/* Quick Symptom Tags */}
            <div className="flex flex-wrap gap-1.5">
              {COMMON_TAGS.map((tag) => {
                const isSelected = quickTags.includes(tag);
                return (
                  <button
                    key={tag}
                    onClick={() => {
                      if (isSelected) {
                        setQuickTags(quickTags.filter((t) => t !== tag));
                      } else {
                        setQuickTags([...quickTags, tag]);
                      }
                    }}
                    className={`text-[11px] px-2.5 py-1 rounded-lg font-medium transition-colors ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    + {tag}
                  </button>
                );
              })}
            </div>

            {/* Big Action Button to Run AI */}
            <button
              onClick={runAiAnalysis}
              disabled={capturedImages.length === 0 || isAnalyzing}
              className={`w-full py-3.5 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
                capturedImages.length === 0 || isAnalyzing
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 hover:opacity-95 shadow-amber-500/25 active:scale-[0.98]'
              }`}
            >
              <Sparkles className="w-5 h-5 text-slate-950" />
              <span>
                {capturedImages.length > 1
                  ? `RUN AI SCAN ON ${capturedImages.length} PHOTOS & ESTIMATE`
                  : 'RUN AI LEAK SCAN & ESTIMATE'}
              </span>
            </button>
          </div>
        </div>

        {/* Right Column: AI Diagnosis, Repair Steps, Parts & Estimate (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {!diagnosis ? (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center min-h-[460px] flex flex-col items-center justify-center shadow-xl">
              <div className="w-16 h-16 rounded-2xl bg-slate-800/80 border border-slate-700/60 text-slate-400 flex items-center justify-center mb-4">
                <FileText className="w-8 h-8 text-amber-400/80" />
              </div>
              <h3 className="text-lg font-bold text-white">Diagnostic Output Ready</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md">
                Select a photo or preset on the left and click <strong className="text-amber-400">Run AI Leak Scan</strong>.
                LeakScan will generate multilingual repair steps, check your van stock, and create a customer-ready quote.
              </p>
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 text-left w-full max-w-lg">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-amber-400 text-xs font-bold block">1. Native Voice</span>
                  <p className="text-[11px] text-slate-400 mt-0.5">Instructions spoken in Spanish, Bulgarian, English, etc.</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-emerald-400 text-xs font-bold block">2. Van Stock Check</span>
                  <p className="text-[11px] text-slate-400 mt-0.5">Know instantly if parts are in your truck or need supply run.</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-blue-400 text-xs font-bold block">3. One-Tap Estimate</span>
                  <p className="text-[11px] text-slate-400 mt-0.5">Labor + materials breakdown with client invoice summary.</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-200">
              {/* Header Box: Issue Diagnosis & Voice Button */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                          diagnosis.severity === 'critical'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : diagnosis.severity === 'high'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                        }`}
                      >
                        {diagnosis.severity.toUpperCase()} PRIORITY
                      </span>
                      <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        ~{diagnosis.estimatedRepairTimeMinutes} min repair
                      </span>
                    </div>

                    <h2 className="text-xl font-black text-white">{diagnosis.issueName}</h2>
                    {diagnosis.issueNameLocal && diagnosis.issueNameLocal !== diagnosis.issueName && (
                      <p className="text-sm font-semibold text-amber-400 mt-0.5">
                        {diagnosis.issueNameLocal} ({currentLang.nativeLabel})
                      </p>
                    )}
                  </div>

                  {/* Audio Readout Button (ESL Contractor Superpower) */}
                  <button
                    onClick={() => playAudioGuidance(diagnosis.audioScript)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all shadow-md ${
                      isPlayingAudio
                        ? 'bg-rose-500 hover:bg-rose-600 text-white animate-pulse'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                    }`}
                  >
                    {isPlayingAudio ? (
                      <>
                        <VolumeX className="w-4 h-4" />
                        <span>Stop Voice Guide</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-4 h-4" />
                        <span>Listen ({currentLang.flag} {currentLang.nativeLabel})</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Root Cause Card */}
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Root Cause Diagnosis
                  </span>
                  <p className="text-slate-200">{diagnosis.rootCause}</p>
                  {diagnosis.rootCauseLocal && diagnosis.rootCauseLocal !== diagnosis.rootCause && (
                    <p className="text-amber-300/90 italic pt-0.5">{diagnosis.rootCauseLocal}</p>
                  )}
                </div>
              </div>

              {/* Step-by-Step Field Repair Instructions (in Tech's native language) */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                    <span>Field Repair Steps</span>
                    <span className="text-xs font-normal text-amber-400">
                      ({currentLang.flag} {currentLang.nativeLabel})
                    </span>
                  </h3>
                  <span className="text-xs text-slate-400">{diagnosis.repairSteps.length} Steps</span>
                </div>

                <div className="space-y-2.5">
                  {diagnosis.repairSteps.map((step) => (
                    <div
                      key={step.stepNumber}
                      className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/90 space-y-1.5"
                    >
                      <div className="flex items-start gap-2.5">
                        <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                          {step.stepNumber}
                        </span>
                        <div className="min-w-0 flex-1">
                          <h4 className="text-xs font-bold text-white">{step.title}</h4>
                          <p className="text-xs text-slate-300 mt-1 leading-relaxed">{step.instruction}</p>
                        </div>
                      </div>

                      {step.visualCue && (
                        <div className="ml-8 text-[11px] text-emerald-400/90 flex items-center gap-1.5 font-medium bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          <span>Check: {step.visualCue}</span>
                        </div>
                      )}

                      {step.safetyWarning && (
                        <div className="ml-8 text-[11px] text-rose-300 flex items-start gap-1.5 font-medium bg-rose-500/10 px-2.5 py-1 rounded-lg border border-rose-500/20">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                          <span>Safety: {step.safetyWarning}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Required Materials & Van Stock Check */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-amber-400" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                      Required Materials & Van Stock Cross-Check
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Target: {selectedVan.name}
                  </span>
                </div>

                <div className="space-y-2">
                  {diagnosis.requiredMaterials.map((mat, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{mat.name}</span>
                          <span className="text-[10px] font-mono bg-slate-800 px-1.5 py-0.2 rounded text-slate-400">
                            Qty: {mat.quantity}
                          </span>
                        </div>
                        {mat.nameLocal && (
                          <div className="text-[11px] text-amber-400/90 font-medium">
                            {mat.nameLocal}
                          </div>
                        )}
                        <div className="text-[10px] text-slate-400 mt-0.5">{mat.specs}</div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                        <div className="text-right">
                          <div className="text-xs font-bold text-slate-200">
                            ${(mat.standardRetailPrice * mat.quantity).toFixed(2)}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            (${mat.standardRetailPrice.toFixed(2)} ea)
                          </div>
                        </div>

                        {mat.inVanStock ? (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-1 rounded-lg">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>In Van ({mat.vanStockCount || 'Yes'})</span>
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-1 rounded-lg">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Supply Run</span>
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Stock Deduction Button */}
                <div className="pt-2 flex items-center justify-between">
                  <p className="text-[11px] text-slate-400">
                    Finished repair? Deduct parts directly from this truck's inventory.
                  </p>
                  <button
                    onClick={handleDeductParts}
                    disabled={stockDeductedSuccess}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                      stockDeductedSuccess
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 cursor-default'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    }`}
                  >
                    {stockDeductedSuccess ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Van Stock Deducted</span>
                      </>
                    ) : (
                      <>
                        <Package className="w-3.5 h-3.5" />
                        <span>Deduct from {selectedVan.name.split(' - ')[0]}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Customer Estimate Sheet & Work Order Dispatch */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-emerald-400" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                      Customer Estimate & Invoice Breakdown
                    </h3>
                  </div>
                  <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
                    Ready to Present
                  </span>
                </div>

                {/* Customer Invoice Summary Text in English */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Customer Invoice Description (English)
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed font-sans">
                    {diagnosis.customerEstimate.clientSummaryEnglish}
                  </p>
                </div>

                {/* Numbers calculation row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Labor</span>
                    <div className="text-sm font-bold text-white mt-0.5">
                      ${(diagnosis.customerEstimate.laborHours * diagnosis.customerEstimate.recommendedLaborRate).toFixed(2)}
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {diagnosis.customerEstimate.laborHours}h @ ${diagnosis.customerEstimate.recommendedLaborRate}/hr
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Materials</span>
                    <div className="text-sm font-bold text-white mt-0.5">
                      ${diagnosis.customerEstimate.partsSubtotal.toFixed(2)}
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {diagnosis.requiredMaterials.length} items included
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Trip / Diagnostic</span>
                    <div className="text-sm font-bold text-white mt-0.5">
                      ${(diagnosis.customerEstimate.tripDiagnosticFee || 85).toFixed(2)}
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">Standard service call</span>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40">
                    <span className="text-[10px] text-emerald-400 uppercase font-bold block">Total Quote</span>
                    <div className="text-base font-black text-emerald-300 mt-0.5">
                      ${diagnosis.customerEstimate.totalEstimate.toFixed(2)}
                    </div>
                    <span className="text-[10px] text-emerald-400/80 font-mono">Tax & warranty incl.</span>
                  </div>
                </div>

                {/* Final Job Dispatch / Work Order Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                  <button
                    onClick={handleCreateJob}
                    disabled={jobAddedSuccess}
                    className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                      jobAddedSuccess
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                    }`}
                  >
                    {jobAddedSuccess ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Work Order Created in Tech Schedule</span>
                      </>
                    ) : (
                      <>
                        <FileText className="w-4 h-4" />
                        <span>Accept Estimate & Add to Dispatch Schedule</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveToDrive}
                    disabled={isSavingToDrive || isSavingLogOnly}
                    className="py-3 px-4 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-all"
                    title="Save photos, customer estimate, and technical diagnostic log into Google Drive as separate files"
                  >
                    {isSavingToDrive ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Saving to Drive...</span>
                      </>
                    ) : (
                      <>
                        <HardDrive className="w-4 h-4" />
                        <span>Save to Drive (Photos, Estimate & Log)</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveLogOnlyToDrive}
                    disabled={isSavingToDrive || isSavingLogOnly}
                    className="py-3 px-3.5 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 flex items-center justify-center gap-1.5 transition-all"
                    title="Save technical diagnostic and audit log as a separate file to Google Drive"
                  >
                    {isSavingLogOnly ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                        <span>Saving Log...</span>
                      </>
                    ) : (
                      <>
                        <ScrollText className="w-4 h-4" />
                        <span>Save Log File to Drive</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="py-3 px-4 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-center gap-2"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print / PDF</span>
                  </button>
                </div>

                {/* Google Drive Save Success Banner */}
                {driveSaveSuccess && (
                  <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-500/40 text-xs text-blue-200 space-y-2.5 animate-in fade-in">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 font-bold text-blue-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>Files Successfully Saved to Google Drive!</span>
                      </div>
                      <span className="text-[10px] text-blue-300/80 font-mono">Folder: LeakScan AI Reports & Photos</span>
                    </div>
                    <div className="flex items-center gap-2 pt-1 flex-wrap">
                      {driveSaveSuccess.report?.webViewLink && (
                        <a
                          href={driveSaveSuccess.report.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 font-semibold flex items-center gap-1.5 border border-blue-500/30"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>View Estimate Report</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                      {driveSaveSuccess.logFile?.webViewLink && (
                        <a
                          href={driveSaveSuccess.logFile.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-semibold flex items-center gap-1.5 border border-emerald-500/30"
                        >
                          <ScrollText className="w-3.5 h-3.5 text-emerald-400" />
                          <span>View Diagnostic Log (Separate File)</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                      {driveSaveSuccess.photo?.webViewLink && (
                        <a
                          href={driveSaveSuccess.photo.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 font-semibold flex items-center gap-1.5 border border-blue-500/30"
                        >
                          <HardDrive className="w-3.5 h-3.5" />
                          <span>View Photo in Drive</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                )}

                {driveError && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{driveError}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Test on Phone Modal */}
      <TestOnPhoneModal
        isOpen={showPhoneModal}
        onClose={() => setShowPhoneModal(false)}
      />
    </div>
  );
};
