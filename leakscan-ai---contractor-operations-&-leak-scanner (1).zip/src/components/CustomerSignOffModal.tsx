import React, { useState, useEffect } from 'react';
import {
  X,
  CheckCircle2,
  FileCheck,
  Star,
  ShieldCheck,
  Calendar,
  Clock,
  MapPin,
  User,
  DollarSign,
  HardDrive,
  Printer,
  Wrench,
  AlertTriangle,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { Job, CustomerSignOff } from '../types';
import { SignaturePad } from './SignaturePad';
import { getAccessToken } from '../services/googleAuth';
import { uploadPhotoToDrive, saveReportToDrive } from '../services/googleDrive';

export interface CustomerSignOffModalProps {
  isOpen: boolean;
  onClose: () => void;
  job?: Job | null;
  procedureTitle?: string;
  availableJobs?: Job[];
  onConfirmSignOff: (signOff: CustomerSignOff, jobId?: string) => void;
  onNavigateToDrive?: () => void;
}

export const CustomerSignOffModal: React.FC<CustomerSignOffModalProps> = ({
  isOpen,
  onClose,
  job,
  procedureTitle,
  availableJobs = [],
  onConfirmSignOff,
  onNavigateToDrive,
}) => {
  // If no job was passed (e.g. invoked from RepairGuides), tech can select one or enter custom customer
  const [selectedJobId, setSelectedJobId] = useState<string>(job?.id || availableJobs[0]?.id || 'custom');
  const activeJob = job || availableJobs.find((j) => j.id === selectedJobId) || null;

  const [customerName, setCustomerName] = useState<string>('');
  const [jobAddress, setJobAddress] = useState<string>('');
  const [techName, setTechName] = useState<string>('');
  const [repairScope, setRepairScope] = useState<string>('');
  const [invoiceTotal, setInvoiceTotal] = useState<number>(350);

  // Sign-off verification checklist states
  const [codeCompliant, setCodeCompliant] = useState(true);
  const [pressureTested, setPressureTested] = useState(true);
  const [worksiteCleaned, setWorksiteCleaned] = useState(true);
  const [warrantyExplained, setWarrantyExplained] = useState(true);

  // Satisfaction rating (1 to 5 stars)
  const [rating, setRating] = useState<number>(5);
  const [customerNotes, setCustomerNotes] = useState<string>('');

  // Signature state
  const [capturedSignature, setCapturedSignature] = useState<string>('');
  const [isDriveSaving, setIsDriveSaving] = useState(false);
  const [driveSavedMessage, setDriveSavedMessage] = useState<string | null>(null);
  const [viewSignedCertificate, setViewSignedCertificate] = useState(false);

  // Sync state when activeJob or procedureTitle changes
  useEffect(() => {
    if (activeJob) {
      setCustomerName(activeJob.customerName);
      setJobAddress(activeJob.address);
      setTechName(activeJob.assignedTechName);
      setRepairScope(procedureTitle || activeJob.issueSummary);
      setInvoiceTotal(activeJob.estimateTotal || 350.0);

      if (activeJob.signOff) {
        setCapturedSignature(activeJob.signOff.signatureDataUrl);
        setRating(activeJob.signOff.satisfactionRating || 5);
        setCustomerNotes(activeJob.signOff.notes || '');
        setViewSignedCertificate(true);
      } else {
        setCapturedSignature('');
        setViewSignedCertificate(false);
      }
    } else {
      setCustomerName('Homeowner / Property Manager');
      setJobAddress('Site Location');
      setTechName('Lead Technician');
      setRepairScope(procedureTitle || 'Completed Plumbing Procedure');
      setInvoiceTotal(250.0);
      setCapturedSignature('');
      setViewSignedCertificate(false);
    }
  }, [activeJob, procedureTitle, isOpen]);

  if (!isOpen) return null;

  const handleSaveSignature = (dataUrl: string) => {
    setCapturedSignature(dataUrl);
  };

  const handleSubmitSignOff = () => {
    if (!capturedSignature) {
      alert('Please have the customer provide their signature on the pad before saving.');
      return;
    }

    const signOffData: CustomerSignOff = {
      signerName: customerName.trim() || 'Valued Customer',
      signatureDataUrl: capturedSignature,
      signedAt: new Date().toISOString(),
      satisfactionRating: rating,
      notes: customerNotes.trim(),
      termsAccepted: codeCompliant && pressureTested && worksiteCleaned && warrantyExplained,
      procedureName: repairScope,
      invoiceTotal: invoiceTotal,
    };

    onConfirmSignOff(signOffData, activeJob?.id);
    setViewSignedCertificate(true);
  };

  // 1-Click Export to Google Drive
  const handleExportToGoogleDrive = async () => {
    if (!capturedSignature) return;
    setIsDriveSaving(true);
    setDriveSavedMessage(null);

    try {
      const token = await getAccessToken();
      if (!token) {
        alert('Please connect your Google Drive account first in the Google Drive tab.');
        if (onNavigateToDrive) onNavigateToDrive();
        setIsDriveSaving(false);
        return;
      }

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `Customer_SignOff_${customerName.replace(/[^a-zA-Z0-9]/g, '_')}_${timestamp}`;

      // 1. Upload signature image to Drive
      await uploadPhotoToDrive(
        token,
        capturedSignature,
        `${filename}_Signature.png`,
        `Customer Signature Sign-off for ${customerName} on ${repairScope}`
      );

      // 2. Upload complete textual certificate report
      const certificateText = [
        '========================================================================',
        '              LEAKSCAN AI - FIELD WORK COMPLETION & SIGN-OFF            ',
        '========================================================================',
        `Date & Time:           ${new Date().toLocaleString()}`,
        `Customer Name:         ${customerName}`,
        `Service Address:       ${jobAddress}`,
        `Lead Technician:       ${techName}`,
        `Scope of Repair:       ${repairScope}`,
        `Total Invoice Amount:  $${invoiceTotal.toFixed(2)}`,
        `Satisfaction Rating:   ${rating} / 5 Stars`,
        '',
        'QUALITY ASSURANCE & IPC COMPLIANCE VERIFICATION:',
        `• International Plumbing Code (IPC) Standards Met:     ${codeCompliant ? 'YES' : 'NO'}`,
        `• Working Pressure Tested (Zero Leaks Observed):      ${pressureTested ? 'YES' : 'NO'}`,
        `• Worksite Cleaned & Shutoff Valves Restored:          ${worksiteCleaned ? 'YES' : 'NO'}`,
        `• 90-Day Leak-Free Labor Warranty Active:              ${warrantyExplained ? 'YES' : 'NO'}`,
        '',
        'CUSTOMER AUTHORIZATION STATEMENT:',
        `"I hereby confirm that the plumbing repairs outlined above have been`,
        `satisfactorily completed, demonstrated under live pressure, and approved."`,
        '',
        `Signer:                ${customerName}`,
        `Timestamp:             ${new Date().toISOString()}`,
        `Customer Notes:        ${customerNotes || 'None'}`,
        '========================================================================',
      ].join('\n');

      await saveReportToDrive(token, `${filename}_Certificate.txt`, certificateText);

      setDriveSavedMessage('Sign-off certificate and signature successfully saved to your Google Drive folder!');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      alert(`Could not export to Google Drive: ${msg}`);
    } finally {
      setIsDriveSaving(false);
    }
  };

  // Browser print slip
  const handlePrintCertificate = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>Customer Sign-Off & Verification</span>
                {viewSignedCertificate && (
                  <span className="text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    <span>Signed</span>
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Official contractor work authorization, leak test verification & customer sign-off.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Work Order / Job Selector if multiple available */}
          {availableJobs.length > 0 && !job && (
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-amber-400" />
                <span>Link Sign-Off to Active Field Work Order:</span>
              </label>
              <select
                value={selectedJobId}
                onChange={(e) => setSelectedJobId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              >
                {availableJobs.map((j) => (
                  <option key={j.id} value={j.id}>
                    #{j.id.slice(-4)} - {j.customerName} ({j.issueSummary.slice(0, 45)}...)
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Job / Customer Overview Pill Card */}
          <div className="bg-slate-950/80 rounded-2xl border border-slate-800 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-850 pb-3">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider">
                  Customer
                </span>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  <span>{customerName}</span>
                </h4>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider">
                  Lead Technician
                </span>
                <p className="text-xs font-medium text-slate-200">{techName}</p>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider">
                  Total Approved
                </span>
                <p className="text-sm font-black text-emerald-400 font-mono">
                  ${invoiceTotal.toFixed(2)}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300 pt-1">
              <div className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                <span className="truncate">{jobAddress}</span>
              </div>
              <div className="flex items-start gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span className="truncate">
                  <strong>Procedure:</strong> {repairScope}
                </span>
              </div>
            </div>
          </div>

          {/* If viewing already signed certificate */}
          {viewSignedCertificate && capturedSignature ? (
            <div className="space-y-5">
              <div className="bg-emerald-950/30 border border-emerald-500/40 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm font-bold text-emerald-300">
                      Work Order Completed & Approved
                    </span>
                  </div>
                  <span className="text-xs font-mono text-emerald-400">
                    {activeJob?.signOff?.signedAt
                      ? new Date(activeJob.signOff.signedAt).toLocaleDateString()
                      : new Date().toLocaleDateString()}
                  </span>
                </div>

                {/* Customer Signature Display */}
                <div className="bg-white rounded-xl p-3 border border-slate-300 flex flex-col items-center justify-center">
                  <div className="w-full text-[10px] text-slate-400 font-mono flex items-center justify-between border-b border-slate-200 pb-1 mb-1">
                    <span>CUSTOMER SIGNATURE RECORD</span>
                    <span>VERIFIED BY LEAKSCAN AI</span>
                  </div>
                  <img
                    src={capturedSignature}
                    alt="Customer Signature"
                    className="max-h-28 w-auto object-contain py-1"
                  />
                  <div className="w-full pt-1 border-t border-slate-200 text-center text-xs font-serif text-slate-800">
                    ✕ {customerName}
                  </div>
                </div>

                {/* Satisfaction & Notes */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300 pt-1">
                  <div className="flex items-center gap-1.5">
                    <span>Customer Rating:</span>
                    <div className="flex items-center gap-0.5 text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3.5 h-3.5 ${
                            i < rating ? 'fill-amber-400 text-amber-400' : 'text-slate-600'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {activeJob?.signOff?.notes && (
                    <div className="text-slate-400 italic">
                      "{activeJob.signOff.notes}"
                    </div>
                  )}
                </div>
              </div>

              {/* Feedback Alert if Drive was saved */}
              {driveSavedMessage && (
                <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>{driveSavedMessage}</span>
                  </span>
                  {onNavigateToDrive && (
                    <button
                      onClick={onNavigateToDrive}
                      className="underline text-emerald-200 hover:text-white font-bold ml-2"
                    >
                      Open Drive
                    </button>
                  )}
                </div>
              )}

              {/* Certificate Actions: Export to Google Drive, Print, Re-sign */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setViewSignedCertificate(false)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-300 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Update / Re-Sign</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handlePrintCertificate}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-400" />
                    <span>Print Slip</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleExportToGoogleDrive}
                    disabled={isDriveSaving}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-950/30 transition-all"
                  >
                    <HardDrive className="w-3.5 h-3.5 text-blue-200" />
                    <span>{isDriveSaving ? 'Saving to Drive...' : 'Save to Google Drive'}</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Active Signing Workflow */
            <div className="space-y-6">
              {/* Quality & Code Compliance Checklist */}
              <div className="space-y-2.5">
                <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Technician Quality & Safety Verification Checklist</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={codeCompliant}
                      onChange={(e) => setCodeCompliant(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-slate-300">IPC code standards met</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={pressureTested}
                      onChange={(e) => setPressureTested(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-slate-300">Live pressure test passed</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={worksiteCleaned}
                      onChange={(e) => setWorksiteCleaned(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-slate-300">Worksite cleaned & dried</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={warrantyExplained}
                      onChange={(e) => setWarrantyExplained(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-slate-300">90-day warranty explained</span>
                  </label>
                </div>
              </div>

              {/* Customer Satisfaction Rating */}
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-bold text-white block">
                    Customer Experience Rating:
                  </span>
                  <span className="text-[11px] text-slate-400">
                    How satisfied is the client with the response & repair?
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4, 5].map((starVal) => (
                    <button
                      key={starVal}
                      type="button"
                      onClick={() => setRating(starVal)}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-5 h-5 ${
                          starVal <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-600 hover:text-slate-400'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-amber-400 ml-1.5 font-mono">
                    {rating}/5
                  </span>
                </div>
              </div>

              {/* Customer Signer Name Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>Authorized Customer Signer Name:</span>
                  <span className="text-[11px] text-slate-400 font-normal">Must match property contact</span>
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Robert Vance"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* The Signature Pad Component */}
              <div className="space-y-2">
                <SignaturePad
                  initialSignature={capturedSignature}
                  signerName={customerName}
                  onSave={handleSaveSignature}
                  title="Customer Sign-Off Signature"
                  subtitle="Sign on the digital pad below to accept completed repair"
                  height={190}
                />
              </div>

              {/* Legal Acknowledgment Disclosure */}
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                <strong className="text-slate-300">Contractor Authorization:</strong> By signing above,
                the customer acknowledges that all described plumbing repairs have been visually inspected,
                pressure tested with no leaks detected, and executed in accordance with applicable plumbing code.
                Invoice total of <strong>${invoiceTotal.toFixed(2)}</strong> is authorized.
              </div>

              {/* Final Submit Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-750 text-slate-300 transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleSubmitSignOff}
                  disabled={!capturedSignature}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40 disabled:pointer-events-none shadow-xl shadow-emerald-950/50 transition-all"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Authorize & Complete Repair</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
