import React, { useState } from 'react';
import {
  FileCheck,
  DollarSign,
  Plus,
  Receipt,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  Calendar,
  X,
  CreditCard,
  Banknote,
  Fuel,
  Check,
} from 'lucide-react';
import { DailyTurnIn, Technician, Van } from '../types';

interface TurnInsManagerProps {
  turnIns: DailyTurnIn[];
  techs: Technician[];
  vans: Van[];
  onSubmitTurnIn: (turnIn: Omit<DailyTurnIn, 'id' | 'status' | 'submittedAt'>) => void;
  onApproveTurnIn: (id: string) => void;
}

export const TurnInsManager: React.FC<TurnInsManagerProps> = ({
  turnIns,
  techs,
  vans,
  onSubmitTurnIn,
  onApproveTurnIn,
}) => {
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending_review' | 'approved'>('all');

  // Submit Form state
  const [selectedTechId, setSelectedTechId] = useState(techs[0]?.id || 'tech-1');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [jobsDone, setJobsDone] = useState(3);
  const [cash, setCash] = useState(250);
  const [checks, setChecks] = useState(450);
  const [card, setCard] = useState(820);
  const [receiptsTotal, setReceiptsTotal] = useState(64.5);
  const [mileStart, setMileStart] = useState(42880);
  const [mileEnd, setMileEnd] = useState(42945);
  const [vanRestocked, setVanRestocked] = useState(true);
  const [turnInNotes, setTurnInNotes] = useState('');

  const selectedTech = techs.find((t) => t.id === selectedTechId) || techs[0];

  const filteredTurnIns = turnIns.filter((t) => {
    if (filterStatus === 'all') return true;
    return t.status === filterStatus;
  });

  // Totals calculations
  const totalCashCollected = turnIns.reduce((acc, t) => acc + t.cashCollected, 0);
  const totalChecksCollected = turnIns.reduce((acc, t) => acc + t.checksCollected, 0);
  const totalCardCollected = turnIns.reduce((acc, t) => acc + t.cardCollected, 0);
  const totalGrossCollected = totalCashCollected + totalChecksCollected + totalCardCollected;
  const totalSupplyReceipts = turnIns.reduce((acc, t) => acc + t.supplyReceiptsTotal, 0);
  const pendingCount = turnIns.filter((t) => t.status === 'pending_review').length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitTurnIn({
      date,
      techId: selectedTech.id,
      techName: selectedTech.name,
      vanName: selectedTech.assignedVanName,
      jobsCompleted: Number(jobsDone),
      cashCollected: Number(cash),
      checksCollected: Number(checks),
      cardCollected: Number(card),
      supplyReceiptsTotal: Number(receiptsTotal),
      mileageStart: Number(mileStart),
      mileageEnd: Number(mileEnd),
      vanRestocked,
      notes: turnInNotes.trim() || 'Daily shift completed with verified van inventory.',
    });

    setShowSubmitModal(false);
    setTurnInNotes('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <FileCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                <span>Shift Turn-Ins & Daily Cash Reconciliation</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Log completed jobs, cash & check turn-ins, parts receipts, and van restock sign-offs.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowSubmitModal(true)}
            className="px-4 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center gap-2 shadow-md shadow-amber-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>Submit Shift Turn-In</span>
          </button>
        </div>
      </div>

      {/* Reconciliation Financial Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Total Collected</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-400">
            ${totalGrossCollected.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Cash + Checks + Cards</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Physical Cash & Checks</span>
            <Banknote className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white">
            ${(totalCashCollected + totalChecksCollected).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
            ${totalCashCollected.toFixed(2)} cash / ${totalChecksCollected.toFixed(2)} check
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Parts & Gas Receipts</span>
            <Receipt className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-rose-400">
            ${totalSupplyReceipts.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Supply house reimbursements</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-1">
            <span>Pending Reviews</span>
            <Clock className={`w-4 h-4 ${pendingCount > 0 ? 'text-amber-400' : 'text-slate-500'}`} />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span>{pendingCount}</span>
            {pendingCount > 0 && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                Awaiting Sign-off
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Owner verification</div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            filterStatus === 'all'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
          }`}
        >
          All Turn-Ins ({turnIns.length})
        </button>

        <button
          onClick={() => setFilterStatus('pending_review')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            filterStatus === 'pending_review'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
          }`}
        >
          Pending Review ({pendingCount})
        </button>

        <button
          onClick={() => setFilterStatus('approved')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            filterStatus === 'approved'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
          }`}
        >
          Approved ({turnIns.filter((t) => t.status === 'approved').length})
        </button>
      </div>

      {/* Turn-Ins Log List */}
      <div className="space-y-3">
        {filteredTurnIns.map((turn) => {
          const isPending = turn.status === 'pending_review';
          const totalTurnRevenue = turn.cashCollected + turn.checksCollected + turn.cardCollected;
          const milesDriven = turn.mileageEnd - turn.mileageStart;

          return (
            <div
              key={turn.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4 hover:border-slate-700 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-amber-400 text-base">
                    {turn.techName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{turn.techName}</span>
                      <span className="text-xs font-mono text-slate-400">• {turn.date}</span>
                    </h3>
                    <div className="text-[11px] text-amber-400 font-mono mt-0.5">
                      {turn.vanName} | {turn.jobsCompleted} Jobs Completed
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <span
                    className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                      isPending
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {isPending ? 'Pending Review' : 'Verified & Approved'}
                  </span>

                  {isPending && (
                    <button
                      onClick={() => onApproveTurnIn(turn.id)}
                      className="px-3 py-1 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center gap-1 shadow-md shadow-emerald-500/20"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Breakdown Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Cash Collected</span>
                  <div className="text-sm font-bold text-emerald-400 mt-0.5">
                    ${turn.cashCollected.toFixed(2)}
                  </div>
                  <span className="text-[10px] text-slate-500">Envelope verified</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Checks & Cards</span>
                  <div className="text-sm font-bold text-white mt-0.5">
                    ${(turn.checksCollected + turn.cardCollected).toFixed(2)}
                  </div>
                  <span className="text-[10px] text-slate-500">
                    ${turn.checksCollected} ck / ${turn.cardCollected} card
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Supply Receipts</span>
                  <div className="text-sm font-bold text-rose-400 mt-0.5">
                    ${turn.supplyReceiptsTotal.toFixed(2)}
                  </div>
                  <span className="text-[10px] text-slate-500">Parts / Ferguson / Gas</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Miles & Van Restock</span>
                  <div className="text-sm font-bold text-white mt-0.5">
                    {milesDriven} Miles
                  </div>
                  <span className="text-[10px] text-emerald-400">
                    {turn.vanRestocked ? '✓ Van Stock Checked' : '⚠️ Needs Morning Restock'}
                  </span>
                </div>
              </div>

              {turn.notes && (
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-300">
                  <strong className="text-slate-400 font-medium">Technician Notes: </strong>
                  {turn.notes}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Submit Turn-In Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-amber-400" />
                <span>Submit Daily Shift Turn-In</span>
              </h3>
              <button
                onClick={() => setShowSubmitModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Technician</label>
                  <select
                    value={selectedTechId}
                    onChange={(e) => setSelectedTechId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  >
                    {techs.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-bold uppercase block mb-1">Jobs Completed Today</label>
                <input
                  type="number"
                  min="0"
                  value={jobsDone}
                  onChange={(e) => setJobsDone(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Cash ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={cash}
                    onChange={(e) => setCash(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Checks ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={checks}
                    onChange={(e) => setChecks(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Card / Digital ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={card}
                    onChange={(e) => setCard(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Receipts Total ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={receiptsTotal}
                    onChange={(e) => setReceiptsTotal(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Odometer Start</label>
                  <input
                    type="number"
                    value={mileStart}
                    onChange={(e) => setMileStart(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-400 font-bold uppercase block mb-1">Odometer End</label>
                  <input
                    type="number"
                    value={mileEnd}
                    onChange={(e) => setMileEnd(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <input
                  type="checkbox"
                  id="vanRestockCheck"
                  checked={vanRestocked}
                  onChange={(e) => setVanRestocked(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-0 bg-slate-900 border-slate-700"
                />
                <label htmlFor="vanRestockCheck" className="text-slate-300 font-semibold cursor-pointer">
                  I verified truck fittings & restocked essential valves before end of shift.
                </label>
              </div>

              <div>
                <label className="text-slate-400 font-bold uppercase block mb-1">Shift Notes / Issues</label>
                <textarea
                  rows={2}
                  value={turnInNotes}
                  onChange={(e) => setTurnInNotes(e.target.value)}
                  placeholder="Notes on completed jobs, missing fittings, customer checks enclosed..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black"
                >
                  Submit for Approval
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
