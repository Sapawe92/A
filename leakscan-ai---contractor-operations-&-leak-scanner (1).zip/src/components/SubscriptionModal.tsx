import React, { useState } from 'react';
import {
  X,
  Check,
  Zap,
  ShieldCheck,
  Sparkles,
  BookOpen,
  PenTool,
  Globe,
  HardDrive,
  Volume2,
  Clock,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Award,
  Truck,
  Users,
  Building,
  Wrench,
} from 'lucide-react';
import { SubscriptionTier } from '../types';
import {
  SUBSCRIPTION_PLANS,
  FEATURE_COMPARISON_MATRIX,
  CONTRACTOR_TESTIMONIALS,
} from '../data/subscriptionPlans';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTier: SubscriptionTier;
  onSelectTier: (tier: SubscriptionTier) => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  currentTier,
  onSelectTier,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [isUpgrading, setIsUpgrading] = useState<boolean>(false);
  const [upgradeSuccess, setUpgradeSuccess] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'plans' | 'matrix' | 'testimonials'>('plans');

  if (!isOpen) return null;

  const handleSelect = (tier: SubscriptionTier) => {
    if (tier === currentTier) {
      onClose();
      return;
    }

    setIsUpgrading(true);
    setTimeout(() => {
      onSelectTier(tier);
      setIsUpgrading(false);
      setUpgradeSuccess(
        tier === 'standard'
          ? '🎉 Upgraded to Journeyman Standard! Repair Guides & Customer Sign-Off are now unlocked.'
          : tier === 'pro'
          ? '🔥 Upgraded to Master Pro Fleet! Van Stock Inventory & Tech Dispatch are now unlocked.'
          : tier === 'enterprise'
          ? '👑 Upgraded to Titan Mechanical Enterprise! Unlimited Vans, Google Drive Sync & Executive Financials are now unlocked.'
          : 'Switched to Apprentice Free Tier.'
      );
      setTimeout(() => {
        setUpgradeSuccess(null);
        onClose();
      }, 1500);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-6xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[94vh] flex flex-col">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/30 border-b border-slate-800 flex items-start justify-between relative shrink-0">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              Contractor Membership Tiers
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              4 Scalable Tiers for Field Plumbing Contractors
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-3xl">
              From solo apprentice diagnostics to full multi-van mechanical enterprise fleet operations with Van Stock inventory control, live Tech Dispatch, and multilingual repair SOPs.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Banner if upgraded */}
        {upgradeSuccess && (
          <div className="bg-emerald-500/20 border-b border-emerald-500/40 p-3.5 text-center text-sm font-bold text-emerald-300 flex items-center justify-center gap-2 animate-in slide-in-from-top-2 shrink-0">
            <Check className="w-4 h-4 text-emerald-400" />
            {upgradeSuccess}
          </div>
        )}

        {/* Controls Toolbar: Billing Toggle & Sub Tabs */}
        <div className="px-5 py-3 bg-slate-950/60 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
          {/* Sub Navigation */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('plans')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                activeTab === 'plans'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Subscription Tiers (4 Plans)
            </button>
            <button
              onClick={() => setActiveTab('matrix')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                activeTab === 'matrix'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Feature Matrix
            </button>
            <button
              onClick={() => setActiveTab('testimonials')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                activeTab === 'testimonials'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Contractor Reviews
            </button>
          </div>

          {/* Billing Cycle Toggle */}
          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-semibold cursor-pointer ${
                billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'
              }`}
              onClick={() => setBillingCycle('monthly')}
            >
              Monthly Billing
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                billingCycle === 'annual' ? 'bg-amber-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span
              className={`text-xs font-semibold cursor-pointer flex items-center gap-1.5 ${
                billingCycle === 'annual' ? 'text-amber-400 font-bold' : 'text-slate-400'
              }`}
              onClick={() => setBillingCycle('annual')}
            >
              Annual Billing
              <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                SAVE 20%
              </span>
            </span>
          </div>

          {/* Quick Demo Simulator Toggles (All 4 Tiers!) */}
          <div className="flex items-center gap-1 text-xs text-slate-400 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-400 font-mono uppercase mr-1">Simulate:</span>
            <button
              onClick={() => onSelectTier('free')}
              className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                currentTier === 'free' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Free
            </button>
            <button
              onClick={() => onSelectTier('standard')}
              className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                currentTier === 'standard' ? 'bg-blue-600 text-white' : 'text-blue-400 hover:text-blue-300'
              }`}
            >
              Standard
            </button>
            <button
              onClick={() => onSelectTier('pro')}
              className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                currentTier === 'pro' ? 'bg-amber-500 text-slate-950' : 'text-amber-400 hover:text-amber-300'
              }`}
            >
              Pro ⭐
            </button>
            <button
              onClick={() => onSelectTier('enterprise')}
              className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                currentTier === 'enterprise' ? 'bg-purple-600 text-white' : 'text-purple-400 hover:text-purple-300'
              }`}
            >
              Enterprise 👑
            </button>
          </div>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* TAB 1: 4 Subscription Pricing Cards */}
          {activeTab === 'plans' && (
            <div className="space-y-6">
              {/* Feature Highlights Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/50 p-3.5 rounded-xl border border-slate-800/80 text-xs">
                <div className="flex items-center gap-2 text-slate-300">
                  <div className="p-1.5 rounded-md bg-blue-500/10 text-blue-400">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold">Repair Guides</div>
                    <div className="text-[10px] text-slate-400">Standard Tier +</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <div className="p-1.5 rounded-md bg-blue-500/10 text-blue-400">
                    <PenTool className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold">Digital Sign-Off</div>
                    <div className="text-[10px] text-slate-400">Standard Tier +</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <div className="p-1.5 rounded-md bg-amber-500/10 text-amber-400">
                    <Truck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold">Van Stock Inventory</div>
                    <div className="text-[10px] text-amber-400">Master Pro Feature 🔥</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <div className="p-1.5 rounded-md bg-amber-500/10 text-amber-400">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold">Tech Dispatch Board</div>
                    <div className="text-[10px] text-amber-400">Master Pro Feature 🔥</div>
                  </div>
                </div>
              </div>

              {/* 4-Column Pricing Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {SUBSCRIPTION_PLANS.map((plan) => {
                  const isCurrent = currentTier === plan.id;
                  const price =
                    billingCycle === 'annual' ? plan.priceAnnual : plan.priceMonthly;

                  const isPro = plan.id === 'pro';
                  const isEnterprise = plan.id === 'enterprise';
                  const isStandard = plan.id === 'standard';

                  return (
                    <div
                      key={plan.id}
                      className={`relative rounded-2xl p-4 sm:p-5 flex flex-col justify-between transition-all ${
                        isPro
                          ? 'bg-gradient-to-b from-slate-900 via-amber-950/20 to-slate-900 border-2 border-amber-500 shadow-xl shadow-amber-500/10 ring-1 ring-amber-500/30'
                          : isEnterprise
                          ? 'bg-gradient-to-b from-slate-900 via-purple-950/20 to-slate-900 border-2 border-purple-500/80 shadow-xl shadow-purple-500/10'
                          : isStandard
                          ? 'bg-slate-900/90 border-2 border-blue-500/60 hover:border-blue-500'
                          : 'bg-slate-900/80 border border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Popular / Recommended Badge */}
                      {plan.popular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-[10px] font-black uppercase tracking-wider shadow-md whitespace-nowrap">
                          Most Popular For Fleets
                        </div>
                      )}

                      {isEnterprise && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white text-[10px] font-black uppercase tracking-wider shadow-md whitespace-nowrap">
                          Commercial Enterprise
                        </div>
                      )}

                      {/* Card Top */}
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-2">
                          <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                            {isEnterprise && <Building className="w-4 h-4 text-purple-400" />}
                            {isPro && <Truck className="w-4 h-4 text-amber-400" />}
                            {isStandard && <Wrench className="w-4 h-4 text-blue-400" />}
                            <span>{plan.name}</span>
                          </h3>
                          {isCurrent && (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                              Active
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-slate-400 min-h-[38px] leading-relaxed">
                          {plan.tagline}
                        </p>

                        {/* Price Display */}
                        <div className="my-3 py-2.5 border-y border-slate-800/80 flex items-baseline gap-1">
                          <span className="text-2xl sm:text-3xl font-black text-white">
                            ${price}
                          </span>
                          <span className="text-xs text-slate-400">
                            {plan.priceMonthly === 0 ? 'forever' : '/ mo'}
                          </span>
                          {billingCycle === 'annual' && plan.priceMonthly > 0 && (
                            <span className="ml-auto text-[10px] text-amber-400 font-medium">
                              billed yearly
                            </span>
                          )}
                        </div>

                        {/* Features List */}
                        <div className="space-y-1.5 mb-5 text-xs">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                            Included:
                          </div>
                          {plan.features.map((feat, idx) => {
                            const isHighlight = feat.startsWith('🔥') || feat.startsWith('⚡') || feat.startsWith('🏢');
                            return (
                              <div key={idx} className="flex items-start gap-1.5 text-slate-300 text-[11px] leading-snug">
                                <Check className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                                  isPro ? 'text-amber-400' : isEnterprise ? 'text-purple-400' : 'text-blue-400'
                                }`} />
                                <span className={isHighlight ? 'font-semibold text-white' : ''}>
                                  {feat}
                                </span>
                              </div>
                            );
                          })}

                          {/* Free & Standard Plan Limitations */}
                          {plan.limitations && plan.limitations.length > 0 && (
                            <div className="pt-2 border-t border-slate-800/60 mt-3 space-y-1">
                              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                Locked Features:
                              </div>
                              {plan.limitations.map((lim, idx) => (
                                <div key={idx} className="flex items-start gap-1.5 text-slate-500 text-[11px]">
                                  <X className="w-3 h-3 text-slate-600 shrink-0 mt-0.5" />
                                  <span>{lim}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action Button */}
                      <button
                        onClick={() => handleSelect(plan.id)}
                        disabled={isUpgrading}
                        className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                          isCurrent
                            ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                            : isPro
                            ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 font-black'
                            : isEnterprise
                            ? 'bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 font-black'
                            : isStandard
                            ? 'bg-blue-600 hover:bg-blue-500 text-white font-bold'
                            : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                        }`}
                      >
                        {isCurrent ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Active Plan</span>
                          </>
                        ) : (
                          <>
                            <span>{plan.ctaText}</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: Feature Matrix Comparison Table */}
          {activeTab === 'matrix' && (
            <div className="bg-slate-950/60 rounded-xl border border-slate-800 overflow-hidden">
              <div className="p-4 border-b border-slate-800">
                <h4 className="text-sm font-bold text-white">Full 4-Tier Feature Comparison Matrix</h4>
                <p className="text-xs text-slate-400">
                  Compare features across Apprentice Free, Journeyman Standard, Master Pro Fleet, and Titan Enterprise.
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-900/90 text-slate-400">
                      <th className="p-3 font-bold">Feature</th>
                      <th className="p-3 font-bold text-center w-28">Apprentice Free</th>
                      <th className="p-3 font-bold text-center w-32 bg-blue-500/5 text-blue-300">
                        Journeyman Standard
                      </th>
                      <th className="p-3 font-bold text-center w-36 bg-amber-500/10 text-amber-300">
                        Master Pro Fleet ⭐
                      </th>
                      <th className="p-3 font-bold text-center w-36 bg-purple-500/10 text-purple-300">
                        Titan Enterprise 👑
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {FEATURE_COMPARISON_MATRIX.map((item, idx) => (
                      <tr
                        key={idx}
                        className={`hover:bg-slate-900/40 transition-colors ${
                          item.highlight ? 'bg-amber-500/5' : ''
                        }`}
                      >
                        <td className="p-3 font-medium text-slate-200">
                          {item.name}
                          {item.highlight && (
                            <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                              Pro / Standard
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {typeof item.free === 'boolean' ? (
                            item.free ? (
                              <Check className="w-4 h-4 text-emerald-400 mx-auto" />
                            ) : (
                              <X className="w-4 h-4 text-slate-600 mx-auto" />
                            )
                          ) : (
                            <span className="text-slate-400">{item.free}</span>
                          )}
                        </td>
                        <td className="p-3 text-center bg-blue-500/5 text-slate-200 font-medium">
                          {typeof item.standard === 'boolean' ? (
                            item.standard ? (
                              <Check className="w-4 h-4 text-blue-400 mx-auto" />
                            ) : (
                              <X className="w-4 h-4 text-slate-600 mx-auto" />
                            )
                          ) : (
                            <span className="text-blue-300">{item.standard}</span>
                          )}
                        </td>
                        <td className="p-3 text-center bg-amber-500/10 font-bold text-white">
                          {typeof item.pro === 'boolean' ? (
                            item.pro ? (
                              <Check className="w-4 h-4 text-amber-400 mx-auto" />
                            ) : (
                              <X className="w-4 h-4 text-slate-600 mx-auto" />
                            )
                          ) : (
                            <span className="text-amber-300">{item.pro}</span>
                          )}
                        </td>
                        <td className="p-3 text-center bg-purple-500/10 font-bold text-purple-200">
                          {typeof item.enterprise === 'boolean' ? (
                            item.enterprise ? (
                              <Check className="w-4 h-4 text-purple-400 mx-auto" />
                            ) : (
                              <X className="w-4 h-4 text-slate-600 mx-auto" />
                            )
                          ) : (
                            <span className="text-purple-300">{item.enterprise}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: Reviews & Contractor Social Proof */}
          {activeTab === 'testimonials' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {CONTRACTOR_TESTIMONIALS.map((t, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex flex-col justify-between"
                  >
                    <p className="text-slate-300 italic mb-4 leading-relaxed">&ldquo;{t.quote}&rdquo;</p>
                    <div className="flex items-center justify-between border-t border-slate-800 pt-3">
                      <div>
                        <div className="font-bold text-white">{t.author}</div>
                        <div className="text-[11px] text-slate-400">{t.company} • {t.location}</div>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-amber-400 font-mono text-[10px] font-bold">
                        {t.vans}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Guarantees and Trust */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-slate-900 to-amber-950/20 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-8 h-8 text-amber-400 shrink-0" />
                  <div>
                    <h5 className="font-bold text-white">14-Day Risk-Free Contractor Guarantee</h5>
                    <p className="text-slate-400 text-[11px]">
                      Test with your technicians on real plumbing calls. If callbacks don&apos;t drop and parts tracking doesn&apos;t save hours, cancel anytime with zero penalty.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleSelect('pro')}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0 shadow-md shadow-amber-500/20"
                >
                  Start 14-Day Free Master Pro Trial
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Instant activation • Cancel anytime • Built for plumbing and mechanical crews</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Close
            </button>
            {currentTier === 'free' && (
              <button
                onClick={() => handleSelect('pro')}
                className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all shadow-md"
              >
                Upgrade to Master Pro ($95/mo)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
