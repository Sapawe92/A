import React, { useState, useEffect, useRef } from 'react';
import {
  Folder,
  Upload,
  Image as ImageIcon,
  FileText,
  ExternalLink,
  Trash2,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Camera,
  X,
  Search,
  HardDrive,
  LogOut,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck,
  Tag,
  Loader2,
  ScrollText,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  googleSignOut,
  getAccessToken,
} from '../services/googleAuth';
import {
  uploadPhotoToDrive,
  saveReportToDrive,
  saveLogToDrive,
  listLeakScanDriveFiles,
  deleteDriveFile,
  getOrCreateLeakScanFolder,
  DriveFileItem,
} from '../services/googleDrive';
import { SAMPLE_LEAK_PRESETS } from '../data/mockData';
import { getSyncQueue, getOfflineCacheStats } from '../services/offlineStorage';

interface GoogleDriveManagerProps {
  onLoadPhotoIntoScanner?: (photoUrl: string, notes?: string) => void;
  onNavigateToScan?: () => void;
}

export const GoogleDriveManager: React.FC<GoogleDriveManagerProps> = ({
  onLoadPhotoIntoScanner,
  onNavigateToScan,
}) => {
  // Auth state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Folder info
  const [folderInfo, setFolderInfo] = useState<{ id: string; webViewLink?: string } | null>(null);

  // File explorer state
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [fileFilter, setFileFilter] = useState<'all' | 'images' | 'reports' | 'logs'>('all');

  // Dedicated system activity log export state
  const [isSavingSystemLog, setIsSavingSystemLog] = useState<boolean>(false);
  const [systemLogSuccessItem, setSystemLogSuccessItem] = useState<DriveFileItem | null>(null);

  // Upload Form state
  const [uploadTitle, setUploadTitle] = useState<string>('');
  const [uploadDescription, setUploadDescription] = useState<string>('');
  const [uploadImagePreview, setUploadImagePreview] = useState<string | null>(null);
  const [uploadImagesPreviews, setUploadImagesPreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadSuccessItem, setUploadSuccessItem] = useState<DriveFileItem | null>(null);
  const [uploadSuccessCount, setUploadSuccessCount] = useState<number>(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Destructive delete confirmation modal state (Required by workspace-integration skill)
  const [fileToDelete, setFileToDelete] = useState<DriveFileItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Initialize Auth listener on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setCurrentUser(user);
        setAccessToken(token);
        loadFolderAndFiles(token);
      },
      () => {
        setCurrentUser(null);
        setAccessToken(null);
        setFiles([]);
        setFolderInfo(null);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  // Fetch or create the Drive folder and list files
  const loadFolderAndFiles = async (token: string) => {
    setIsLoadingFiles(true);
    try {
      const folder = await getOrCreateLeakScanFolder(token);
      setFolderInfo(folder);
      const fileList = await listLeakScanDriveFiles(token, folder.id);
      setFiles(fileList);
    } catch (err: any) {
      console.error('Error loading Drive folder/files:', err);
    } finally {
      setIsLoadingFiles(false);
    }
  };

  // Sign In handler
  const handleSignIn = async () => {
    setIsSigningIn(true);
    setAuthError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setCurrentUser(result.user);
        setAccessToken(result.accessToken);
        await loadFolderAndFiles(result.accessToken);
      }
    } catch (err: any) {
      console.error('Sign In Failed:', err);
      setAuthError(err.message || 'Google sign-in was closed or could not be completed.');
    } finally {
      setIsSigningIn(false);
    }
  };

  // Sign Out handler
  const handleSignOut = async () => {
    await googleSignOut();
    setCurrentUser(null);
    setAccessToken(null);
    setFiles([]);
    setFolderInfo(null);
  };

  // Handle local image selection for upload (supports multiple simultaneous files)
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (!uploadTitle) {
      setUploadTitle(files[0].name.replace(/\.[^/.]+$/, ''));
    }

    const fileList = Array.from(files);
    const promises = fileList.map((file) => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (event) => resolve(event.target?.result as string);
        reader.readAsDataURL(file);
      });
    });

    Promise.all(promises).then((results) => {
      setUploadImagesPreviews((prev) => [...prev, ...results]);
      if (!uploadImagePreview && results[0]) {
        setUploadImagePreview(results[0]);
      }
    });
  };

  // Quick preset loader
  const handleSelectPreset = (preset: (typeof SAMPLE_LEAK_PRESETS)[0]) => {
    setUploadImagePreview(preset.imageUrl);
    setUploadImagesPreviews([preset.imageUrl]);
    setUploadTitle(preset.title);
    setUploadDescription(preset.description);
  };

  // Submit Upload to Google Drive (supports multiple photos at once)
  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken) {
      setUploadError('Please sign in with Google first.');
      return;
    }

    const photosToUpload = uploadImagesPreviews.length > 0
      ? uploadImagesPreviews
      : uploadImagePreview
      ? [uploadImagePreview]
      : [];

    if (photosToUpload.length === 0) {
      setUploadError('Please select or capture at least one photo.');
      return;
    }
    if (!uploadTitle.trim()) {
      setUploadError('Please provide a title or file name.');
      return;
    }

    setIsUploading(true);
    setUploadError(null);
    setUploadSuccessItem(null);
    setUploadSuccessCount(0);

    try {
      let lastUploaded: DriveFileItem | null = null;
      for (let i = 0; i < photosToUpload.length; i++) {
        const titleSuffix = photosToUpload.length > 1 ? `_Photo_${i + 1}` : '';
        const item = await uploadPhotoToDrive(
          accessToken,
          photosToUpload[i],
          `${uploadTitle.trim()}${titleSuffix}`,
          uploadDescription.trim(),
          folderInfo?.id
        );
        lastUploaded = item;
      }

      setUploadSuccessItem(lastUploaded);
      setUploadSuccessCount(photosToUpload.length);

      // Refresh files list
      const updated = await listLeakScanDriveFiles(accessToken, folderInfo?.id);
      setFiles(updated);

      // Reset form
      setUploadTitle('');
      setUploadDescription('');
      setUploadImagePreview(null);
      setUploadImagesPreviews([]);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      console.error('Upload Error:', err);
      setUploadError(err.message || 'Failed to upload photo(s) to Google Drive.');
    } finally {
      setIsUploading(false);
    }
  };

  // Confirm and execute destructive file deletion
  const handleExecuteDelete = async () => {
    if (!accessToken || !fileToDelete) return;
    setIsDeleting(true);
    try {
      await deleteDriveFile(accessToken, fileToDelete.id);
      setFiles((prev) => prev.filter((f) => f.id !== fileToDelete.id));
      setFileToDelete(null);
    } catch (err: any) {
      alert(`Could not delete file from Google Drive: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Save application field activity & audit log to Google Drive as a separate file
  const handleExportActivityLogToDrive = async () => {
    if (!accessToken) return;
    setIsSavingSystemLog(true);
    setUploadError(null);
    try {
      const stats = getOfflineCacheStats();
      const queue = getSyncQueue();
      const timestamp = new Date().toISOString().slice(0, 10);
      const logContent = `================================================================================
LEAKSCAN AI - FIELD OPERATIONS & SYSTEM AUDIT LOG
================================================================================
Generated:           ${new Date().toISOString()} (${new Date().toLocaleString()})
Google Account:      ${currentUser?.email || 'Authenticated Field User'}
Storage Folder:      LeakScan AI Reports & Photos

[AUDIT METRICS & DATA STORE]
- Completed Jobs in Local Cache:  ${stats.jobsCount}
- Active Van Count:               ${stats.vansCount}
- Van Stock SKUs Managed:         ${stats.stockCount}
- Registered Field Technicians:   ${stats.techsCount}
- Daily Turn-Ins Logged:          ${stats.turnInsCount}
- Pending Offline Sync Actions:   ${stats.pendingSyncCount}
- Local Storage Footprint:        ~${stats.estimatedStorageKb} KB
- Last Sync Timestamp:            ${stats.lastSyncTime}

[EVENT QUEUE & TRANSACTION LOG (${queue.length} items)]
${
  queue.length === 0
    ? 'All offline events synchronized with server/cloud.'
    : queue
        .map(
          (q, idx) =>
            `[#${idx + 1}] ID: ${q.id} | Timestamp: ${new Date(q.timestamp).toISOString()}\n     Action: ${q.type}\n     Details: ${q.description}`
        )
        .join('\n\n')
}

[AUTHENTICATION & SESSION VERIFICATION]
- Auth Provider: Google Workspace OAuth 2.0
- User Identifier: ${currentUser?.uid || 'N/A'}
- Scope: drive.file
================================================================================
END OF SYSTEM AUDIT LOG FILE
`;

      const logTitle = `LeakScan_Field_Activity_Log_${timestamp}.log`;
      const uploadedItem = await saveLogToDrive(accessToken, logTitle, logContent, folderInfo?.id);
      setSystemLogSuccessItem(uploadedItem);

      // Refresh file list
      const updated = await listLeakScanDriveFiles(accessToken, folderInfo?.id);
      setFiles(updated);
    } catch (err: any) {
      console.error('Export Log to Drive Error:', err);
      setUploadError(err.message || 'Failed to save system log file to Google Drive.');
    } finally {
      setIsSavingSystemLog(false);
    }
  };

  // Filter files
  const filteredFiles = files.filter((f) => {
    const matchesQuery =
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.description && f.description.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesQuery) return false;

    if (fileFilter === 'images') {
      return f.mimeType.startsWith('image/');
    }
    if (fileFilter === 'reports') {
      return !f.mimeType.startsWith('image/') && !f.name.endsWith('.log');
    }
    if (fileFilter === 'logs') {
      return f.name.endsWith('.log') || (f.description && f.description.toLowerCase().includes('log'));
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500/20 via-blue-500/20 to-emerald-500/20 border border-slate-700 flex items-center justify-center text-blue-400">
              <HardDrive className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white">Google Drive Integration</h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/30">
                  Cloud Sync
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Save leak diagnoses, estimates, and upload jobsite photos directly into your Google Drive account.
              </p>
            </div>
          </div>

          {/* Auth State Button */}
          <div>
            {!currentUser ? (
              <div className="flex flex-col items-start md:items-end gap-1.5">
                <button
                  type="button"
                  onClick={handleSignIn}
                  disabled={isSigningIn}
                  className="gsi-material-button shadow-md hover:shadow-lg transition-all"
                  aria-label="Sign in with Google"
                >
                  <div className="gsi-material-button-state"></div>
                  <div className="gsi-material-button-content-wrapper">
                    <div className="gsi-material-button-icon">
                      <svg
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 48 48"
                        style={{ display: 'block' }}
                      >
                        <path
                          fill="#EA4335"
                          d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                        ></path>
                        <path
                          fill="#4285F4"
                          d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                        ></path>
                        <path
                          fill="#FBBC05"
                          d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                        ></path>
                        <path
                          fill="#34A853"
                          d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                        ></path>
                        <path fill="none" d="M0 0h48v48H0z"></path>
                      </svg>
                    </div>
                    <span className="gsi-material-button-contents">
                      {isSigningIn ? 'Connecting...' : 'Sign in with Google'}
                    </span>
                  </div>
                </button>
                <span className="text-[10px] text-slate-400">
                  Connect to save files to your Google Drive
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-3 bg-slate-950/70 border border-slate-800 p-2 rounded-xl">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'Google Account'}
                    className="w-9 h-9 rounded-full border border-slate-700"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-blue-600/30 text-blue-400 flex items-center justify-center font-bold text-sm">
                    {currentUser.displayName?.charAt(0) || 'U'}
                  </div>
                )}
                <div className="text-left text-xs">
                  <div className="font-semibold text-slate-200 leading-tight">
                    {currentUser.displayName || 'Google User'}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono truncate max-w-[180px]">
                    {currentUser.email}
                  </div>
                </div>
                <button
                  onClick={handleSignOut}
                  title="Sign out from Google"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors ml-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Auth error banner */}
        {authError && (
          <div className="mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{authError}</span>
          </div>
        )}

        {/* Dedicated folder status banner & Log export action */}
        {currentUser && folderInfo && (
          <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <Folder className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Target Google Drive Folder:</span>
              <span className="font-semibold text-amber-300 font-mono">
                LeakScan AI Reports & Photos
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleExportActivityLogToDrive}
                disabled={isSavingSystemLog || !accessToken}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold text-xs transition-colors"
                title="Save application operations and offline event log to Google Drive as a separate file"
              >
                {isSavingSystemLog ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving Log File...</span>
                  </>
                ) : (
                  <>
                    <ScrollText className="w-3.5 h-3.5" />
                    <span>Save Operations Log to Drive</span>
                  </>
                )}
              </button>

              {folderInfo.webViewLink && (
                <a
                  href={folderInfo.webViewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-blue-400 hover:text-blue-300 font-semibold transition-colors px-2 py-1"
                >
                  <span>Open Folder</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>
        )}

        {/* System Activity Log Save Success Banner */}
        {systemLogSuccessItem && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs text-emerald-200 flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Operations & Event Log successfully saved as a separate file in your Google Drive: <strong className="text-white font-mono">{systemLogSuccessItem.name}</strong>
              </span>
            </div>
            {systemLogSuccessItem.webViewLink && (
              <a
                href={systemLogSuccessItem.webViewLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold flex items-center gap-1 shrink-0"
              >
                <span>View Log</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        )}
      </div>

      {/* Main Grid: Upload Photo Form (Left) & File Browser (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Upload Photos and Descriptions */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Upload className="w-4 h-4 text-amber-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Upload Photo & Description
                </h2>
              </div>
              <span className="text-[10px] text-amber-400/90 font-mono bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                Direct to Drive
              </span>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-4">
              {/* Photo Select / Preview Area */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-300">
                    Jobsite Photo(s) {uploadImagesPreviews.length > 0 && `(${uploadImagesPreviews.length} selected)`}
                  </label>
                  {uploadImagesPreviews.length > 0 && (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="text-[11px] text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
                    >
                      + Add More
                    </button>
                  )}
                </div>
                {uploadImagesPreviews.length > 0 ? (
                  <div className="space-y-2">
                    <div className="relative rounded-xl overflow-hidden border border-slate-700 bg-slate-950 h-52 group">
                      <img
                        src={uploadImagePreview || uploadImagesPreviews[0]}
                        alt="Selected leak"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setUploadImagesPreviews([]);
                          setUploadImagePreview(null);
                        }}
                        className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-900/80 hover:bg-rose-500 text-slate-300 hover:text-white transition-all backdrop-blur"
                        title="Clear all images"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <div className="absolute bottom-2 left-2 right-2 bg-slate-950/80 backdrop-blur px-2.5 py-1.5 rounded-lg text-[11px] text-slate-300 flex items-center justify-between">
                        <span>{uploadImagesPreviews.length} photo(s) selected for Drive upload</span>
                        <span className="font-mono text-amber-400">Direct to Drive</span>
                      </div>
                    </div>

                    {/* Thumbnail strip for multiple images */}
                    {uploadImagesPreviews.length > 1 && (
                      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
                        {uploadImagesPreviews.map((img, idx) => (
                          <div
                            key={idx}
                            onClick={() => setUploadImagePreview(img)}
                            className={`relative shrink-0 w-12 h-12 rounded-lg overflow-hidden border-2 cursor-pointer transition-all ${
                              (uploadImagePreview || uploadImagesPreviews[0]) === img
                                ? 'border-amber-400 ring-2 ring-amber-400/30'
                                : 'border-slate-700 opacity-70 hover:opacity-100'
                            }`}
                          >
                            <img src={img} alt={`Thumb ${idx + 1}`} className="w-full h-full object-cover" />
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const filtered = uploadImagesPreviews.filter((_, i) => i !== idx);
                                setUploadImagesPreviews(filtered);
                                if (uploadImagePreview === img) {
                                  setUploadImagePreview(filtered[0] || null);
                                }
                              }}
                              className="absolute top-0 right-0 w-3.5 h-3.5 bg-slate-950/90 text-rose-400 hover:bg-rose-500 hover:text-white rounded-bl flex items-center justify-center text-[9px]"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="h-44 border-2 border-dashed border-slate-700 hover:border-amber-500/70 rounded-xl bg-slate-950/60 hover:bg-slate-950 flex flex-col items-center justify-center p-4 text-center cursor-pointer transition-all group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-slate-800 group-hover:bg-amber-500/10 text-slate-400 group-hover:text-amber-400 flex items-center justify-center transition-colors mb-2">
                      <ImageIcon className="w-6 h-6" />
                    </div>
                    <p className="text-xs font-bold text-slate-200 group-hover:text-white">
                      Click to choose or drop multiple photos
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Upload multiple pictures at once (JPG, PNG, WebP)
                    </p>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageSelect}
                  className="hidden"
                />
              </div>

              {/* Sample Leak Quick Loaders */}
              <div>
                <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
                  Or pick a common field sample:
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  {SAMPLE_LEAK_PRESETS.slice(0, 4).map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className="px-2 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 text-left text-[11px] text-slate-300 hover:text-white truncate transition-all"
                    >
                      {preset.title.split(' - ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Photo Title / Label */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Photo Name / Tag <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Unit 4B - 3/4in Copper Pinhole Leak"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-500 focus:outline-none text-xs text-white placeholder-slate-500 font-sans"
                />
              </div>

              {/* Jobsite Description / Technician Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Repair Notes & Job Description
                </label>
                <textarea
                  rows={3}
                  placeholder="Describe location, pipe type, severity, or customer requirements so technicians have full context..."
                  value={uploadDescription}
                  onChange={(e) => setUploadDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-amber-500 focus:outline-none text-xs text-white placeholder-slate-500 font-sans resize-none"
                />
              </div>

              {uploadError && (
                <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{uploadError}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-1">
                {!currentUser ? (
                  <button
                    type="button"
                    onClick={handleSignIn}
                    className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Connect Google Drive to Upload</span>
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isUploading || (uploadImagesPreviews.length === 0 && !uploadImagePreview)}
                    className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all ${
                      isUploading || (uploadImagesPreviews.length === 0 && !uploadImagePreview)
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20 active:scale-98'
                    }`}
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Uploading {uploadImagesPreviews.length > 1 ? `${uploadImagesPreviews.length} Photos` : 'Photo'} to Google Drive...</span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4" />
                        <span>
                          {uploadImagesPreviews.length > 1
                            ? `Upload ${uploadImagesPreviews.length} Photos to Google Drive`
                            : 'Upload to Google Drive'}
                        </span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </form>

            {/* Upload Success Callout */}
            {uploadSuccessItem && (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs space-y-2 animate-in fade-in">
                <div className="flex items-center gap-2 text-emerald-300 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Uploaded to Google Drive!</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  <strong className="text-white">{uploadSuccessItem.name}</strong> is safely stored in your "LeakScan AI Reports & Photos" folder.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  {uploadSuccessItem.webViewLink && (
                    <a
                      href={uploadSuccessItem.webViewLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1 border border-emerald-500/30"
                    >
                      <span>View in Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                  {onLoadPhotoIntoScanner && (
                    <button
                      type="button"
                      onClick={() => {
                        if (uploadSuccessItem.thumbnailLink || uploadImagePreview) {
                          onLoadPhotoIntoScanner(
                            uploadImagePreview || uploadSuccessItem.thumbnailLink!,
                            uploadSuccessItem.description
                          );
                        }
                      }}
                      className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-bold flex items-center gap-1 shadow-sm"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Diagnose Now with AI</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Google Drive File Explorer */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            {/* Explorer Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Folder className="w-4 h-4 text-amber-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Files in Google Drive
                </h2>
                <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                  {files.length}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => accessToken && loadFolderAndFiles(accessToken)}
                  disabled={isLoadingFiles || !accessToken}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                  title="Refresh Drive files"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFiles ? 'animate-spin' : ''}`} />
                </button>

                {/* Filter Pills */}
                <div className="flex items-center bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[11px]">
                  <button
                    onClick={() => setFileFilter('all')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      fileFilter === 'all'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    All
                  </button>
                  <button
                    onClick={() => setFileFilter('images')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      fileFilter === 'images'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Photos
                  </button>
                  <button
                    onClick={() => setFileFilter('reports')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      fileFilter === 'reports'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Estimates
                  </button>
                  <button
                    onClick={() => setFileFilter('logs')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      fileFilter === 'logs'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Logs
                  </button>
                </div>
              </div>
            </div>

            {/* Search Bar */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search Drive files by name or notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* File List View */}
            {!currentUser ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-800/80 text-blue-400 flex items-center justify-center mx-auto">
                  <HardDrive className="w-6 h-6" />
                </div>
                <p className="text-sm font-semibold text-slate-300">
                  Connect Google Drive to View Your Files
                </p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Sign in with your Google account to automatically store and browse all jobsite photos and estimates.
                </p>
                <button
                  onClick={handleSignIn}
                  disabled={isSigningIn}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all inline-flex items-center gap-2"
                >
                  <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
                    <path d="M12.24 10.285V13.4h6.887C18.2 16.14 15.645 18 12.24 18c-3.315 0-6-2.685-6-6s2.685-6 6-6c1.53 0 2.92.57 3.99 1.51l2.355-2.355C17.15 3.735 14.83 3 12.24 3 7.28 3 3.24 7.04 3.24 12s4.04 9 9 9c5.2 0 8.64-3.655 8.64-8.8 0-.61-.06-1.2-.18-1.765l-8.46-.15z" />
                  </svg>
                  <span>Sign in with Google</span>
                </button>
              </div>
            ) : isLoadingFiles ? (
              <div className="py-12 text-center space-y-2">
                <Loader2 className="w-6 h-6 text-amber-400 animate-spin mx-auto" />
                <p className="text-xs text-slate-400">Loading files from Google Drive...</p>
              </div>
            ) : filteredFiles.length === 0 ? (
              <div className="py-12 text-center space-y-2">
                <Folder className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-xs font-semibold text-slate-300">No files found</p>
                <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                  {searchQuery
                    ? 'No files matching your search filter.'
                    : 'Upload a photo using the form on the left or save a scan from the Camera Scanner.'}
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
                {filteredFiles.map((file) => {
                  const isImage = file.mimeType.startsWith('image/');
                  const isLog =
                    file.name.endsWith('.log') ||
                    (file.description && file.description.toLowerCase().includes('log'));
                  return (
                    <div
                      key={file.id}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-all flex items-start justify-between gap-3 group"
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        {/* Thumbnail or File Icon */}
                        {isImage && file.thumbnailLink ? (
                          <img
                            src={file.thumbnailLink}
                            alt={file.name}
                            className="w-12 h-12 rounded-lg object-cover bg-slate-900 border border-slate-800 shrink-0"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                            {isImage ? (
                              <ImageIcon className="w-6 h-6 text-amber-400" />
                            ) : isLog ? (
                              <ScrollText className="w-6 h-6 text-emerald-400" />
                            ) : (
                              <FileText className="w-6 h-6 text-blue-400" />
                            )}
                          </div>
                        )}

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="text-xs font-bold text-white truncate font-sans">
                              {file.name}
                            </h3>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                                isImage
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                  : isLog
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                              }`}
                            >
                              {isImage ? 'Photo' : isLog ? 'Log File' : 'Report'}
                            </span>
                          </div>

                          {file.description && (
                            <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                              {file.description}
                            </p>
                          )}

                          <div className="flex items-center gap-3 text-[10px] text-slate-500 mt-1 font-mono">
                            {file.createdTime && (
                              <span>
                                {new Date(file.createdTime).toLocaleDateString([], {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* File Action Buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Diagnose in AI button (if image) */}
                        {isImage && onLoadPhotoIntoScanner && (
                          <button
                            type="button"
                            onClick={() => {
                              if (file.thumbnailLink) {
                                onLoadPhotoIntoScanner(file.thumbnailLink, file.description);
                              }
                            }}
                            className="px-2 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1 transition-all"
                            title="Open and diagnose this photo in LeakScan AI"
                          >
                            <Sparkles className="w-3 h-3" />
                            <span className="hidden sm:inline">Diagnose</span>
                          </button>
                        )}

                        {/* Open in Google Drive Link */}
                        {file.webViewLink && (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            title="Open in Google Drive"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {/* Delete Button (triggers confirmation dialog) */}
                        <button
                          type="button"
                          onClick={() => setFileToDelete(file)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Delete from Google Drive"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* MANDATORY USER CONFIRMATION DIALOG FOR DESTRUCTIVE OPERATIONS (Per SKILL.md guidelines) */}
      {fileToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4 text-left relative">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete file from Google Drive?</h3>
                <p className="text-xs text-slate-400 mt-0.5">This action cannot be undone.</p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
              <span className="text-[10px] text-slate-500 uppercase font-mono block">Target File</span>
              <div className="font-semibold text-slate-200 mt-0.5 truncate">{fileToDelete.name}</div>
              {fileToDelete.description && (
                <div className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                  {fileToDelete.description}
                </div>
              )}
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to permanently remove this file from your Google Drive folder?
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setFileToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteDelete}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirm Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
