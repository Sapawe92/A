import { useEffect, useState } from 'react';
import { getSimulatedOffline } from '../services/offlineStorage';

export function useOnlineStatus() {
  const [browserOnline, setBrowserOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [simulatedOffline, setSimulatedOffline] = useState(getSimulatedOffline());

  useEffect(() => {
    const handleOnline = () => setBrowserOnline(true);
    const handleOffline = () => setBrowserOnline(false);
    const handleSimChange = () => setSimulatedOffline(getSimulatedOffline());

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('offline-simulation-changed', handleSimChange);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('offline-simulation-changed', handleSimChange);
    };
  }, []);

  // Effective status: false if real browser is offline OR simulation is active
  const isOnline = browserOnline && !simulatedOffline;

  return {
    isOnline,
    browserOnline,
    isSimulated: simulatedOffline,
  };
}
