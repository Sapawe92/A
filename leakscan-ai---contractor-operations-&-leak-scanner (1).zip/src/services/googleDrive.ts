// Google Drive API Client-Side Service
export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  thumbnailLink?: string;
  createdTime?: string;
  size?: string;
  description?: string;
}

const FOLDER_NAME = 'LeakScan AI Reports & Photos';

// Locate or create dedicated folder in Google Drive
export async function getOrCreateLeakScanFolder(accessToken: string): Promise<{ id: string; webViewLink?: string }> {
  const query = `mimeType='application/vnd.google-apps.folder' and name='${FOLDER_NAME}' and trashed=false`;
  const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name,webViewLink)`;

  const searchRes = await fetch(searchUrl, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!searchRes.ok) {
    throw new Error(`Failed to search Google Drive folders: ${searchRes.statusText}`);
  }

  const searchData = await searchRes.json();
  if (searchData.files && searchData.files.length > 0) {
    return { id: searchData.files[0].id, webViewLink: searchData.files[0].webViewLink };
  }

  // Create folder if it doesn't exist
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files?fields=id,name,webViewLink', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: FOLDER_NAME,
      mimeType: 'application/vnd.google-apps.folder',
      description: 'LeakScan AI Contractor Job Estimates, Diagnoses and Field Photos',
    }),
  });

  if (!createRes.ok) {
    throw new Error(`Failed to create Google Drive folder: ${createRes.statusText}`);
  }

  const folderData = await createRes.json();
  return { id: folderData.id, webViewLink: folderData.webViewLink };
}

// Upload a photo to Google Drive with custom description
export async function uploadPhotoToDrive(
  accessToken: string,
  base64DataUrl: string,
  filename: string,
  description?: string,
  folderId?: string
): Promise<DriveFileItem> {
  const targetFolder = folderId ? { id: folderId } : await getOrCreateLeakScanFolder(accessToken);

  // Extract base64 and mime type
  const match = base64DataUrl.match(/^data:([^;]+);base64,(.+)$/);
  const mimeType = match ? match[1] : 'image/jpeg';
  const rawBase64 = match ? match[2] : base64DataUrl;

  const byteCharacters = atob(rawBase64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);

  // Multipart upload to Google Drive
  const cleanFilename = filename.endsWith('.jpg') || filename.endsWith('.png') ? filename : `${filename}.jpg`;
  const metadata = {
    name: cleanFilename,
    parents: [targetFolder.id],
    description: description || 'Uploaded via LeakScan AI Field Inspector',
  };

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadataPart = `${delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}`;
  const mediaPartHeader = `${delimiter}Content-Type: ${mimeType}\r\nContent-Transfer-Encoding: base64\r\n\r\n`;

  const body = new Blob([metadataPart, mediaPartHeader, rawBase64, closeDelimiter]);

  const uploadRes = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,thumbnailLink,createdTime,size,description',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: body,
    }
  );

  if (!uploadRes.ok) {
    const errText = await uploadRes.text();
    throw new Error(`Upload to Google Drive failed: ${errText}`);
  }

  return await uploadRes.json();
}

// Save a detailed leak report and estimate to Google Drive
export async function saveReportToDrive(
  accessToken: string,
  title: string,
  content: string,
  folderId?: string
): Promise<DriveFileItem> {
  const targetFolder = folderId ? { id: folderId } : await getOrCreateLeakScanFolder(accessToken);

  const cleanTitle = title.endsWith('.txt') ? title : `${title}.txt`;
  const metadata = {
    name: cleanTitle,
    parents: [targetFolder.id],
    mimeType: 'text/plain',
    description: 'LeakScan AI Contractor Job Estimate & Diagnostic Report',
  };

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const body = `${delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(
    metadata
  )}${delimiter}Content-Type: text/plain; charset=UTF-8\r\n\r\n${content}${closeDelimiter}`;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,createdTime,size,description',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: body,
    }
  );

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to save report to Google Drive: ${errText}`);
  }

  return await res.json();
}

// Save a dedicated technical diagnostic or activity log to Google Drive as a separate file
export async function saveLogToDrive(
  accessToken: string,
  title: string,
  content: string,
  folderId?: string
): Promise<DriveFileItem> {
  const targetFolder = folderId ? { id: folderId } : await getOrCreateLeakScanFolder(accessToken);

  const cleanTitle = title.endsWith('.log') || title.endsWith('.txt') ? title : `${title}.log`;
  const metadata = {
    name: cleanTitle,
    parents: [targetFolder.id],
    mimeType: 'text/plain',
    description: 'LeakScan AI Contractor Diagnostic & System Activity Log File',
  };

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const body = `${delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(
    metadata
  )}${delimiter}Content-Type: text/plain; charset=UTF-8\r\n\r\n${content}${closeDelimiter}`;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,createdTime,size,description',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: body,
    }
  );

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to save log to Google Drive: ${errText}`);
  }

  return await res.json();
}

// List all files inside the LeakScan AI Drive folder
export async function listLeakScanDriveFiles(
  accessToken: string,
  folderId?: string
): Promise<DriveFileItem[]> {
  const targetFolder = folderId ? { id: folderId } : await getOrCreateLeakScanFolder(accessToken);
  const query = `'${targetFolder.id}' in parents and trashed=false`;
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
    query
  )}&fields=files(id,name,mimeType,webViewLink,thumbnailLink,createdTime,size,description)&orderBy=createdTime desc`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    throw new Error(`Failed to list files from Google Drive: ${res.statusText}`);
  }

  const data = await res.json();
  return data.files || [];
}

// Delete file from Google Drive (Requires user confirmation in UI before invoking)
export async function deleteDriveFile(
  accessToken: string,
  fileId: string
): Promise<boolean> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    throw new Error(`Failed to delete Google Drive file: ${res.statusText}`);
  }

  return true;
}

