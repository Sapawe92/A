import { Job, StockItem, Van, Technician, DailyTurnIn } from '../types';
import {
  INITIAL_VANS,
  INITIAL_STOCK,
  INITIAL_TECHS,
  INITIAL_JOBS,
  INITIAL_TURN_INS,
} from '../data/mockData';

// Local Storage Keys
const STORAGE_KEYS = {
  JOBS: 'leakscan_offline_jobs_v1',
  STOCK: 'leakscan_offline_stock_v1',
  VANS: 'leakscan_offline_vans_v1',
  TECHS: 'leakscan_offline_techs_v1',
  TURN_INS: 'leakscan_offline_turnins_v1',
  SYNC_QUEUE: 'leakscan_offline_sync_queue_v1',
  SIMULATED_OFFLINE: 'leakscan_simulated_offline',
  LAST_SYNC: 'leakscan_last_cache_sync_time',
};

export interface SyncQueueAction {
  id: string;
  type:
    | 'stock_update'
    | 'stock_add'
    | 'stock_restock'
    | 'parts_deducted'
    | 'job_create'
    | 'job_status'
    | 'job_historical_photo'
    | 'job_signoff'
    | 'turnin_submit';
  description: string;
  timestamp: number;
  payload: any;
}

export interface OfflineCacheStats {
  jobsCount: number;
  stockCount: number;
  vansCount: number;
  techsCount: number;
  turnInsCount: number;
  pendingSyncCount: number;
  estimatedStorageKb: number;
  lastSyncTime: string;
}

// Helper for safe JSON parse
function safeParse<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (err) {
    console.warn(`[OfflineStorage] Error reading ${key} from localStorage:`, err);
    return fallback;
  }
}

// Helper for safe JSON stringify
function safeSave<T>(key: string, data: T): boolean {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
    return true;
  } catch (err) {
    console.error(`[OfflineStorage] Failed to save ${key} to localStorage:`, err);
    return false;
  }
}

// ----------------- Initial Data Loaders -----------------

export function loadStoredJobs(): Job[] {
  const jobs = safeParse<Job[] | null>(STORAGE_KEYS.JOBS, null);
  if (jobs && Array.isArray(jobs) && jobs.length > 0) {
    return jobs;
  }
  // Initialize with initial data and cache immediately
  safeSave(STORAGE_KEYS.JOBS, INITIAL_JOBS);
  return INITIAL_JOBS;
}

export function saveStoredJobs(jobs: Job[]): void {
  safeSave(STORAGE_KEYS.JOBS, jobs);
}

export function loadStoredStock(): StockItem[] {
  const stock = safeParse<StockItem[] | null>(STORAGE_KEYS.STOCK, null);
  if (stock && Array.isArray(stock) && stock.length > 0) {
    return stock;
  }
  safeSave(STORAGE_KEYS.STOCK, INITIAL_STOCK);
  return INITIAL_STOCK;
}

export function saveStoredStock(stock: StockItem[]): void {
  safeSave(STORAGE_KEYS.STOCK, stock);
}

export function loadStoredVans(): Van[] {
  const vans = safeParse<Van[] | null>(STORAGE_KEYS.VANS, null);
  if (vans && Array.isArray(vans) && vans.length > 0) {
    return vans;
  }
  safeSave(STORAGE_KEYS.VANS, INITIAL_VANS);
  return INITIAL_VANS;
}

export function saveStoredVans(vans: Van[]): void {
  safeSave(STORAGE_KEYS.VANS, vans);
}

export function loadStoredTechs(): Technician[] {
  const techs = safeParse<Technician[] | null>(STORAGE_KEYS.TECHS, null);
  if (techs && Array.isArray(techs) && techs.length > 0) {
    return techs;
  }
  safeSave(STORAGE_KEYS.TECHS, INITIAL_TECHS);
  return INITIAL_TECHS;
}

export function saveStoredTechs(techs: Technician[]): void {
  safeSave(STORAGE_KEYS.TECHS, techs);
}

export function loadStoredTurnIns(): DailyTurnIn[] {
  const turnIns = safeParse<DailyTurnIn[] | null>(STORAGE_KEYS.TURN_INS, null);
  if (turnIns && Array.isArray(turnIns) && turnIns.length > 0) {
    return turnIns;
  }
  safeSave(STORAGE_KEYS.TURN_INS, INITIAL_TURN_INS);
  return INITIAL_TURN_INS;
}

export function saveStoredTurnIns(turnIns: DailyTurnIn[]): void {
  safeSave(STORAGE_KEYS.TURN_INS, turnIns);
}

// ----------------- Offline Sync Queue -----------------

export function getSyncQueue(): SyncQueueAction[] {
  return safeParse<SyncQueueAction[]>(STORAGE_KEYS.SYNC_QUEUE, []);
}

export function enqueueSyncAction(
  type: SyncQueueAction['type'],
  description: string,
  payload: any
): SyncQueueAction {
  const current = getSyncQueue();
  const newAction: SyncQueueAction = {
    id: `sync-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    type,
    description,
    timestamp: Date.now(),
    payload,
  };
  const updated = [...current, newAction];
  safeSave(STORAGE_KEYS.SYNC_QUEUE, updated);
  return newAction;
}

export function clearSyncQueue(): void {
  safeSave(STORAGE_KEYS.SYNC_QUEUE, []);
}

export function removeSyncAction(actionId: string): void {
  const current = getSyncQueue();
  safeSave(
    STORAGE_KEYS.SYNC_QUEUE,
    current.filter((item) => item.id !== actionId)
  );
}

// ----------------- Simulated Offline Toggle -----------------

export function getSimulatedOffline(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEYS.SIMULATED_OFFLINE) === 'true';
  } catch {
    return false;
  }
}

export function setSimulatedOffline(val: boolean): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SIMULATED_OFFLINE, val ? 'true' : 'false');
    window.dispatchEvent(new Event('offline-simulation-changed'));
  } catch (err) {
    console.error('Failed to set simulated offline state', err);
  }
}

// ----------------- Cache Statistics & Diagnostics -----------------

export function getOfflineCacheStats(): OfflineCacheStats {
  const jobs = safeParse<Job[]>(STORAGE_KEYS.JOBS, []);
  const stock = safeParse<StockItem[]>(STORAGE_KEYS.STOCK, []);
  const vans = safeParse<Van[]>(STORAGE_KEYS.VANS, []);
  const techs = safeParse<Technician[]>(STORAGE_KEYS.TECHS, []);
  const turnIns = safeParse<DailyTurnIn[]>(STORAGE_KEYS.TURN_INS, []);
  const queue = getSyncQueue();

  // Estimate localStorage usage
  let totalChars = 0;
  for (const key of Object.values(STORAGE_KEYS)) {
    const val = localStorage.getItem(key);
    if (val) totalChars += val.length;
  }
  const estimatedStorageKb = Math.round((totalChars * 2) / 1024);

  const lastSyncTime =
    localStorage.getItem(STORAGE_KEYS.LAST_SYNC) ||
    new Date().toISOString();

  return {
    jobsCount: jobs.length,
    stockCount: stock.length,
    vansCount: vans.length,
    techsCount: techs.length,
    turnInsCount: turnIns.length,
    pendingSyncCount: queue.length,
    estimatedStorageKb,
    lastSyncTime,
  };
}

export function resetCacheToDefaults(): void {
  safeSave(STORAGE_KEYS.JOBS, INITIAL_JOBS);
  safeSave(STORAGE_KEYS.STOCK, INITIAL_STOCK);
  safeSave(STORAGE_KEYS.VANS, INITIAL_VANS);
  safeSave(STORAGE_KEYS.TECHS, INITIAL_TECHS);
  safeSave(STORAGE_KEYS.TURN_INS, INITIAL_TURN_INS);
  safeSave(STORAGE_KEYS.SYNC_QUEUE, []);
}
