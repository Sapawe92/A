import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createPng(width, height, drawFn) {
  // RGBA buffer with filter byte 0 at start of each scanline
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(rowSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter type: None
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const compressedData = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrChunk = Buffer.alloc(13);
  ihdrChunk.writeUInt32BE(width, 0);
  ihdrChunk.writeUInt32BE(height, 4);
  ihdrChunk.writeUInt8(8, 8); // 8 bits per channel
  ihdrChunk.writeUInt8(6, 9); // Color type 6: RGBA
  ihdrChunk.writeUInt8(0, 10); // Compression method 0
  ihdrChunk.writeUInt8(0, 11); // Filter method 0
  ihdrChunk.writeUInt8(0, 12); // Interlace method 0

  function makeChunk(type, data) {
    const typeBuf = Buffer.from(type, 'ascii');
    const len = data.length;
    const buf = Buffer.alloc(4 + 4 + len + 4);
    buf.writeUInt32BE(len, 0);
    typeBuf.copy(buf, 4);
    data.copy(buf, 8);
    // CRC32 over type + data
    const crc = crc32(Buffer.concat([typeBuf, data]));
    buf.writeUInt32BE(crc, 8 + len);
    return buf;
  }

  // Quick CRC32 table
  function crc32(buf) {
    let table = [];
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c;
    }
    let crc = -1;
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
    }
    return (crc ^ (-1)) >>> 0;
  }

  const ihdr = makeChunk('IHDR', ihdrChunk);
  const idat = makeChunk('IDAT', compressedData);
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

// Ensure public dir
const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Brand SVG
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="100%" stop-color="#1e293b" />
    </linearGradient>
    <linearGradient id="drop" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="100%" stop-color="#0284c7" />
    </linearGradient>
    <linearGradient id="beam" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#ea580c" />
    </linearGradient>
  </defs>
  <!-- Background with rounded corners -->
  <rect width="512" height="512" rx="112" fill="url(#bg)" />
  <!-- Scanner Target Ring -->
  <circle cx="256" cy="256" r="160" fill="none" stroke="#334155" stroke-width="8" stroke-dasharray="16 16" />
  <circle cx="256" cy="256" r="110" fill="none" stroke="#0ea5e9" stroke-width="4" opacity="0.6" />
  
  <!-- Water Droplet -->
  <path d="M256 120 C256 120 176 240 176 300 C176 344 212 380 256 380 C300 380 336 344 336 300 C336 240 256 120 256 120 Z" fill="url(#drop)" />
  <!-- Droplet highlight -->
  <path d="M236 250 C236 220 256 180 256 180 C240 210 210 260 210 290 C210 310 220 326 234 336 C226 322 224 306 226 290 C228 274 236 260 236 250 Z" fill="#bae6fd" opacity="0.7" />

  <!-- Laser Scanner Pulse Line -->
  <line x1="140" y1="290" x2="372" y2="290" stroke="#f59e0b" stroke-width="8" stroke-linecap="round" />
  <circle cx="256" cy="290" r="7" fill="#ffffff" />
  <circle cx="256" cy="290" r="14" fill="#f59e0b" opacity="0.4" />
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent, 'utf8');

// Color function for raster icons
function drawBrandIcon(x, y, w, h) {
  // Center is (w/2, h/2)
  const cx = w / 2;
  const cy = h / 2;
  const r = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
  const maxR = w / 2;

  // Background navy: #0f172a (15, 23, 42)
  let bgR = 15, bgG = 23, bgB = 42;

  // Subtle radial gradient in bg
  const t = Math.min(1, r / maxR);
  bgR = Math.round(15 + 15 * t);
  bgG = Math.round(23 + 18 * t);
  bgB = Math.round(42 + 20 * t);

  // Droplet approximate shape
  const nx = (x - cx) / (w * 0.32);
  const ny = (y - cy + (h * 0.05)) / (h * 0.36);

  // Droplet formula: (x^2 + (y - sqrt(|x|))^2) < radius
  const isDroplet = (nx * nx + (ny - 0.5 * Math.abs(nx)) ** 2) < 0.65 && ny > -1.1 && ny < 1.1;

  // Scanner beam: horizontal amber line at cy + 0.1 * h
  const isBeam = Math.abs(y - (cy + h * 0.1)) < Math.max(2, h * 0.02) && Math.abs(x - cx) < (w * 0.36);

  if (isBeam) {
    return [245, 158, 11, 255]; // Amber #f59e0b
  }

  if (isDroplet) {
    // Cyan gradient from top to bottom
    const dropT = (ny + 1) / 2;
    const dr = Math.round(56 * (1 - dropT) + 2 * dropT);
    const dg = Math.round(189 * (1 - dropT) + 132 * dropT);
    const db = Math.round(248 * (1 - dropT) + 199 * dropT);
    return [dr, dg, db, 255];
  }

  // Cyan target ring arc
  const ringDist = Math.abs(r - w * 0.38);
  if (ringDist < Math.max(1.5, w * 0.015)) {
    return [14, 165, 233, 200];
  }

  return [bgR, bgG, bgB, 255];
}

// Generate PNGs
const p192 = createPng(192, 192, drawBrandIcon);
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), p192);

const p512 = createPng(512, 512, drawBrandIcon);
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), p512);
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), p512);

const p180 = createPng(180, 180, drawBrandIcon);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), p180);

// Favicon
const p32 = createPng(32, 32, drawBrandIcon);
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), p32);

console.log('Icons generated successfully in public/');
